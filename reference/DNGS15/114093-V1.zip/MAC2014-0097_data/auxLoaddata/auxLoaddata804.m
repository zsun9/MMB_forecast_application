function [data, judge] = auxLoaddata803(vintData,vintJudge,ovint,qvint,nlags,varargin)

if nargin == 6
    bolUseFinals = varargin{1};
end

vintData.final(:,end+1:end+8)=nan(size(vintData.final,1),8);

vintJudge.forecast(:,end+1:end+8)=nan(size(vintJudge.forecast,1),8);

data = vintData;
judge = vintJudge;
   
