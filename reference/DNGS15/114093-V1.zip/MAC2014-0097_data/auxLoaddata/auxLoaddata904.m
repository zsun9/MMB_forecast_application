function [data, judge] = auxLoaddata904(vintData,vintJudge,ovint,qvint,nlags,varargin)

if nargin == 6
    bolUseFinals = varargin{1};
end

vintData.final(:,end+1:end+9)=nan(size(vintData.final,1),9);

vintJudge.forecast(:,end+1:end+9)=nan(size(vintJudge.forecast,1),9);

data = vintData;
judge = vintJudge;
   
