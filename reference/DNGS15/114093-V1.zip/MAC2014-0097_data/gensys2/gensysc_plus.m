
function [Tcal, Rcal,Ccal, num_z] = gensysc_plus(G0, G1, C, PSI, TTT, RRR,CCC, nstate, nshocks, ind_1, ind_2, ind_ant, ind_eq, ind_eq_ant, n_end, n_exo, Tbar, nant, numAdd)

%% This re-defines the G0 G1 and PSI Matrices 
num_z = n_end+n_exo; % this excludes the anticipated policy shocks and adds 1 for the additional state

% Initializing the G2 matrix
G2_tilda = zeros(nstate+numAdd, nstate+numAdd);

%taking the Expectations 
G0_tilda = G0;
G0_tilda(ind_eq,:) = G0_tilda(ind_eq,:)*0;%[];
G0_tilda(:,ind_1) = G0_tilda(:,ind_1)*0;%[];

%moving the expectation from G0 to G2
for i_ind = 1:length(ind_1)
G2_tilda(:,ind_2(i_ind)) = G0(:,ind_1(i_ind));

% identity map of expectational states
G2_tilda(ind_eq(i_ind), ind_2(i_ind)) = 1;
G0_tilda(ind_eq(i_ind), ind_1(i_ind)) = -1;

end

%taking expectations  
%G2_tilda(num_z+1:end-1,:) = [];
%G2_tilda(:,num_z+1:end-1) = [];

%taking the Expectations  
G1_tilda = G1;
G1_tilda(ind_eq,:) = 0;%[];
G1_tilda(:,ind_1) = 0;%[];
% Taking expectation  
PSI_tilda = PSI;
PSI_tilda(ind_eq,:) = 0;%[];
PSI_tilda(:,nshocks+1:end) = []; %taking out anticipated policy shocks
% taking expectations out of C
C_tilda = C; %[C(1:num_z);C(end)];


%% This solves for the TTT and RRR Matrix using the methods in "Solving
%% Linear Rational Expectations Methods with Anticipated Policy Changes

T11 = TTT;
T11(ind_eq_ant,:) = [];
T11(:,ind_ant) = [];

R11 = RRR;
R11(ind_eq_ant,:) = [];
R11(:,nshocks+1:end) = [];  %taking out anticipated policy shocks

C11 = CCC;
C11(ind_eq_ant) = [];

%initialize Tcal and Rcal matrices
Tcal = zeros([size(T11),Tbar+1]);%zeros(num_z+1, num_z+1, Tbar+1);
Rcal = zeros([size(R11),Tbar+1]);%num_z+1, nshocks, Tbar+1);
Ccal = zeros([size(C11),Tbar+1]);%num_z+1, Tbar+1);

Tcal(:,:,end) = T11;
Rcal(:,:,end) = R11;
Ccal(:,end) = C11;

for t = 1:Tbar
Tcal(:,:,end-t) = (G2_tilda*T11 + G0_tilda)\G1_tilda;
Rcal(:,:,end-t) = (G2_tilda*T11 + G0_tilda)\PSI_tilda;
Ccal(:,end-t) = (G2_tilda*T11 + G0_tilda)\(C_tilda - G2_tilda*C11);

% Tcal(:,:,end-t) = pinv(G2_tilda*T11 + G0_tilda)*G1_tilda;
% Rcal(:,:,end-t) = pinv(G2_tilda*T11 + G0_tilda)*PSI_tilda;
% Ccal(:,end-t) = pinv(G2_tilda*T11 + G0_tilda)*(C_tilda - G2_tilda*C11);

T11 = Tcal(:,:,end-t);
C11 = Ccal(:,end-t);
R11= Rcal(:,:,end-t);
end 

end
