
function [Tcal, Rcal, Ccal,Tbar, num_z] = get_gensys2(params, mspec, model2_num, nshocks, nant)


if mspec == 510
    [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,a2,nu_l,nu_m,zeta_w,iota_w,law,rstar,psi1,psi2,rho_r,pistar,...
        Fom,sprd,zeta_spb,gammstar,NEW_5,...
        gam,Lstar,chi,laf,gstar,Ladj,...
        rho_z,rho_phi,rho_chi,rho_laf,rho_mu,rho_b,rho_g,rho_sigw,rho_mue,rho_gamm,...
        sig_z,sig_phi,sig_chi,sig_laf,sig_mu,sig_b,sig_g,sig_r,sig_sigw,sig_mue,sig_gamm,...
        bet,zstar,phi,istokbarst,rkstar,cstar,ystar,istar,kstar,kbarstar,Rstarn,wstar,wadj,mstar,...
        zeta_nRk, zeta_nR, zeta_nqk, zeta_nn, zeta_nmue, zeta_spmue, zeta_nsigw, zeta_spsigw, ...
        vstar, nstar] = getpara00_51(params);
elseif mspec == 803
    [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,ppsi,nu_l,zeta_w,iota_w,law,laf,bet,Rstarn,psi1,psi2,psi3,pistar,sigmac,rho,epsp,epsw...
        gam,Lmean,Lstar,gstar,rho_g,rho_b,rho_mu,rho_z,rho_laf,rho_law,rho_rm,...
        sig_g,sig_b,sig_mu,sig_z,sig_laf,sig_law,sig_rm,eta_gz,eta_laf,eta_law...
        zstar,rstar,rkstar,wstar,wl_c,cstar,kstar,kbarstar,istar,ystar] = getpara00_802(params);
elseif mspec == 805
    [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,ppsi,nu_l,zeta_w,iota_w,law,laf,bet,Rstarn,psi1,psi2,psi3,pistar,sigmac,rho,epsp,epsw...
        gam,Lmean,Lstar,gstar,rho_g,rho_b,rho_mu,rho_z,rho_laf,rho_law,rho_rm,rho_pist...
        sig_g,sig_b,sig_mu,sig_z,sig_laf,sig_law,sig_rm,sig_pist,eta_gz,eta_laf,eta_law...
        zstar,rstar,rkstar,wstar,wl_c,cstar,kstar,kbarstar,istar,ystar,pistflag] = getpara00_805(params);
elseif mspec == 904
    [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,ppsi,nu_l,zeta_w,iota_w,law,laf,bet,Rstarn,psi1,psi2,psi3,pistar,sigmac,rho,epsp,epsw...
        gam,Lmean,Lstar,gstar,rho_g,rho_b,rho_mu,rho_z,rho_laf,rho_law,rho_rm,rho_sigw,rho_mue,rho_gamm,rho_pist...
        sig_g,sig_b,sig_mu,sig_z,sig_laf,sig_law,sig_rm,sig_sigw,sig_mue,sig_gamm,sig_pist,eta_gz,eta_laf,eta_law...
        zstar,rstar,rkstar,wstar,wl_c,cstar,kstar,kbarstar,istar,ystar,sprd,zeta_spb,gammstar,vstar,nstar,...
        zeta_nRk,zeta_nR,zeta_nsigw,zeta_spsigw,zeta_nmue,zeta_spmue,zeta_nqk,zeta_nn] = getpara00_904(params);
end
    
%% alt policy
%psi1 = 1.2;
% psi2 = 0;

eval(['states',num2str(mspec)]);
eval(['eqs',num2str(mspec)]);
nstate = n_end+n_exo+n_exp;
neq  = nstate;
G0 = zeros(neq,neq);
G1 = zeros(neq,neq);
C =  zeros(neq,1);
PSI = zeros(neq,nex);
PIE =  zeros(neq,nend);
eval(['eqcond',num2str(mspec)]);
eval(['ant',num2str(mspec)]);
[T1,TC,T0,M,TZ,TY,gev,RC] = gensys(G0,G1,C,PSI,PIE,1+10^(-6));
if (RC(1) ~= 1) || (RC(2) ~= 1);
    TTT = zeros(nstates,nstates);
    RRR = zeros(nstates,2);
    valid = - 3;
    %keyboard;
end;
TTT =    real( T1 );
RRR =    real( T0 );
CCC =    TC;


%re-estimate the G0 , G1, PSI and G0 matrices with the second model and
%additional state
if mspec == 510
    numAdd = 1; 
    if nant>0
        neq = neq - nant -1;
    end
    G0 = zeros(neq+numAdd,neq+numAdd);
    G1 = zeros(neq+numAdd,neq+numAdd);
    C =  zeros(neq+numAdd,1);
    PSI = zeros(neq+numAdd,nex);
    PIE =  zeros(neq+numAdd,nend);
elseif any(mspec == [803 805 904])  
    numAdd = 6;
    if nant>0
        neq = neq - nant;
    end
    G0 = zeros(neq+numAdd,neq+numAdd);
    G1 = zeros(neq+numAdd,neq+numAdd);
    C =  zeros(neq+numAdd,1);
    PSI = zeros(neq+numAdd,nex);
    PIE =  zeros(neq+numAdd,nend);
end
%reset nant so that the new model has no anticipated policy shocks
nant_keep = nant; 
nant = 0;

%re-define the indicators so there are no anticipated policy shocks
eval(['states',num2str(mspec)]);
eval(['eqs',num2str(mspec)]);
eval(['exp',num2str(mspec)]);
eval(['eqcond',num2str(mspec), '_',model2_num])
nant = nant_keep;
nstate = n_end+n_exo+n_exp;

%Setting the number of periods at the ZLB
Tbar = nant-1;

% Adding the state

if mspec == 510
    AddTTT = zeros(numAdd,size(TTT,2));
    
    stateAdd = [y_t];
    
    for i = 1:numAdd
        G0(neq+i,neq+i) = 1;
        G1(neq+i,stateAdd(i)) = 1;
        AddTTT(i,stateAdd(i)) = 1;
    end
    
    TTT = [[TTT,zeros(size(TTT,1),numAdd)];[AddTTT,zeros(numAdd)]];
    RRR = [RRR ; zeros(numAdd,size(RRR,2))];
    CCC = [CCC ; zeros(numAdd,size(CCC,2))];

elseif any(mspec == [803 805 904])
    AddTTT = zeros(numAdd,size(TTT,2));
    
    stateAdd = [y_t c_t i_t w_t pi_t L_t];
    
    for i = 1:numAdd%-1
        G0(neq+i,neq+i) = 1;
        G1(neq+i,stateAdd(i)) = 1;
        AddTTT(i,stateAdd(i)) = 1;
    end
    
%     T2 = TTT^2;
%     TR = TTT*RRR;
%     CTC = CCC+TTT*CCC;
%     
%     AddTTT(7,:) = T2(pi_t,:);
    
    TTT = [[TTT,zeros(size(TTT,1),numAdd)];[AddTTT,zeros(numAdd)]];
    RRR = [RRR ; zeros(numAdd,size(RRR,2))];
    CCC = [CCC ; zeros(numAdd,size(CCC,2))];
    
%     RRR(end,:) = TR(pi_t,:);
%     CCC(end,:) = CTC(pi_t,:);
    
end


%Calculationg Tcal and Rcal recursively
[Tcal, Rcal, Ccal,num_z] = gensysc_plus(G0,G1,C,PSI,TTT,RRR,CCC,nstate,nshocks,ind_1,ind_2,ind_ant, ind_eq, ind_eq_ant, n_end,n_exo, Tbar, nant,numAdd);


end