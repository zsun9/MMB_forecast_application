%% hairplots.m generates a .mat file with smoothed states and "hair"
%% forecasts for plotting
function [hair] = hairplots_tv(mspec,sm_states,Startdate,Startdate_tv,TTT,TTT_T_seq,CCC,CCC_T_seq,NN_)

mc_t = getState(mspec,0,'mc_t');                                    % Get Marginal cost state
hair = nan(size(sm_states,2)-Startdate+2,size(sm_states,2)+NN_);    % initialize data matrix for hairplots
hair(1,1:size(sm_states,2)) = sm_states(mc_t,:);                    % store smoothed state of mc in first row

for j = Startdate:size(sm_states,2)-1     % loop over "root" dates for hairs
    x0 = sm_states(:,j);            % set root value (all states)
    k = j-Startdate+2;              % set root index
    hair(k,j)=x0(mc_t);             % select mc root value
    
    if j+1 >= Startdate_tv
        CCC_T = CCC_T_seq{j+2-Startdate_tv};
        TTT_T = TTT_T_seq{j+2-Startdate_tv};
    end
    
    for i = 1:NN_                       % grow hairs
        if j+1 >= Startdate_tv
            if i <= size(CCC_T,3) % + Startdate_tv - 1
                x0 = CCC_T(:,:,i) + TTT_T(:,:,i)*x0;
            else
                x0 = CCC + TTT*x0;
            end
        else
            x0 = CCC + TTT*x0;
        end
        
        hair(k,j+i)=x0(mc_t);
    end
end
        
        
        
        