%% hairplots.m generates a .mat file with smoothed states and "hair"
%% forecasts for plotting
function [hair] = hairplots(mspec,sm_states,Startdate,TTT,NN_)
mc_t = getState(mspec,0,'mc_t');                                    % Get Marginal cost state
hair = nan(size(sm_states,2)-Startdate+2,size(sm_states,2)+NN_);    % initialize data matrix for hairplots
hair(1,1:size(sm_states,2)) = sm_states(mc_t,:);                    % store smoothed state of mc in first row

for j = Startdate:size(sm_states,2)     % loop over "root" dates for hairs
        x0 = sm_states(:,j);            % set root value (all states)
        k = j-Startdate+2;              % set root index
        hair(k,j)=x0(mc_t);             % select mc root value
    for i = 1:NN_                       % grow hairs
        x0 = TTT*x0;
        hair(k,j+i)=x0(mc_t);
    end
end

        
        
        
        