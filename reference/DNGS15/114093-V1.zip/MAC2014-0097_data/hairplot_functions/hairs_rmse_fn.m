function [saved] = hairs_rmse_fn(mspec,fcastType,lineStyles,leg,gpath,spath,dts,start)

idx = find(start == dts) + 1;
fig = figure();
for f = 1:length(fcastType)
    load([spath,'hairs/hairplots_mc',fcastType{f},'_',num2str(mspec),'_',num2str(dts(end)*100),'.mat']);
    hair = hair_save;
    rmse = zeros(1,20);
    ct = 0;
    for i = idx:size(hair,1)
        ind = find(~isnan(hair(i,:)),21,'first');
        ind = ind(2:end);
        tmp = (hair(1,ind) - hair(i,ind)).^2;
        if ~isempty(tmp)
            tmp = arrayfun(@(x)nansum(x),tmp);
            rmse = rmse + tmp;
            ct = ct + 1;
        end
    end
    ct_adj = ct*ones(1,20) - [1:1:20];
    rmse = (rmse ./ ct_adj).^0.5;
    plot(rmse,lineStyles{f});
    hold on;
end
xlabel('h-step ahead forecast');
ylabel('RMSE');
legend(leg,'location','SouthEast');

if ~exist(gpath,'dir'), mkdir(gpath); end
saveas(fig,[gpath,'hair_rmse_',num2str(floor(start)),'Q',num2str(rem(start,1)*4+1),'_Present.pdf']);
saved = 1;
