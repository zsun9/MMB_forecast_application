%% hairplots.m generates a .mat file with smoothed states and "hair"
%% forecasts for plotting
function [hair] = hairplots_ar2(mspec,sm_states,Startdate,T,TTT,NN_)
mc_t = getState(mspec,0,'mc_t');                                    % Get Marginal cost state
hair = nan(size(sm_states,2)-Startdate+2,size(sm_states,2)+NN_);    % initialize data matrix for hairplots
hair(1,1:size(sm_states,2)) = sm_states(mc_t,:);                    % store smoothed state of mc in first row

for j = T:size(sm_states,2)                % loop over "root" dates for hairs
    
        x0 = sm_states(mc_t,j);
    
        Y = sm_states(mc_t,Startdate+2:j)';   % set root value (all states)
        
        X = [ ones(size(Y,1),1), sm_states(mc_t,Startdate+1:j-1)', sm_states(mc_t,Startdate:j-2)' ];
        
        B = inv(X'*X)*X'*Y;
        
        k = j-Startdate+2;                 % set root index
        hair(k,j)=x0;                      % select mc root value
        
        x1 = sm_states(mc_t,j);
        x2 = sm_states(mc_t,j-1);
        
    for i = 1:NN_                       % grow hairs
        
        x = [ 1, x1, x2 ]*B;
        hair(k,j+i) = x;
        x2 = x1;
        x1 = x;
    end
end
        
        
        
        