%% hairplots.m generates a .mat file with smoothed states and "hair"
%% forecasts for plotting
function [saved] = hairplots_ar2fullSample(mspec,sm_states,Startdate,T,TTT,NN_)
mc_t = getState(mspec,0,'mc_t');                                    % Get Marginal cost state
hair = nan(size(sm_states,2)-Startdate+2,size(sm_states,2)+NN_);    % initialize data matrix for hairplots
hair(1,1:size(sm_states,2)) = sm_states(mc_t,:);                    % store smoothed state of mc in first row

Y = sm_states(mc_t,Startdate+2:end)';
X = [ ones(size(Y,1),1), sm_states(mc_t,Startdate+1:end-1)', sm_states(mc_t,Startdate:end-2)' ];
B = inv(X'*X)*X'*Y;


for j = T:size(sm_states,2)                % loop over "root" dates for hairs
    
        x0 = sm_states(mc_t,j);
        
        k = j-Startdate+2;                 % set root index
        hair(k,j)=x0;                      % select mc root value
        
        x1 = sm_states(mc_t,j);
        x2 = sm_states(mc_t,j-1);
        
    for i = 1:NN_                       % grow hairs
        
        x = [ 1, x1, x2 ]*B;
        hair(k,j+i) = x;
        x2 = x1;
        x1 = x;
    end
end

save(['hairplots_mc_ar2fullSample',num2str(mspec),'.mat'],'hair');
saved = 1;
end
        
        
        
        