clear; fclose all; close all;

files = {'hairplots_mc904.mat','hairplots_mc_rw904.mat','hairplots_mc_ar2904.mat','hairplots_mc_rwfullSample904.mat','hairplots_mc_ar2fullSample904.mat','hairplots_mc_rwNODRIFTfullSample904.mat'};
lineStyles = {'rs-','bs-','cs-','bs--','cs--','gs-'};
leg = {'DSGE','Random Walk w/ Drift', 'AR(2) recursive','Random Walk w/ Drift full sample','AR(2) full sample','Random Walk'};

fig = figure();
hold on;

for f = [ 1 3 6 ]%1:length(files)
    load(files{f});
    rmse = zeros(1,20);
    ct = 0;
    for i = 102:174%size(hair,1)
        ind = find(~isnan(hair(i,:)),20,'last');
        
        tmp = (hair(1,ind) - hair(i,ind)).^2;
        if ~isempty(tmp)
            tmp = arrayfun(@(x)nansum(x),tmp);
            rmse = rmse + tmp;
            ct = ct + 1;
        end
    end
    ct_adj = ct*ones(1,20) - [1:1:20];
    rmse = (rmse ./ ct_adj).^0.5;
    plot(rmse,lineStyles{f});
end
xlabel('h-step ahead forecast');
ylabel('RMSE');
legend(leg{[1 3 6]},'location','SouthEast');
saveas(fig,'hair_rmse_1989Q4_2007Q4.pdf');
