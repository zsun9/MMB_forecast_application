function [Vseq,Vseq_alt,Shseq,Shseq_alt] = setVseq(plotType,mspec,varnames,cum_flag,phillips_mc)

mc_I = find(strcmp(varnames,'Marginal Cost'));
gap_I = find(strcmp(varnames,'Output Gap'));

%% Preallocate space for memory usage
Vseq=[];
Vseq_alt=[];
Shseq=[];
Shseq_alt=[];

%% Settings
switch plotType
    case {'Forecast'}
        if ~cum_flag
            Vseq = [1 4 5 mc_I gap_I]; % Designate which variables to plot (i.e. in this case we plot (1) Output growth, (4) GDPDEF inflation, (5) FFR, (mc_I) Marginal Cost, (gap_I) Output Gap
            if exist('phillips_mc','var') && phillips_mc
                Vseq = [4];
            end
        else % cumulated/level charts
            Vseq = [1 4]; % Cumulated (1) Output Growth and (4) GDPDEF inflation
        end
    case {'Forecast Decomposition'}
        Vseq = [1 4 5 mc_I];
end
