            
%% Figure Specifications

% Adjust Yaxis
YL = ylabel(Yaxis.axislabel);
set(YL,'FontSize',Yaxis.axislabelsize);
if exist('Yaxis.lim') && ~isempty(Yaxis.lim)
    set(gca,'YLim',Yaxis.lim);
    set(gca,'YTick',(Yaxis.lim(1):Yaxis.freq:Yaxis.lim(2)),'FontSize',Yaxis.ticklabelsize);
end
          
% Adjust Xaxis
set(gca,'XLim',Xaxis.limits);
set(gca,'XTick',Xaxis.freq);
set(gca,'XTickLabel',Xaxis.ticklabels);

% Secondary Yaxis - must be done after Xaxis, but before title to avoid
% resizing
h1 = gca;
h2 = axes('Position',get(gca,'Position'));
set(h2,'YAxisLocation','right','Color','none','XTick',[],'XTickLabel',[]);

% These lines will align the size, ticks, and fontsize of the two axes.
h(1) = h1;
h(2) = h2;
linkprop(h,{'YLim','YTick','FontSize'});
% for some reason, the YTicks don't synchronize, so this additional line is needed
% if graphs still don't look right, set the rest of the Yaxis properties after the line below
if exist('Yaxis.lim') && ~isempty(Yaxis.lim)
    set(h,'YTick',(Yaxis.lim(1):Yaxis.freq:Yaxis.lim(2)));
end;

% Title
if ~isequal(V_a,Vseq_alt) && ~noTitles
%if ~noTitles
    T = title(Title.name);
    set(T,'FontSize',Title.size);
else
    if system
        T = title(Title.name);
        set(T,'FontSize',Title.size);
    end
end

% Misc
if any(strcmp(plotList{plotnum},{'Forecast'}))
    set(gca,'Layer','top');
end

