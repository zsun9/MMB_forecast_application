% OVERVIEW
% setOutfiles.m creates variable outfile, where each field name is a type of
%               data that we want to write (ie forecast or shockdec). 
%               Each field of outfile is the name of the output file. 
% 
% IMPORTANT VARIABLES
% outfile: a structure where each field name is a type of
%          data that we want to write. Each field of outfile is the
%          name of the output file. Example: outfile.forecast =
%          '/data/data_dsge_dir/.../forecastm...."
% outdataType: a cell array listing the type of data you want to create
%              outfiles for. Example: {forecast,datashocks}.

function [outfile] = setOutfiles(outdataType,...
    spath,lmodel,lprior,ds,ssf,ti,I,nlags,T0,jstep,parstr,...
    peachflag,peachstr,...
    ShockremoveList,Startdate,Enddate_forecastfile)

peachstr = peachstr{peachflag+1};

for iDT = 1:length(outdataType)
    switch outdataType{iDT}
        case 'forecast'
            outfile.forecast = [spath,'/forecast',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),num2str(jstep),parstr];
        case 'condforecast'
            outfile.condforecast = [spath,'/condforecast',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr,num2str(jstep),parstr];
        case 'states'
            outfile.states = [spath,'/states',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),parstr];
        case 'dickshocks'
            outfile.dickshocks = [spath,'/dickshocks',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr,num2str(jstep),parstr];
            outfile.semidickshocks = [spath,'/semidickshocks',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr,num2str(jstep),parstr];
        case 'condshocks'
            outfile.condshocks = [spath,'/condshocks',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr,num2str(jstep),parstr];
            outfile.semicondshocks = [spath,'/semicondshocks',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr,num2str(jstep),parstr];
        case 'datashocks'
            outfile.datashocks = [spath,'/datashocks',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),num2str(jstep),parstr];
        case 'counter'
            for peachcounter = 0:peachflag
                for Shockremove = ShockremoveList
                    switch peachcounter
                        case 1,     outfile.(['counter',num2str(peachcounter),num2str(Shockremove)]) = [spath,'/counter',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr,num2str(Startdate),num2str(Enddate_forecastfile),num2str(Shockremove),num2str(jstep),parstr];
                        case 0,     outfile.(['counter',num2str(peachcounter),num2str(Shockremove)]) = [spath,'/counter',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),num2str(Startdate),num2str(Enddate_forecastfile),num2str(Shockremove),num2str(jstep),parstr];
                            
                    end
                end
            end
        case 'shockdec'
            for peachcounter = 0:peachflag
                for Shockremove = ShockremoveList
                    switch peachcounter
                        case 1,     if Shockremove > 0, outfile.(['shockdec',num2str(peachcounter),num2str(Shockremove)]) = [spath,'/shockdec',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr,num2str(Startdate),num2str(Enddate_forecastfile),num2str(Shockremove),num2str(jstep),parstr]; end
                        case 0,     if Shockremove > 0, outfile.(['shockdec',num2str(peachcounter),num2str(Shockremove)]) = [spath,'/shockdec',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),num2str(Startdate),num2str(Enddate_forecastfile),num2str(Shockremove),num2str(jstep),parstr]; end
                    end
                end
            end
        case 'ytrend'
            outfile.ytrend = [spath,'/ytrend',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),num2str(jstep),parstr];
        case 'dettrend'
            outfile.dettrend = [spath,'/dettrend',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),num2str(jstep),parstr];
        case 'dettrend_peach'
            outfile.dettrend_peach = [spath,'/dettrend_peach',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr,num2str(jstep),parstr];
            outfile.dettrend_semipeach = [spath,'/dettrend_semipeach',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr,num2str(jstep),parstr];
        case 'hist'
            outfile.hist = [spath,'/hist',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),num2str(jstep),parstr];
        case 'condhist'
            outfile.condhist = [spath,'/condhist',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr,num2str(jstep),parstr];
            
    end
end