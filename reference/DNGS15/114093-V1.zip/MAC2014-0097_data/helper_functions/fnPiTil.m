function [pltDt, returnVar] = fnPiTil( specFile, replaceBlock, varargin )

%%%% plotOther.m %%%%

if nargin == 3
    boolHelper = varargin{1};
    haircompare = boolHelper(1);
    swapKapSSS = boolHelper(2);
end

eval([specFile,';']);
if strcmp(specFile,'spec_904_aux_full201250')
    forecast_vintage_aux_2model;
else
    forecast_vintage_aux;
end

forplot_vint_aux;

if auxFlag
    % update auxilary var data with smoothed state "actuals"
    loadParams;
    state_file =['states',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr{peachflag+1},num2str(jstep),parstr];
    eval(['[YY,stateFinals,auxCount] = auxUpdateYY',num2str(mspec),'(YY,state_file,mspec,nlags,nstate,dataset,priotheta, priotheta);']);
end

Ys = getYs(YY(1:Idate,:),YY_p,dlpop,dlpop_p,cum_for,popadj,nvar,0,q_adj,0);

kSt = find(strcmp(varnames,'\kappa (1+\iota_p\bar{\beta}) S^{\infty}_t'));
St  = find(strcmp(varnames,'S^{\infty}_t'));

pitilde_return = fnGenPiTil(ti,Ys,Means.counter(:,1:length(ti),1,5)',kSt,priotheta,mspec);
Sinf_return = fnGenSinf(ti,Ys,Means.counter(:,1:length(ti),1,5)',St,priotheta,mspec);

returnVar = [pitilde_return, Sinf_return];
pltDt = tiI;

