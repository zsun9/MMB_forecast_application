function [observableMap] = getObservablesMap(varnamesOriginal,varnamesCompare)

observableMap = zeros(length(varnamesOriginal),length(varnamesCompare));

for ii = 1:length(varnamesOriginal)
    
    ind = find(strcmp(varnamesCompare,varnamesOriginal{ii}));
    
    if ~isempty(ind)
        observableMap(ii,ind)=1;
    else
        observableMap(ii,:) = NaN;
    end
end