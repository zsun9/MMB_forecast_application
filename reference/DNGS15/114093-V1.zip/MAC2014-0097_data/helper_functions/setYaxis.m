function [Yaxis] = setYaxis(newsletter,system,pres,mspec,dataset,zerobound,nvar,plotType,V_a)

if any(mspec==[4 40:45 450 48 6 7 8 81 16 50 51 510 555 556 557 5571 558 557 52 53 64 4501 82 511]) || any(mspec==[46 47]) && any(dataset==[100 200 300])
    switch plotType
        case {'Forecast','Forecast Comparison','Exp_Forecast','Forward Guidance','Forward Guidance Horizontal','Forecast Semicond'}
            switch V_a
                case 1 	%% output
                    if mspec==47
                        Yaxis.lim = [-7 13];
                        Yaxis.freq = 1;
                    else
                        if newsletter || system
                            Yaxis.lim = [-10 11];
                            Yaxis.freq = 1;
                        else
                            Yaxis.lim = [-9 9];
                            if any(mspec==[450 6 82])
                                Yaxis.lim = [-11 11];
                            end
                            Yaxis.freq = 3;
                        end
                    end
                case 2	%% hours
                    if any(mspec==[45 450 6 82]) && pres==1
                        Yaxis.lim = [-11 12];
                        %Yaxis.lim = [530 560];  % Use for levels
                    else
                        Yaxis.lim = [-9 12];
                        %Yaxis.lim = [530 560];  % Use for levels
                    end
                    Yaxis.freq = 1;
                    %Yaxis.freq = 5; % Use for levels
                case 3	%% labor share
                    Yaxis.lim = [0.5 0.6];
                    Yaxis.freq = 0.01;
                case 4	%% inflation
                    if any(mspec==[4 47])
                        Yaxis.lim = [-2 7];
                        Yaxis.freq = 0.5;
                    elseif mspec == 64
                        Yaxis.lim = [-2 6];
                        Yaxis.freq = 0.5;
                    else
                        if newsletter || system
                            Yaxis.lim = [-2 5];
                            Yaxis.freq = 0.5;
                        else
                            Yaxis.lim = [0 4];
                            Yaxis.freq = 1;
                        end 
                    end
                case 5	%% interest rate
                    if zerobound
                        if mspec==47 || (any(mspec==[45 450 6 82]) && pres==1)
                            Yaxis.lim = [0 6];
                            Yaxis.freq = 1;
                        else
                            Yaxis.lim = [0 6];
                            Yaxis.freq = 1;
                        end
                    else
                        if any(mspec== [4 64])
                            Yaxis.lim = [-6 8];
                            Yaxis.freq = 0.5;
                        elseif mspec==64
                            Yaxis.lim = [-4 8];
                            Yaxis.freq = 0.5;
                        else
                            Yaxis.lim = [-4 6];
                            Yaxis.freq = 1;
                        end
                    end
                    
                case 6	%% consumption in mspec 6, investment in mspec 7
                    if any(mspec== [6 64])
                        Yaxis.lim = [-10 10];
                        Yaxis.freq = 1.5;
                    elseif mspec==7
                        Yaxis.lim = [-40 40];
                        Yaxis.freq = 5;
                    elseif mspec == 16
                        Yaxis.lim = [0 12];
                        Yaxis.freq = 1;
                    elseif any(mspec==[45 450]) % pigap_t
                        Yaxis.lim = [-1 7];
                        Yaxis.freq = 1;
                    elseif any(mspec==[51 510 555 556 557 5571 558])
                        Yaxis.lim = [-3 6];
                        Yaxis.freq = 1;
                    end
                case 7	%% investment in mspec 6
                    if any(mspec==[45 450]) % real r
                        Yaxis.lim = [-4 2];
                        Yaxis.freq = 1;
                    elseif any(mspec==[51 510 555 556 5571 558]) % pigap_t
                        Yaxis.lim = [0 14];
                        Yaxis.freq = 2;
                    elseif any(mspec==[557]) % pigap_t
                        Yaxis.lim = [-10 10];
                        Yaxis.freq = 2;
                    else
                        Yaxis.lim = [-40 40];
                        Yaxis.freq = 5;
                    end
                case 8
                    if any(mspec==[45 450]) % cumlevel output
                        Yaxis.lim = [-6 10];
                        Yaxis.freq = 1;
                    elseif any(mspec==[51 510 555 556 557 5571]) % real r
                        if zerobound
                            Yaxis.lim = [-4 2];
                            Yaxis.freq = 1;
                        else
                            Yaxis.lim = [-6 2];
                            Yaxis.freq = 2;
                        end
                    elseif any(mspec==[558]) % real r
                        Yaxis.lim = [0, 3];
                        Yaxis.freq = 0.5;
                    end
                case 9
                    if any(mspec==[45 450]) % cumlevel inflation
                        Yaxis.lim = [-2 20];
                        Yaxis.freq = 2;
                    elseif any(mspec==[51 510 555 556 557 5571 558]) % cumlevel output
                        Yaxis.lim = [-8 8];
                        Yaxis.freq = 2;
                    end
                case 10 
                    if any(mspec==[51 510 555 556 557 5571 558]) % cumlevel inflation
                        Yaxis.lim = [-3 18];
                        Yaxis.freq = 3;
                    elseif any(mspec==[45]) % cumlevel nominal output
                        Yaxis.lim = [-5 20];
                        Yaxis.freq = 2;
                    end
                case 11
                    if any(mspec==[51 510 555 556 557 5571 558]) % cumlevel nominal output
                        Yaxis.lim = [-4 23];
                        Yaxis.freq = 3;
                    end
                case 12 % unemployment
%                     Yaxis.lim = [5 9];
                    Yaxis.lim = [0 11];
%                     Yaxis.freq = 0.5;
                    Yaxis.freq = 1;
                case 13	%% interest rate
                    if zerobound
                        if mspec==47 || (any(mspec==[45 450 6 82]) && pres==1)
                            Yaxis.lim = [0 6];
                            Yaxis.freq = 1;
                        else
                            Yaxis.lim = [0 6];
                            Yaxis.freq = 1;
                        end
                    else
                        if any(mspec== [4 64])
                            Yaxis.lim = [-6 8];
                            Yaxis.freq = 0.5;
                        elseif mspec==64
                            Yaxis.lim = [-4 8];
                            Yaxis.freq = 0.5;
                        else
                            Yaxis.lim = [-4 6];
                            Yaxis.freq = 1;
                        end
                    end
                case 14 %% 4q output growth
                    Yaxis.lim = [-5 13];
                    Yaxis.freq = 1;
                case 15 %% Cumulative output growth
                    Yaxis.lim = [-4 26];
                    Yaxis.freq = 2;
                case 16
                    Yaxis.lim = [0 5];
                    Yaxis.freq = 0.5;
                case 17
                    Yaxis.lim = [0 30];
                    Yaxis.freq = 2;
  
            end
        case {'4Q Forecast'}
            switch V_a
                case 1, 
                    Yaxis.lim = [-6 10];
                    Yaxis.freq = 1;
                case 2, 
                    Yaxis.lim = [-15 6];
                    Yaxis.freq = 4;
                case 3	%% labor share
                    Yaxis.lim = [0.50 0.6];
                    Yaxis.freq = 0.02;
                case 4
                    Yaxis.lim = [-1 3.5];
                    Yaxis.freq = 0.5;
                case 5
                    if zerobound
                        Yaxis.lim = [0 5.5];
                        Yaxis.freq = 0.5;
                    end
                case 6	%% consumption in mspec 6, investment in mspec 7
                    if any(mspec== [6 64])
                        Yaxis.lim = [-10 10];
                        Yaxis.freq = 1.5;
                    elseif mspec==7
                        Yaxis.lim = [-40 40];
                        Yaxis.freq = 5;
                    elseif mspec == 16
                        Yaxis.lim = [0 12];
                        Yaxis.freq = 1;
                    elseif any(mspec==[45 450]) % pigap_t
                        Yaxis.lim = [-1 7];
                        Yaxis.freq = 1;
                    elseif any(mspec==[51 510 555 556 557 5571 558])
                        Yaxis.lim = [-3 6];
                        Yaxis.freq = 1;
                    end
                case 7	%% investment in mspec 6
                    if any(mspec==[45 450]) % real r
                        Yaxis.lim = [-4 2];
                        Yaxis.freq = 1;
                    elseif any(mspec==[51 510 555 556 557 5571 558]) % pigap_t
                        Yaxis.lim = [0 14];
                        Yaxis.freq = 2;
                    else
                        Yaxis.lim = [-40 40];
                        Yaxis.freq = 5;
                    end
                case 8
                    if any(mspec==[45 450]) % cumlevel output
                        Yaxis.lim = [-6 10];
                        Yaxis.freq = 1;
                    elseif any(mspec==[51 510 555 556 557 5571 558]) % real r
                        if zerobound
                            Yaxis.lim = [-4 2];
                            Yaxis.freq = 1;
                            if mspec==558
                                Yaxis.lim = [0, 3];
                                Yaxis.freq = 0.5;
                            end
                        else
                            Yaxis.lim = [-6 2];
                            Yaxis.freq = 2;
                        end
                    end
                case 9
                    if any(mspec==[45 450]) % cumlevel inflation
                        Yaxis.lim = [-2 20];
                        Yaxis.freq = 2;
                    elseif any(mspec==[51 510 555 556 557 5571 558]) % cumlevel output
                        Yaxis.lim = [-8 8];
                        Yaxis.freq = 2;
                    end
                case 10 
                    if any(mspec==[51 510 555 556 557 5571 558]) % cumlevel inflation
                        Yaxis.lim = [-3 18];
                        Yaxis.freq = 3;
                    elseif any(mspec==[45]) % cumlevel nominal output
                        Yaxis.lim = [-5 20];
                        Yaxis.freq = 2;
                    end
                case 11
                    if any(mspec==[51 510 555 556 557 5571 558]) % cumlevel nominal output
                        Yaxis.lim = [-4 23];
                        Yaxis.freq = 3;
                    end
                case 12 % unemployment
%                     Yaxis.lim = [5 9];
                    Yaxis.lim = [0 11];
%                     Yaxis.freq = 0.5;
                    Yaxis.freq = 1;
                case 13	%% interest rate
                    if zerobound
                        if mspec==47 || (any(mspec==[45 450 6 82]) && pres==1)
                            Yaxis.lim = [0 6];
                            Yaxis.freq = 1;
                        else
                            Yaxis.lim = [0 6];
                            Yaxis.freq = 1;
                        end
                    else
                        if any(mspec== [4 64])
                            Yaxis.lim = [-6 8];
                            Yaxis.freq = 0.5;
                        elseif mspec==64
                            Yaxis.lim = [-4 8];
                            Yaxis.freq = 0.5;
                        else
                            Yaxis.lim = [-4 6];
                            Yaxis.freq = 1;
                        end
                    end
                case 14 %% 4q output growth
                    Yaxis.lim = [-5 13];
                    Yaxis.freq = 1;
                case 15 %% Cumulative output growth
                    Yaxis.lim = [-4 26];
                    Yaxis.freq = 2;
                case 16
                    Yaxis.lim = [0 5];
                    Yaxis.freq = 0.5;
                case 17
                    Yaxis.lim = [0 30];
                    Yaxis.freq = 2;
  
            end
        case {'Counterfactual','Counterfactual by Variable','Counterfactual by Shock'}
            switch V_a
                case 1 	%% output
                    Yaxis.lim = [-10 10];
                    Yaxis.freq = 4;
                case 2	%% hours
                    Yaxis.lim = [-15 6];
		    %Yaxis.lim = [530 560]; % Use for levels
                    Yaxis.freq = 4;
                    %Yaxis.freq = 5; % Use for levels
                case 3	%% labor share
                    Yaxis.lim = [0.50 0.6];
                    Yaxis.freq = 0.02;
                case 4	%% inflation
                    Yaxis.lim = [-1 5];
                    Yaxis.freq = 2;
                case 5	%% interest rate
                    Yaxis.lim = [-2 7];
                    Yaxis.freq = 2;
                case 6	%% consumption in mspec 6, investment in mspec 7
                    if any(mspec== [6 64])
                        Yaxis.lim = [-10 10];
                        Yaxis.freq = 4;
                    elseif mspec==7
                        Yaxis.lim = [-40 30];
                        Yaxis.freq = 10;
                    elseif mspec == 16
                        Yaxis.lim = [0 12];
                        Yaxis.freq = 2;
                    elseif any(mspec==[51 510 555 556 557 5571 558])
                        Yaxis.lim = [-3 6];
                        Yaxis.freq = 1;
                    end
                case 7	%% investment in mspec 6
                    Yaxis.lim = [-40 30];
                    Yaxis.freq = 10;
                otherwise 
                    Yaxis.lim = [-40 30];
                    Yaxis.freq = 10;
            end
            
        case {'Shock Decomposition','Shock Decomposition-noDet'}
            switch V_a
                case 1 	%% output
                    if any(mspec== [4 47])
                        Yaxis.lim = [-10 8];
                    elseif any(mspec==[45 450 6 82]) && pres==1
                        Yaxis.lim = [-11 10];
                    else
                        Yaxis.lim = [-12 10];
                    end
                    Yaxis.freq = 2;
                    if any(mspec==[555 556 557 5571 558])
                        Yaxis.lim = [-12 5];
                    end
                case 2	%% hours
                    if any(mspec==[6 7 64])
                        Yaxis.lim = [-10 6];
                        %Yaxis.lim = [-10 15]; % Use for levels
                    elseif any(mspec==[45 450 6 82]) && pres==1
                        Yaxis.lim = [-11 6];
                        %Yaxis.lim = [-10 15]; % Use for levels
                    elseif mspec==50
                        Yaxis.lim = [-9 8];
                        %Yaxis.lim = [-10 15]; % Use for levels
                    else
%                         Yaxis.lim = [-8 6];
                        Yaxis.lim = [-9 6]; % for comparison with model 51 in newsletter
                        %Yaxis.lim = [-10 15]; % Use for levels
                    end
                    Yaxis.freq = 1;
                    %Yaxis.freq = 5; % Use for levels
                case 3	%% labor share
%                     if any(mspec==[6 7 64])
%                         Yaxis.lim = [-0.13 0.04];
%                     elseif mspec==8
%                         Yaxis.lim = [-0.025 0.015];
%                     else
%                         Yaxis.lim = [-0.03 0.02];
%                     end
%                     Yaxis.freq = 0.01;
                        Yaxis.lim = [-4 3];
                        Yaxis.freq = 0.5;
                case 4	%% inflation
                    if any (mspec ==[6 7 47])
                        Yaxis.lim = [-4 4];
                    elseif mspec ==64
                        Yaxis.lim =[-4 3];
                    elseif mspec==4
                        Yaxis.lim = [-3 4];
                    elseif mspec==8
                        Yaxis.lim = [-2.5 2];
                    else
                        Yaxis.lim = [-2 2];
                    end
                    Yaxis.freq = 1;
                case 5	%% interest rate
                    if any (mspec ==[6 7 64])
                        Yaxis.lim = [-6 3];
                    elseif mspec==47
                        if zerobound
                            Yaxis.lim = [-8 8];
                        else
                            Yaxis.lim = [-8 5];
                        end
                    elseif any(mspec==[45 450 6 82]) && pres==1
                        Yaxis.lim = [-6.5 2];
                    elseif mspec==8
                        Yaxis.lim = [-7 4];
                    else
                        Yaxis.lim = [-5 2];
                    end
                    Yaxis.freq = 1;
                case 6	%% consumption in mspec 6, investment in mspec 7
                    if any(mspec== [6 64])
                        Yaxis.lim = [-13 4];
                        Yaxis.freq = 1.5;
                    elseif mspec==7
                        Yaxis.lim = [-40 15];
                        Yaxis.freq = 5;
                    elseif mspec == 16
                        Yaxis.lim = [-3 6];
                        Yaxis.freq = 1;
                    elseif any(mspec==[51 510 555 556 557 5571 558])
                        Yaxis.lim = [-1 5];
                        Yaxis.freq = 1;
                    end
                case 7	%% investment in mspec 6
                    Yaxis.lim = [-40 15];
                    Yaxis.freq = 5;
                case 8
                    Yaxis.lim = [-1 1];
                    Yaxis.freq = 0.25;
            end
        case {'Shock'}
            Yaxis.lim = [-4,4];
            if any(mspec==[51 510 555 556 557 5571 558]) && V_a==7
                Yaxis.lim = [-7,7];
            end
            if system
                Yaxis.freq = 1;
            else
                Yaxis.freq = 0.5;
            end
        case {'ShockAnt'}
            Yaxis.lim = [-0.4,0.2];
            if system
                Yaxis.freq = 0.1;
            else
                Yaxis.freq = 0.1;
            end
        case {'Shock Squared','Htil','Eta Squared','Sigma'}
            Yaxis.lim = [];
        case 'ImpObs'
            if V_a == 8
                Yaxis.lim = [-30 40];
                Yaxis.freq = 10;
            else Yaxis.lim = [];
            end
        otherwise
            Yaxis.lim = [];
    end
else Yaxis.lim = [];
end

end
