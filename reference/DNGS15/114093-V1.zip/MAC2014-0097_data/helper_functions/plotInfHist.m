
spec_904_aux_full201250;
forecast_vintage_aux_2model;
forplot_vint_aux;

if auxFlag
    % update auxilary var data with smoothed state "actuals"
    loadParams;
    para = priotheta;
    state_file =['states',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr{peachflag+1},num2str(jstep),parstr];
    eval(['[YY,stateFinals,auxCount] = auxUpdateYY',num2str(mspec),'(YY,state_file,mspec,nlags,nstate,dataset,para, para);']);
end
Ys = getYs(YY(1:Idate,:),YY_p,dlpop,dlpop_p,cum_for,popadj,nvar,0,q_adj,0);

inf_ind = find(strcmp(varnames,'GDP Deflator'));
mrkup_ind = find(strcmp(shocksnames,'\lambda_f'));
kSt_ind = find(strcmp(varnames,'\kappa (1+\iota_p\bar{\beta}) S^{\infty}_t'));
Y1 = Ys;
Y2 = squeeze(Means.counter(:,1:size(tiI,1),1,mrkup_ind))';

if mspec == 904
    [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,ppsi,nu_l,zeta_w,iota_w,law,laf,bet,Rstarn,psi1,psi2,psi3,pistar,sigmac,rho,epsp,epsw...
        gam,Lmean,Lstar,gstar,rho_g,rho_b,rho_mu,rho_z,rho_laf,rho_law,rho_rm,rho_sigw,rho_mue,rho_gamm,rho_pist...
        sig_g,sig_b,sig_mu,sig_z,sig_laf,sig_law,sig_rm,sig_sigw,sig_mue,sig_gamm,sig_pist,eta_gz,eta_laf,eta_law...
        zstar,rstar,rkSt_indar,wstar,wl_c,cstar,kSt_indar,kbarstar,istar,ystar,sprd,zeta_spb,gammstar,vstar,nstar,...
        zeta_nRk,zeta_nR,zeta_nsigw,zeta_spsigw,zeta_nmue,zeta_spmue,zeta_nqk,zeta_nn] = getpara00_904(para);
elseif mspec == 805
    [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,ppsi,nu_l,zeta_w,iota_w,law,laf,bet,Rstarn,psi1,psi2,psi3,pistar,sigmac,rho,epsp,epsw...
        gam,Lmean,Lstar,gstar,rho_g,rho_b,rho_mu,rho_z,rho_laf,rho_law,rho_rm,rho_pist...
        sig_g,sig_b,sig_mu,sig_z,sig_laf,sig_law,sig_rm,sig_pist,eta_gz,eta_laf,eta_law...
        zstar,rstar,rkSt_indar,wstar,wl_c,cstar,kSt_indar,kbarstar,istar,ystar,pistflag] = getpara00_805(para);
elseif mspec == 803
    [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,ppsi,nu_l,zeta_w,iota_w,law,laf,bet,Rstarn,psi1,psi2,psi3,pistar,sigmac,rho,epsp,epsw...
        gam,Lmean,Lstar,gstar,rho_g,rho_b,rho_mu,rho_z,rho_laf,rho_law,rho_rm,...
        sig_g,sig_b,sig_mu,sig_z,sig_laf,sig_law,sig_rm,eta_gz,eta_laf,eta_law...
        zstar,rstar,rkSt_indar,wstar,wl_c,cstar,kSt_indar,kbarstar,istar,ystar] = getpara00_802(para);
else
    error(['plotInfHist.m doesn''t support model ',num2str(mspec)]);
end

pitilde = nan(size(Y1,1),1);
for i = 4:size(pitilde,1)
    pitilde(i) = Y1(i,kSt_ind) + iota_p*Y1(i-1,kSt_ind) ...
        + iota_p^2*Y1(i-2,kSt_ind) + iota_p^3*Y1(i-3,kSt_ind);
end

pitilde_ctr = nan(size(Y2,1),1);
for i = 4:size(pitilde_ctr,1)
    pitilde_ctr(i) = Y2(i,kSt_ind) + iota_p*Y2(i-1,kSt_ind) ...
        + iota_p^2*Y2(i-2,kSt_ind) + iota_p^3*Y2(i-3,kSt_ind);
end

fname = 'data/cpce.txt';
cpce = importdata(fname);

f = figure();
% fund. inflation
plot(ti,pitilde/4 + 100*(pistar-1),'b');
hold on;
% gdpdef
plot(ti,Y1(:,inf_ind)/4,'k');
% cpce
plot(ti,cpce-mean(cpce)+100*(pistar-1),'g');
% gdpdef - less markup
plot(ti,Y2(:,inf_ind)/4,'b--');

legend('Fund. Infl.', 'GDPDEF','CPCE','GDPDEF - markup');

if ~exist(gpath,'dir'), mkdir(gpath); end
saveas(f,[gpath,'PITILvsGDPDEFvsCPCEvsGDPDEF-MRKUP',num2str(mspec),'.pdf'])
success=1;
