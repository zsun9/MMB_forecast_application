function [ZZ_,DD_,TTT_,RRR_,CCC_,sm_states,zend,varargout] = calcImplied(mspec,ZZ,DD,TTT,RRR,CCC,para,impVar,YY0,sm_states_all,zend,peachflag,varargin)
          
%% Get parameters
if any(mspec==[51,611]),
    [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,a2,nu_l,nu_m,zeta_w,iota_w,law,rstar,psi1,psi2,rho_r,pistar,...
        Fom,sprd,zeta_spb,gammstar,NEW_5,...
        gam,Lstar,chi,laf,gstar,Ladj,...
        rho_z,rho_phi,rho_chi,rho_laf,rho_mu,rho_b,rho_g,rho_sigw,rho_mue,rho_gamm,...
        sig_z,sig_phi,sig_chi,sig_laf,sig_mu,sig_b,sig_g,sig_r,sig_sigw,sig_mue,sig_gamm,...
        bet,zstar,phi,istokbarst,rkstar,cstar,ystar,istar,kstar,kbarstar,Rstarn,wstar,wadj,mstar,...
        zeta_nRk, zeta_nR, zeta_nqk, zeta_nn, zeta_nmue, zeta_spmue, zeta_nsigw, zeta_spsigw, ...
        vstar,nstar] = getpara00_51(para);
    
elseif any(mspec==[517,601:604]),
    [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,a2,nu_l,nu_m,zeta_w,iota_w,law,rstar,psi1,psi2,rho_r,pistar,...
        Fom,sprd,zeta_spb,gammstar,NEW_5,mu_i,...
        gam,Lstar,chi,laf,gstar,Ladj,...
        rho_z,rho_phi,rho_chi,rho_laf,rho_mu,rho_b,rho_g,rho_sigw,rho_mue,rho_gamm,...
        sig_z,sig_phi,sig_chi,sig_laf,sig_mu,sig_b,sig_g,sig_r,sig_sigw,sig_mue,sig_gamm,...
        bet,zstar,phi,istokbarst,rkstar,cstar,ystar,istar,kstar,kbarstar,Rstarn,wstar,wadj,mstar,...
        zeta_nRk, zeta_nR, zeta_nqk, zeta_nn, zeta_nmue, zeta_spmue, zeta_nsigw, zeta_spsigw, ...
        vstar, nstar] = getpara00_517(para);
else
    error('Specify getpara file')
end

%% Create alternative measurement equation matrices

nimpVar = length(impVar);
ZZ_ = ZZ;
DD_ = DD;
TTT_ = TTT; 
RRR_ = RRR; 
CCC_ = CCC; 

nobs = size(ZZ,1);
nstate = size(sm_states_all,1);
eval(['states',num2str(mspec)]);

sm_states = sm_states_all(:,size(YY0,1)+1:end);
if peachflag
    sm_states_all_peach = varargin{1}; 
    zend_peach = varargin{2}; 
    sm_states_peach = sm_states_all_peach(:,size(YY0,1)+1:end);
end

AddTTT = zeros(nimpVar,size(TTT,2));

for iAlt = 1:nimpVar
    
    switch impVar{iAlt}
        case 'c_t'
            c_t1 = nstate+iAlt;
            
            sm_states(nstate+iAlt,:) = [sm_states_all(c_t,size(YY0,1)),sm_states(c_t,1:end-1)];
            zend(nstate+iAlt) = sm_states_all(c_t,end-1);
            if peachflag
                sm_states_peach(nstate+iAlt,:) = [sm_states_all_peach(c_t,size(YY0,1)),sm_states_peach(c_t,1:end-1)];
                zend_peach(nstate+iAlt) = sm_states_all_peach(c_t,end-1);
            end
            
            ZZ_(nobs+iAlt,c_t) = 4;
            ZZ_(nobs+iAlt,c_t1) = -4;
            ZZ_(nobs+iAlt,z_t) = 4;
            DD_(nobs+iAlt) = 400*(gam+(alp*log(ups)/(1-alp)));
            
            AddTTT(iAlt,c_t) = 1;
            
        case 'i_t'
            i_t1 = nstate+iAlt;
            
            sm_states(nstate+iAlt,:) = [sm_states_all(i_t,size(YY0,1)),sm_states(i_t,1:end-1)];
            zend(nstate+iAlt) = sm_states_all(i_t,end-1);
            if peachflag
                sm_states_peach(nstate+iAlt,:) = [sm_states_all_peach(i_t,size(YY0,1)),sm_states_peach(i_t,1:end-1)];
                zend_peach(nstate+iAlt) = sm_states_all_peach(i_t,end-1);
            end
            
            ZZ_(nobs+iAlt,i_t) = 4;
            ZZ_(nobs+iAlt,i_t1) = -4;
            ZZ_(nobs+iAlt,z_t) = 4;
            DD_(nobs+iAlt) = 400*(gam+(alp*log(ups)/(1-alp)));
            
            AddTTT(iAlt,i_t) = 1;
    end    
end

TTT_ = [[TTT_,zeros(size(TTT_,1),nimpVar)];[AddTTT,zeros(nimpVar)]];
RRR_ = [RRR_ ; zeros(nimpVar,size(RRR_,2))];
CCC_ = [CCC_ ; zeros(nimpVar,size(CCC_,2))]; 

if peachflag
    varargout{1} = sm_states_peach;
    varargout{2} = zend_peach;
end
