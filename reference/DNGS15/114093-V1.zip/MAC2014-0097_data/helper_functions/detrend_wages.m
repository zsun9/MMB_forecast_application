function YY = detrend_wages(YY,mspec,para,varnames,dt_vec,dt)

if mspec == 904

    [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,ppsi,nu_l,zeta_w,iota_w,law,laf,bet,Rstarn,psi1,psi2,psi3,pistar,sigmac,rho,epsp,epsw...
        gam,Lmean,Lstar,gstar,rho_g,rho_b,rho_mu,rho_z,rho_laf,rho_law,rho_rm,rho_sigw,rho_mue,rho_gamm,rho_pist...
        sig_g,sig_b,sig_mu,sig_z,sig_laf,sig_law,sig_rm,sig_sigw,sig_mue,sig_gamm,sig_pist,eta_gz,eta_laf,eta_law...
        zstar,rstar,rkstar,wstar,wl_c,cstar,kstar,kbarstar,istar,ystar,sprd,zeta_spb,gammstar,vstar,nstar,...
        zeta_nRk,zeta_nR,zeta_nsigw,zeta_spsigw,zeta_nmue,zeta_spmue,zeta_nqk,zeta_nn] = getpara00_904(para);

else
    
    error('GET A DIFFERENT MSPEC, BROOO!');

end



gamma = 100*(exp(zstar)-1);

w_i  = strcmp(varnames,'Real Wage Growth');
dt_i = find(dt_vec == dt);

w_mean = mean(YY(dt_i:end,w_i));

YY(dt_i:end,w_i) = YY(dt_i:end,w_i) - w_mean + gamma;