function priotheta = paramSelector(modelSpec, paramSpecFile,...
    paramFile, para_names, para, para_mask, npara, nsim, replaceBlock)


fid.mhpara = fopen(paramFile);

if strcmp(paramSpecFile,'')
    priotheta = fread(fid.mhpara,[npara,nsim],'single')';
else
    nparaSource = getSpec(paramSpecFile,'npara');
    priotheta = fread(fid.mhpara,[nparaSource,nsim],'single')';
    priotheta = mapParams(modelSpec,para_names,para,para_mask,...
        priotheta,paramSpecFile);
end

if ~isempty(replaceBlock)
    for i = 1: size(replaceBlock,1)
        p = replaceBlock(i,:);
        priotheta(int8(p(1))) = p(2);
    end
end