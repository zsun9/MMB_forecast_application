function [fcast_d, resid_fd] = forecast_decomp(ZZ,DD,CCC_Tf,TTT_Tf,RRR_Tf,shocks_Tf,zend_Tf,semicond,varargin)

if nargin == 9
    resid_0 = varargin{1};
end

T = size(shocks_Tf,2);
k = size(ZZ,1);
fcast_d = NaN(k,T);
resid_fd = NaN(k,T);

z = zend_Tf;
r = resid_0;
for i_ = 1:T 
    
    r = TTT_Tf(:,:,i_)*r;
    
    if semicond && i_ == 1
        z = z + RRR_Tf(:,:,i_)*shocks_Tf(:,i_);
    else
        z = CCC_Tf(:,:,i_) + TTT_Tf(:,:,i_)*z + RRR_Tf(:,:,i_)*shocks_Tf(:,i_);
    end
    
    resid_fd(:,i_) = ZZ*r;
    fcast_d(:,i_) = DD + ZZ*z;
end

