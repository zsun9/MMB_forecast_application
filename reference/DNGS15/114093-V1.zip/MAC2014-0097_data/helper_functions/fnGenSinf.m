function [Sinf_all] = fnGenSinf(ti,Y1,Y2,St,para,mspec)

Sinf = Y1(:,St);

Sinf_ctr = Y2(:,St);


Sinf_all = [ Sinf, Sinf_ctr];
