function [dates, mc_return] = fnMcEvol( specFile, hairType, replaceBlock, sdate, edate, h1, varargin )

if nargin == 7
    h2 = varargin{1};
elseif nargin == 8
    h2 = varargin{1};
    h3 = varargin{2};
end

if ~strcmp(hairType,'')
    hairType = ['_',hairType];
end

eval([specFile,';']);
haircompare = 1;
forecast_vintage_aux_2model;

load([spath,'hairs/hairplots_mc',hairType,'_alt_',num2str(mspec),'_',num2str(tiI(end)*100),'.mat']);

T = edate - sdate + 1;

if exist('h3','var')
    mc_return = nan(T,4);
elseif exist('h2','var')
    mc_return = nan(T,3);
else
    mc_Retur = nan(T,2);
end

mc_return(:,1) = hair(1,sdate:edate);
mc_return(:,2) = hair(h1,sdate:edate);

if exist('h2','var')
    mc_return(:,3) = hair(h2,sdate:edate);
end

if exist('h3','var')
    mc_return(:,4) = hair(h3,sdate:edate);
end

dates = ti(sdate):0.25:ti(sdate)+(edate-sdate)*0.25;

