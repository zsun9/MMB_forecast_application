function [varargout] = getSpec(specFile,varName)

eval([specFile,';']);
spec;
eval(['varargout{1}=',varName,';']);
