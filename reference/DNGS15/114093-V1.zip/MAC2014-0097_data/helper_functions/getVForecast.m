function [yypred] = getVForecast(qahead,nvar,nshocks,TTT,RRR,DD,ZZ,QQ,z,sflag)
                              
%% Check inputs      
if nargin ~= 10; error('Ten inputs required'); end

%% Initialize output
yypred = zeros(qahead,nvar);

%% Draw shocks for forecasting
Shocks = repmat(sqrt(diag(QQ)'),qahead,1).*randn(qahead,nshocks);

%TURN SHOCKS OFF
if sflag
    Shocks=zeros(size(Shocks));
end

%% Calculate forecast 
% Applying state transition equation and measurement equation 
% S_t = TTT*S_(t-1) + RRR*eps_t
% y_t = ZZ*S_t + DD

for t = 1:qahead;
    z = TTT*z+RRR*Shocks(t,:)';
    yypred(t,:) = (DD+ZZ*z)';
end