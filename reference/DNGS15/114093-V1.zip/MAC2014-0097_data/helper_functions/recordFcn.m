% Record numbers plotted
function [record] = recordFcn(plotType,record,V_1,V_a,peachcount,...
                              tiall,Startdate,stime,qahead,...
                              varnames,fid0,finalRecord,varargin)
                          
    
    if V_1==1, j=1; else j=0; end % Applies to everything except Counterfactual by Shock and Counterfactual by Var
    
    switch plotType 
          
        case 'Forecast'
            bandsp = varargin{1}; 
            mlp = varargin{2}; 
            
            switch peachcount
                case 1, record(end+j).type = 'Conditional Forecast';
                case 0, record(end+j).type = 'Unconditional Forecast';
            end
            record(end).labels = {'dates','90%LB','80%LB','70%LB','60%LB','50%LB','50%UB','60%UB','70%UB','80%UB','90%UB','mean'};
            record(end).data(:,:,V_a) = [tiall(Startdate:(stime+qahead),:),bandsp(Startdate:end,:),mlp(Startdate:end)];                
    end

if finalRecord
    
    % Record plotted data
    for k = 1:length(record)
        fprintf(fid0,'%s \n\n', record(k).type);
        for v = 1:size(record(k).data,3)
            fprintf(fid0,'%s \n', char(varnames(v)));
            fprintf(fid0,'%s ', record(k).labels{:});
            fprintf(fid0,' \n');
            for a = 1:size(record(k).data,1)
                eval(['fprintf(fid0, ''' repmat(' %4.5f',1,size(record(k).data,2)) ' \n '' ,[record(k).data(a,:,v)]);']);
            end
            fprintf(fid0,' \n \n');
        end
    end
end


end
