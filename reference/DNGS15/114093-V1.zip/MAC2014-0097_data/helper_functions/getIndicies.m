function [states,shocks,expShocks] = getIndicies(mspec)
    

eval(['states',num2str(mspec),';']);

list = who;

shocks = struct('varName',{{}},'index',{[]});
states = struct('varName',{{}},'index',{[]});
expShocks = struct('varName',{{}},'index',{[]});

for ii = 1:length(list)
    var = list{ii};

    if strcmp(var(end-1:end),'_t') || strcmp(var(end-2:end),'_t1') || strcmp(var(end-1:end),'_f') || (strcmp(var(1:2),'E_') && ~strcmp(var(end-1:end),'_sh'))
        index = eval(eval('var'));
        states.varName{end+1} = var;
        states.index(end+1) = index;
    elseif strcmp(var(end-2:end),'_sh') && ~strcmp(var(1),'E')
        index = eval(eval('var'));
        shocks.varName{end+1} = var;
        shocks.index(end+1) = index;
    elseif strcmp(var(end-2:end),'_sh') && strcmp(var(1),'E')
        index = eval(eval('var'));
        expShocks.varName{end+1} = var;
        expShocks.index(end+1) = index;
    end
end