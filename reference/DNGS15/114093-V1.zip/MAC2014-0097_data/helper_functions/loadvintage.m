vintage=vintend;

for i=1:length(vintage)
    if compound==1
      vintage(i).final=vintage(i).cfinal;
      vintage(i).lsharefinal=vintage(i).lsharecfinal;
    elseif first==1
      vintage(i).final=vintage(i).ffinal;
      vintage(i).lsharefinal=vintage(i).lshareffinal;
    else 
      vintage(i).final=vintage(i).rfinal;
      vintage(i).lsharefinal=vintage(i).lsharerfinal;
   end;

    if any(mspec==[804 809]);%dump long term inf
         vintage(i).series(:,end-1:end)=[];
    elseif any(mspec==[805 8051 905]);%dump spread, long term gdp
         vintage(i).series(:,[end-2,end])=[];
         vintage(i).final(:,end-1)=[];
         vintage(i).lastpoint(end)=[];
    elseif any(mspec==[305 303]);%dump spread
         vintage(i).series(:,end-2)=[];
         vintage(i).final(:,end-1)=[];
         vintage(i).lastpoint(end)=[];
     elseif mspec==514;%dump consumption, investment, and long term gdp, put in labor share
         vintage(i).series=[vintage(i).series(:,1:2),vintage(i).lshare,vintage(i).series(:,[4:5 8:end-1])];
         vintage(i).final=[vintage(i).final(:,1:2),vintage(i).lsharefinal,vintage(i).final(:,[4:5 8:end])];
         vintage(i).lastpoint=[vintage(i).lastpoint(:,1:2),vintage(i).lshare(end),vintage(i).lastpoint(:,[4:5 8:end])];
    elseif mspec==904;%dumplong term gdp
         vintage(i).series(:,end)=[];        
    elseif mspec==304;%keep everything
    else%dump long term inf,gdp and spread
        vintage(i).series(:,end-2:end)=[];
        vintage(i).final(:,end-1)=[];
        vintage(i).lastpoint(end)=[];
    end
    % Adding Auxilary vars
    
    if auxFlag && exist('bolUseFinals','var')
        eval(['[vintage(i), jvint] = auxLoaddata',num2str(mspec),'(vintage(i),jvint,ovint,qvint,nlags,bolUseFinals);']);
    else
        eval(['[vintage(i), jvint] = auxLoaddata',num2str(mspec),'(vintage(i),jvint,ovint,qvint,nlags);']);
    end

end
vintend=vintage;