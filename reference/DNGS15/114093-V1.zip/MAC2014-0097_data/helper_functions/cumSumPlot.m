                    % MAKE GDP NOMINAL
%                     if V_a == 1 && ngdpFlag == 1
%                         Means.forecast(V_a,:,peachcount+1) = Means.forecast(V_a,:,peachcount+1)+Means.forecast(4,:,peachcount+1);
%                         vintend.final(:,V_a) = vintend.final(:,V_a) + vintend.final(:,4);
%                         Bands.forecast(:,V_a,:,peachcount+1) = Bands.forecast(:,V_a,:,peachcount+1) + Bands.forecast(:,4,:,peachcount+1);
%                     end

                    % Mean
                    mlp = cumsum([Ys(1:end,V_a);squeeze(Means.forecast(V_a,:,peachcount+1))']);
                    mlp = mlp - mlp(sirf(1),1);
    
                    % Bands
                    num_bands = 2 + 8*fancharts;
                    bandsp = [NaN*repmat(Ys(1:end-1,V_a),[1 num_bands]);zeros(1,num_bands);cumsum(squeeze(Bands.forecast(:,V_a,:,peachcount+1)),2)'];
                    
                    LBands(V_a,:) =  bandsp(sirf,1)';
                    UBands(V_a,:) =  bandsp(sirf,2)';
                    
                    % Record data plotted
                   
                    if overwrite
                            [record] = recordFcn(plotType,record,V_idx,V_a,peachcount,tiall,Startdate,stime,qahead,varnames,fid0,0,...
                                bandsp,mlp);
                    end
                    
                    
                    % Forecast
                    P = plot(sirf,mlp(sirf),'r-');
                    set(P,'LineWidth',line.width);
                    
                    hold on;    
                    
                    % Actual data
                    mn=min(size(vintend.final,1),qahead);
                    bn=min(length(jvint.fdate),qahead);
                    
                    t_I = size(mlp,1)-40;
                    
                    %mlp = [Ys(:,V_a);NaN*squeeze(Means.forecast(V_a,:,peachcount+1))'];%estimation sample data
%                     if V_a == 10
%                         flp = [vintend.final(:,V_a);nan(qahead-bn,1)];%finals here
%                         mmlp = [extraOut;;NaN*squeeze(Means.forecast(V_a,:,peachcount+1))']; %model implied state
%                     else
                        flp = [nan(size(Ys,1)-1,1);0;cumsum(vintend.final(:,V_a));nan(qahead-mn,1)];%finals here
                        flp = flp + mlp(t_I,1);
                        
%                     end
%                     blp = [nan(size(Ys,1),1);jvint.forecast(:,V_a);nan(qahead-bn,1)];%judgemental forecast here
                    
                    t_I_sirf = find(t_I==sirf);
                    
                    P = plot(sirf(1:t_I_sirf),mlp(sirf(1:t_I_sirf)),'k-');
                    set(P,'LineWidth',line.width);
                    hold on;
                    
                    P = plot(sirf,flp(sirf),'--k');
                    set(P,'LineWidth',line.width);
                    hold on;

                    hold off;