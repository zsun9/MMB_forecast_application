function [data] = getData( specFile, ind )

eval([specFile,';']);
spec_realtime;
sflag=1;
initializePrograms;
Ys = getYs(YY(1:Idate,:),YY_p,dlpop,dlpop_p,cum_for,popadj,nvar,0,q_adj,0);

data = Ys(:,ind)/4;