if exist('useRtParallelResults','var') && useRtParallelResults
    % List data to be read in
    
    %     load(strcat(spath,'/realtime/realtime_parallel_FULL_',judge,'_estimationResults_1_',lmodel,lprior,ds,num2str(stime),'_',num2str(100*vintage(1).odate(end)),'-',num2str(100*vintage(1).fdate(end)),'.mat'),'EstOut');
    %     load(strcat(spath,'/realtime/realtime_parallel_FULL_',judge,'_estimationResults_1_',lmodel,lprior,ds,'_',num2str(100*vintage(1).odate(end)),'-',num2str(100*vintage(1).fdate(end)),'.mat'),'EstOut');
    load(strcat(spath,'/realtime/realtime_parallel_MODE_',judge,'_estimationResults_1_',lmodel,lprior,ds,'_',num2str(100*vintage(1).odate(end)),'-201100.mat'),'EstOut');
    
    if bolUseFinals==1
        opts=EstOut(strcmp(EstOut(:,end)',vintage(71).date),:);
    else
        opts=EstOut(strcmp(EstOut(:,end)',vintend.date),:);
    end
    priotheta=opts{:,1}';
    %priotheta=opts{:,5};
    %nsim=length(priotheta);
    
else
    
    if exist('paramDate','var') && bolUseFinals == 1
        infile.mhpara = [spath,'mhpara',lmodel,lprior,ds,num2str(100*paramDate),num2str(nlags),num2str(T0),pargibbstr,parstr];
    else
        infile.mhpara = [spath,'mhpara',lmodel,lprior,ds,num2str(100*ti(I)),num2str(nlags),num2str(T0),pargibbstr,parstr];
    end
   
    if ~exist('replaceBlock','var'); replaceBlock = []; end
    if ~exist('paramSpecFile','var'); paramSpecFile = ''; end
    if ~exist('paramFile','var'); paramFile = infile.mhpara; end
    
    priotheta = paramSelector(mspec,paramSpecFile, paramFile, para_names, para, para_mask, npara, nsim, replaceBlock);
 
    if exist('haircompare','var') && haircompare
        fidOriginal = fopen(infile.mhpara,'r');
        originalTheta = fread(fidOriginal, 'single')';
    else
        originalTheta = priotheta;
    end
    
    if exist('swapKapSSS','var') && swapKapSSS
        tmp = originalTheta;
        originalTheta = priotheta;
        priotheta = tmp;
    end
    
end