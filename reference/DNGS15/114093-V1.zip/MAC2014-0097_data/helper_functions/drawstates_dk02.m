function [alpha_til,eta_til] = drawstates_dk02(y,T,R,Q,Z,b,A0,P0,nant,antlags,peachcount,psize,Ny0)

% DRAWSTATES_DK02.M

% This program is a simulation smoother based on Durbin and Koopman's 
% "A Simple and Efficient Simulation Smoother for State Space Time Series 
% Analysis" (Biometrika, 2002). The algorithm has been simplified for the 
% case in which there is no measurement error, and the model matrices do 
% not vary with time.

% Unlike other simulation smoothers (for example, that of Carter and Kohn,
% 1994), this method does not require separate draws for each period, draws
% of the state vectors, or even draws from a conditional distribution.
% Instead, vectors of shocks are drawn from the unconditional distribution
% of shocks, which is then corrected (via a Kalman Smoothing step), to
% yield a draw of shocks conditional on the data. This is then used to
% generate a draw of states conditional on the data. Drawing the states in
% this way is much more efficient than other methods, as it avoids the need
% for multiple draws of state vectors (requiring singular value
% decompositions), as well as inverting state covariance matrices
% (requiring the use of the computationally intensive and relatively
% erratic Moore-Penrose pseudoinverse).

% Nz will stand for the number of states, Ny for the number of observables,
% Ne for the number of shocks, and Nt for the number of periods of data.

% The state space is assumed to take the form:
% y(t) = Z*alpha(t) + b
% alpha(t+1) = T*alpha(t) + R*eta(t+1)

% INPUTS:

% y, the (Ny x Nt) matrix of observable data.
% T, the (Nz x Nz) transition matrix.
% R, the (Nz x Ne) matrix translating shocks to states.
% Q, the (Ne x Ne) covariance matrix for the shocks.
% Z, the (Ny x Nz) measurement matrix.
% b, the (Ny x 1) constant vector in the measurement equation.
% A0, the (Nz x 1) initial (time 0) states vector.
% P0, the (Nz x Nz) initial (time 0) state covariance matrix.

% nant, an optional scalar for the zero bound specification indicating the 
%       number of periods ahead the interest rate is fixed.
% antlags, an optional scalar for the zero bound specification indicating
%       the number of periods for which interest rate expectations have
%       been fixed
% Ny0, an optional scalar indicating the number of periods of presample
%       (i.e. the number of periods for which smoothed states are not
%       required). If you want to set a value for Ny0 but not for nant or
%       antlags then set them both empty.

if nargin < 10, error('At least ten inputs required'); end
if nargin == 11, error('Zero, two, or three optional inputs required'); end
if nargin > 13, error('At most 13 inputs allowed'); end

Ny = size(y,1);
Ne = size(R,2);
Nt = size(y,2);
Nz = length(T);

%% Draw a sequence of eta+
eta_plus = sqrt(Q)*randn(Ne,Nt);
%% Set nant, antlags shocks to 0 for zerobound time periods
if exist('nant','var') && exist('antlags','var')
    if nant > 0
        % eta_plus(end-nant+1:end,1:end-antlags-1) = 0;
        eta_plus(end-nant+1:end,1:end-antlags-(peachcount*psize+1)) = 0;
    end
end

%% Draw a sequence of y+
%% Draw initial state a_0+ (Eq. 4)
[U,D,V] = svd(P0);
ap_t = U*sqrt(D)*randn(Nz,1);

alpha_plus = zeros(Nz,Nt);
y_plus = zeros(Ny,Nt);

% alpha_plus(:,1) = ap_t;
% y_plus(:,1) = Z*ap_t;

%% Draw states a+ and y+ (Eq. 1, 2, 3)
for t = 1:Nt
    ap_t = T*ap_t + R*eta_plus(:,t);
    alpha_plus(:,t) = ap_t;
    y_plus(:,t) = Z*ap_t;
end

%% Compute y* = y - y+ - b
y_star = y - y_plus - repmat(b,1,Nt);

var = zeros(Ny+Nz,Ny+Nz);
var(1:Nz,1:Nz) = R*Q*R';

%% Compute filtered state using Kalman Filter
[L,zend,Pend,pred_star,vpred_star] = kalcvf2NaN(y_star,0,zeros(Nz,1),T,zeros(Ny,1),Z,var,zeros(Nz,1),P0);

%% Compute smoothed state using Koopman Smoother
[alpha_hat_star,eta_hat_star] = kalsmth_k93(A0,P0,y_star,pred_star,vpred_star,T,R,Q,Z,zeros(Ny,1),nant,antlags,peachcount,psize);

%% Compute draw (states and shocks) 
alpha_til = alpha_plus + alpha_hat_star;
eta_til = eta_plus + eta_hat_star;

if ~exist('Ny0','var'), Ny0 = 0; end

if Ny0 > 0
    alpha_til = alpha_til(:,Ny0+1:end);
    eta_til = eta_til(:,Ny0+1:end);
end
