function dettrend_all = getdettrend_fullHist(Enddate_forecastfile,nvar,ZZ_,TTT_,DD,z0T,Startdate,peachflag)

dettrend_all = zeros((Enddate_forecastfile)*nvar,peachflag+1);

for peachcount = 0:peachflag
    
    z = z0T(:,peachcount+1);
    
    dettrend = zeros(Enddate_forecastfile,nvar);
    for t = 1:Enddate_forecastfile
        dettrend(t,:) = (DD + ZZ_*(TTT_^t)*z)';
    end

    dettrend_all(:,peachcount+1) = dettrend(:)';
    
end