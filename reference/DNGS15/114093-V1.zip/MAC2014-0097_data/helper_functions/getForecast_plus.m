function [yypred] = getForecast_plus(qahead,nvar,nshocks,Tcal,Rcal,Ccal,DD,ZZ,QQ,z,Tbar, num_z, nant)
                              

%% Initialize output

yypred = zeros(qahead,nvar);

%% Draw shocks for forecasting
%nshocks = nshocks - nant;
QQ = QQ(1:nshocks,1:nshocks);
Shocks = repmat(sqrt(diag(QQ)'),qahead,1).*randn(qahead,nshocks);
Shocks = zeros(size(Shocks));

%% Calculate forecast 

%taking out the expectations from the smooth states
%z = [z(1:num_z);z(end)]; 
%ZZ(:,num_z+1:end-1) = [];

%using the Tcal and Rcal for the transition equations
for t = 1:Tbar;
    z = Ccal(:,t) + Tcal(:,:,t)*z+Rcal(:,:,t)*Shocks(t,:)';
    yypred(t,:) = (DD+ZZ*z)';
%     z(10)
%     z(10)*4 + 400*log(Rstarn)
end

for t= Tbar+1 :qahead
    z = Ccal(:,end) + Tcal(:,:,end)*z+Rcal(:,:,end)*Shocks(t,:)';
    yypred(t,:) = (DD+ZZ*z)';
end
stop = 1;



