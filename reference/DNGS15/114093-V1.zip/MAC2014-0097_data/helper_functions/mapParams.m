function [paramsTarget] = mapParams(mspecTarget, paraNamesTarget, defaultParamsTarget, paraMaskTarget, paramsSource, specFileSource)

[paraNamesSource] = getSpec(specFileSource,'para_names');    % get source model para_names

paramsTarget = nan(1,length(paraNamesTarget));  % create empty array to hold new params vector

for pIdx = 1:length(paraNamesSource)            % map params: original --> target
    pmodIdx = find(strcmp(paraNamesTarget,paraNamesSource(pIdx)), 1);
    if(~isempty(pmodIdx))
        paramsTarget(pmodIdx) = paramsSource(pIdx);
    end
end

for k = 1:length(paramsTarget)
    sourceIndex = find(strcmp(paraNamesSource,paraNamesTarget(k)), 1);
    if isnan(paramsTarget(k)) && isempty(sourceIndex)
        if paraMaskTarget(k)
            fixed = 'fixed';
        else
            fixed = 'not fixed';
        end
        
        reply = input([paraNamesTarget{k},' does not appear in source model. ',...
                      'It is ',fixed,' in model ',num2str(mspecTarget),'.',...
                      ' Do you want to use the value in mspec_parameters? Y/N [Y]: '], 's');
        
        if isempty(reply)
            reply = 'Y';
        end
        
        if strcmp(reply,'Y')
            paramsTarget(k) = defaultParamsTarget(k);
        else
            reply = input(['Please enter a parameter value for ', paraNamesTarget(k),...
                ' or press ENTER to exit.'], 'double');
            if ~isempty(reply)
                paramsTarget(k) = reply;
            else
                break
            end
        end
    end
end

% If we can't resolve missing parameters, stop program
if any(isnan(paramsTarget)); error(['parameter names mismatch. ',...
        'Make sure naming convention in para_names is consistent.']); end
            