% figspecs.m will output specifications for each type of product and figure

function [Xaxis,Yaxis,Title,line,lgnd,plotSeparate] = figspecs(V_a,V_1,mspec,peachcount,newsletter,system,pres,plotType,...
    varnames,varnames_YL,varnames_YL_4Q,Vseq,Vseq_alt,nobs,Idate,Startdate,Enddate,...
    sirf,sirf_shockdec,sirf_counter,sirf_shock,datesall,dataset,zerobound,...
    nvar,list,shocksnames,names_shocks,pass,varargin)


if strcmp(plotType,'Forward Guidance')
    varnames{12} = 'Unemployment: t1 = ';
    varnames{13} = 'Interest Rate: Post-2017';
    sirf2 = min(sirf):max(sirf)+44;
    sirf3 = sirf + 44;
end
if pass % For counterfactuals, pass=1 only when figspecs is called the second time; for counterfactuals, figspecs requires S_a as well as V_a (shock and var loop)
    S_a = varargin{1};
end

if strcmp(plotType,'Counterfactual by Shock')
    if pass
        [Yaxis] = setYaxis(newsletter,system,pres,mspec,dataset,zerobound,nvar,plotType,S_a);
    end
else
    [Yaxis] = setYaxis(newsletter,system,pres,mspec,dataset,zerobound,nvar,plotType,V_a);
end

if newsletter || system || pres % The only change we make for system is the legend for the shockdec graphs-- this is set is mspec_add.m
    line.width = 1;
    switch plotType
        %% Forecast
        case {'Forecast','Forecast Semicond', 'Forecast Comparison','4Q Forecast','Exp_Forecast','Forecast Comparison Separate','4Q Forecast Separate','Forward Guidance'}
            plotSeparate = 0;
            
            Xaxis.limits = [min(sirf),max(sirf)];
            if V_a == 12 && mspec==510, Xaxis.limits = [min(sirf2),max(sirf2)]; end
            if V_a == 13 && mspec==510, Xaxis.limits = [min(sirf3),max(sirf3)]; end
            
            if strcmp('4Q Forecast',plotType)
                Yaxis.axislabel = varnames_YL_4Q(V_a);
            else
                Yaxis.axislabel = varnames_YL(V_a);
            end
            
            if any(V_a==Vseq_alt)
                Title.name = [];
                Title.size = 13;
                Xaxis.freq = sirf(1:8:end)';
                if ~strcmp(datesall(Xaxis.freq(1),end),'1')
                    disp('NOTE: Xaxis labels do not mark first quarter')
                end
                Xaxis.ticklabels = datesall(Xaxis.freq,1:4);
                Xaxis.ticklabelsize = 14;
                Yaxis.axislabelsize = 14;
                Yaxis.ticklabelsize = 10;
            else
                Title.name = varnames(V_a);
                Title.size = 11;
                Xaxis.freq = sirf(1:8:end)';
                if V_a == 12 && mspec==510, Xaxis.freq = sirf2(1:8:end)'; end
                if V_a == 13 && mspec==510, Xaxis.freq = sirf3(1:4:end)'; end
                
                if ~strcmp(datesall(Xaxis.freq(1),end),'1')
                    disp('NOTE: Xaxis labels do not mark first quarter')
                end
                Xaxis.ticklabels = datesall(Xaxis.freq,1:4);
                Xaxis.ticklabelsize = 6;
                
                if pres,
                    Title.size = 18;
                    Yaxis.axislabelsize = 16;
                    Yaxis.ticklabelsize = 12;
                else
                    Title.size = 11;
                    Yaxis.axislabelsize = 11;
                    Yaxis.ticklabelsize = 6;
                end
            end
            
            lgnd = [];
            
            %% Shock Decomposition
        case {'Shock Decomposition','Shock Decomposition-noDet'}
            plotSeparate = 0;
            Xaxis.limits = [min(sirf_shockdec),max(sirf_shockdec)];
            Xaxis.freq = sirf_shockdec(1:4:end);
            Xaxis.ticklabels = datesall(Xaxis.freq,1:4);
            
            if V_a==3
                Yaxis.axislabel = 'Percent';
            else
                Yaxis.axislabel = 'Percent Q-to-Q Annualized';
            end
            
            if any(V_a == Vseq_alt)
                Yaxis.axislabelsize = 12;
                Yaxis.ticklabelsize = 12;
            else
                Yaxis.axislabelsize = 11;
                Yaxis.ticklabelsize = 11;
            end
            
            if strcmp(plotType,'Shock Decomposition-noDet') || system
                if V_1 == length(Vseq)-length(Vseq_alt)
                    lgnd.size = 11;
                elseif V_1 == length(Vseq)
                    lgnd.size = 11;
                else lgnd = [];
                end
            elseif strcmp(plotType,'Shock Decomposition')
                if V_1 == length(Vseq)-length(Vseq_alt)
                    lgnd.size = 14;
                elseif V_1 == length(Vseq)
                    lgnd.size = 14;
                else 
                    lgnd = [];
                end
            end
            
            if newsletter
                if ~isequal(V_a,Vseq_alt)
                    Title.name = [varnames(V_a), '(deviations from mean)'];
                    Title.size = 11;
                else
                    Title = [];
                end
            else
                Title.name = [varnames(V_a), '(deviations from mean)'];
                Title.size = 11;
            end
            
            
            %% Counterfactuals
        case {'Counterfactual by Shock', 'Counterfactual by Variable'}
            plotSeparate = 0;
            % Counterforecast=1 plots 60QAhead, Counterforecast=1 or 2 plots up to stime only
            if Counterforecast==1,tick_counter=3; else tick_counter=1; end
            
            sirf_counter = (Startdate:Enddate);
            
            if strcmp(plotType, 'Counterfactual by Shock')
                if pass
                    S_a = varargin{1};
                    Yaxis.axislabel = varnames_YL(S_a);
                    Title.name = varnames(S_a);
                end
            else
                if pass
                    S_a = varargin{1};
                    Title.name = shocksnames(S_a);
                end
                Yaxis.axislabel = varnames_YL(V_a);
            end
            
            Title.size = 14;
            Xaxis.limits = [min(sirf_counter),max(sirf_counter)];
            Xaxis.freq = sirf_counter(1:4*tick_counter:end);
            Yaxis.axislabelsize = 8;
            Yaxis.ticklabelsize = 6;
            % 			if plotSeparate_counter
            if plotSeparate
                Xaxis.ticklabels = datesall(Xaxis.freq,:);
            else
                Xaxis.ticklabels = datesall(Xaxis.freq,3:end);
            end
            lgnd=[];
            
            %% Shock innovations
        case {'Shock'}
            plotSeparate = 1;
            sirf_shock = (Startdate:Idate + logical(peachcount));
            
            if system
                Title.name = names_shocks{V_a};
                Title.size = 10;
            else
                Title.name = [shocksnames(V_a)];
                Title.size = 10;
            end
            
            Xaxis.limits = [min(sirf_shock),max(sirf_shock)];
            
            Xaxis.freq = sirf_shock(1:4:end);
            Yaxis.axislabel = 'Standard Deviations';
            Yaxis.axislabelsize = 8;
            Yaxis.ticklabelsize = 6;
            
            % 			if plotSeparate_shocks
            if plotSeparate
                Xaxis.ticklabels = datesall(Xaxis.freq,:);
            else
                Xaxis.ticklabels = datesall(Xaxis.freq,3:end);
            end
            
            lgnd=[];
        case {'ShockAnt'}
            plotSeparate = 1;
            sirf_shock = (Startdate:Idate + logical(peachcount));
            
            if system
                Title.name = names_shocks{V_a};
                Title.size = 10;
            else
                Title.name = [shocksnames(V_a)];
                Title.size = 10;
            end
            
            Xaxis.limits = [min(sirf_shock),max(sirf_shock)];
            
            Xaxis.freq = sirf_shock(1:4:end);
            Yaxis.axislabel = 'Percent';
            Yaxis.axislabelsize = 8;
            Yaxis.ticklabelsize = 6;
            
            % 			if plotSeparate_shocks
            if plotSeparate
                Xaxis.ticklabels = datesall(Xaxis.freq,:);
            else
                Xaxis.ticklabels = datesall(Xaxis.freq,3:end);
            end
            
            lgnd=[];
            
        case {'Shock Squared','Htil','Eta Squared','Sigma'}
            plotSeparate = 1;
            sirf_shock_sq = 1:nobs;
            
            %sirf_shock = (Startdate:Idate + peachcount);
            
            if system
                Title.name = names_shocks{V_a};
                Title.size = 10;
            else
                Title.name = [shocksnames(V_a)];
                Title.size = 10;
            end
            
            Xaxis.limits = [min(sirf_shock_sq),max(sirf_shock_sq)];
            
            Xaxis.freq = sirf_shock_sq(1:4:end);
            Yaxis.axislabel = 'Standard Deviations';
            Yaxis.axislabelsize = 8;
            Yaxis.ticklabelsize = 6;
            
            % 			if plotSeparate_shocks
            if plotSeparate
                Xaxis.ticklabels = datesall(Xaxis.freq,:);
            else
                Xaxis.ticklabels = datesall(Xaxis.freq,3:end);
            end
            
            lgnd=[];
            
        case 'ImpObs'
            % set in spec, under "Forecast:implied variables"
            varnames_YL_imp = varargin{1}; 
            varnames_imp = varargin{2}; 
            nimpVar = varargin{3}; 
                        
            varnames_YL(end+1:end+nimpVar) = varnames_YL_imp;
            varnames(end+1:end+nimpVar) = varnames_imp;
            
            plotSeparate = 1;
            
            Xaxis.limits = [min(sirf),max(sirf)];
            
            Yaxis.axislabel = varnames_YL(V_a);
            
            Title.name = varnames(V_a);
            Title.size = 11;
            
            Xaxis.freq = sirf(1:4:end)';    
            if ~strcmp(datesall(Xaxis.freq(1),end),'1')
                disp('NOTE: Xaxis labels do not mark first quarter')
                disp('Adjusting Xaxis.freq so that labels mark first quarter')
                Q1indx = find(datesall(:,6)=='1',1,'first');
                Xaxis.freq = sirf(Q1indx:4:end)';
            end
            Xaxis.ticklabels = datesall(Xaxis.freq,1:4);
            Xaxis.ticklabelsize = 11;

            if pres,
                Title.size = 18;
                Yaxis.axislabelsize = 16;
                Yaxis.ticklabelsize = 12;
            else
                Title.size = 11;
                Yaxis.axislabelsize = 11;
                Yaxis.ticklabelsize = 6;
            end
            
            lgnd=[];
    end
end

if pres % JC: In case newsletter,system and presentation figure formats diverge, I'm leaving this list separate.
    line.width = 2.2;
    switch plotType
        case {'Forecast' 'Forward Guidance'}
            plotSeparate = 1;
        case 'Counterfactual by Shock'
            plotSeparate = 0;
        case 'Counterfactual by Variable'
            plotSeparate = 0;
        case {'Shock','ShockAnt'}
            plotSeparate = 1;
        case {'Shock Decomposition','Shock Decomposition-noDet'}
            plotSeparate = 1;
    end
end
if any(mspec==[16 160 161 162 172 173 174])
    plotSeparate=1;
end;
