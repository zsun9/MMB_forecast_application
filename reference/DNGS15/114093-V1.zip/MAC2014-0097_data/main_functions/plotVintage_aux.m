% OVERVIEW
% plotPresentation.m: Produces figures for presentations only.
%
% IMPORTANT FUNCTIONS
% setVseq.m: a function whose input is the figure type. The output from this
%            function is a vector that indicates the sequence of variables
%            for which we want to produce figures.
% recordFcn.m: a function that records the plotted values.
%              The output is a structure variable, record, whose fields
%              are different plot types, and whose subfields are the plotted
%              mean and bands. The variable record is saved and
%              written to an output text file.
% figspecs.m: this function outputs the variables Xaxis, Yaxis, Title, line,
%             lgnd, and plotSeperate, which are all specifications
%             for unique to each figure and model. lgnd contains
%             specifications for the legend. plotSeparate is a flag
%             indicating whether or not the figures for each variable are
%             to be plotted separately.
% setfig.m: this function takes the variable plotType (ie. 'Forecast') as
%           input and outputs the scalar variable figmain. All figures of
%           this plot type have a figure number that is a function of this
%           scalar. For example, if figmain for 'Forecast' figures is 100,
%           then the output forecast figure would be figure(101), and
%           figure(102) for labor share forecast.
% applyfigspecs.m: this program applies figure specifications for the
%                  X-axis, Y-axis, title, secondary axis, and gridlines.
plotList = {'Forecast'};

noTitles = 0;

pres = 1; newsletter = 0; system = 0;
peachloop = peachflag ;
if peachflag==1;
    pstrn='peach';
else
    pstrn='';
end
[fpath,spath,gpath] = pathspec(dataset,figDir);
gpath = [gpath,lmodel,'_',pf_mod,pstrn,'_',vintend.date,'_',datestr(now,'YYYYmmdd-HHMMSS'),'/'];
if ~exist('gpath','file'), mkdir(gpath); end;

%% Specify outfile for recording plotted values
namestr_record = [lmodel,lprior,ds,num2str(100*dates),num2str(nlags),num2str(T0),parstr];
outfile0 = [gpath,namestr_record,'_',date,'.txt'];
fid0 = fopen(outfile0,'wt+');

loadvintage;

if auxFlag
    % update auxilary var data with smoothed state "actuals"
    loadParams;
    state_file =['states',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr{peachflag+1},num2str(jstep),parstr];
    eval(['[YY,stateFinals,auxCount] = auxUpdateYY',num2str(mspec),'(YY,state_file,mspec,nlags,nstate,dataset,priotheta, priotheta);']);
end

Ys = getYs(YY(1:Idate,:),YY_p,dlpop,dlpop_p,cum_for,popadj,nvar,0,q_adj,0);

%% Loop through figures
for plotnum = 1:length(plotList)
    
    plotType = plotList{plotnum};

    sirf = Startdate:stime+future;
    
    [Vseq,Vseq_alt,Shseq,Shseq_alt] = setVseq(plotType,mspec,varnames,cum_flag,phillips_mc);

    for peachcount = peachloop
        varcount = 0;
        V_alt_count = 0;
        for V_idx = 1:length(Vseq)
            
            V_a = Vseq(V_idx);
            pass = 0;
            %% Set figure specifications and fignum
            [Xaxis,Yaxis,Title,line,lgnd,plotSeparate] = figspecs(V_a,V_idx,mspec,peachcount,newsletter,system,pres,plotType,...
                varnames,varnames_YL,varnames_YL_4Q,Vseq,Vseq_alt,nobs,Idate,Startdate,Enddate,...
                sirf,sirf_shockdec,sirf_counter,sirf_shock_1,datesall,dataset,zerobound,...
                nvar,list,shocksnames,names_shocks_title,pass);%varnames_YL_imp,varnames_imp,nimpVar);
            
            % This extends the bounds for graphs with the (larger) 99
            % percent bands
            if onepctflag && strcmp(plotType,'Forecast')
                if any(V_a == [1,2])
                    Yaxis.lim = [-15,15];
                elseif any(V_a == [4,5])
                    Yaxis.lim = [-5,10];
                end
            end
            
            [figmain] = setfig(plotType);
            
            %% Specify subplots and orientation
            
            if plotSeparate
                figure(figmain+(250*peachcount)+V_a);
                
                if cum_for(V_a) == 6
                    orient landscape
                else
                    orient portrait
                end
                if strcmp(plotType,'Shock Decomposition')
                     ax = get(gca,'Position');
                     ax(2) = 0.17;
                     ax(4) = 0.75;
                     set(gca,'Position',ax);
                end
                if history==1 && strcmp(plotType,'ImpObs')
                    set(gcf, 'PaperSize', [34 8]);
                    set(gcf, 'PaperOrientation', 'portrait');
                end
            else
                if strcmp(plotType,'Shock')
                    figure(figmain+(250*peachcount))
                end
                switch plotType
                    case {'Shock Decomposition','Forecast','Counterfactual by Variable','ImpObs'} % Figures that loop through variables
                        if any(strcmp(plotType,{'Forecast','Counterfactual by Variable','ImpObs'}))
                            figure(figmain) % Both conditional and unconditional forecasts are plotted together
                            orient tall
                            subplot(length(aVseq)-length(Vseq_alt),2,2*V_idx-(1-peachcount));
                        elseif strcmp(plotType,'Shock Decomposition')
                            figure(figmain+(250*peachcount));
                            orient portrait
                            ax = get(gca,'Position');
                            set(gca,'Position',ax);
                        end
                end
            end
            
            %% Plot figures
            switch plotType
                case {'Forecast'}
                    if cum_for(V_a) ~= 6
                        % Mean
                        mlp = [Ys(:,V_a);squeeze(Means.forecast(V_a,:,peachcount+1))'];
                        
                        % Bands
                        num_bands = 2 + 8*fancharts;
                        bandsp = [repmat(Ys(:,V_a),[1 num_bands]);squeeze(Bands.forecast(:,V_a,:,peachcount+1))'];
                        
                        LBands(V_a,:) =  bandsp(sirf,1)';
                        UBands(V_a,:) =  bandsp(sirf,2)';
                        
                        % Record data plotted
                        if overwrite
                            [record] = recordFcn(plotType,record,V_idx,V_a,peachcount,tiall,Startdate,stime,qahead,varnames,fid0,0,...
                                bandsp,mlp);
                        end
                        
                        % Fancharts
                        if fancharts
                            bandsp = bandsp/4;
                            bandsp = [bandsp(:,1),bandsp(:,2:10)-bandsp(:,1:9)];
                        else
                            bandsp = bandsp/4;
                        end
                        
                        if fancharts %Uncomment to put bands into figure
                            P = area(sirf,bandsp(sirf,:));
                            set(P(1),'FaceColor','none')
                            for layer = 2:10
                                set(P(layer),'FaceColor',[0.4 + 0.12*abs(layer-6),0.4 + 0.12*abs(layer-6),1]);
                            end
                            set (P,'LineStyle','none')
                            if V_a == 3
                                set(P,'BaseValue',.52)
                            end
                        else
                            % dont plot bands!!!
                        end
                        %hold on;
                        
                        % This adds the 99 percent bands if onepctflag is on
                        if onepctflag
                            bandsp_onepct = [repmat(Ys(:,V_a),1,2);squeeze(Bands_onepct(:,V_a,:,peachcount+1))'];
                            P = plot(sirf,bandsp_onepct(sirf,1)/4,'r:',sirf,bandsp_onepct(sirf,2)/4,'r:');
                            set(P,'LineWidth',line.width);
                        end
                        
                        % Forecast
                        P = plot(sirf,mlp(sirf)/4,'r-');
                        set(P,'LineWidth',line.width);
                        hold on;
                        
                        
                        % Actual data
                        mn=min(size(vintend.final,1),qahead);
                        bn=min(length(jvint.fdate),qahead);
                        
                        mlp = [Ys(:,V_a);NaN*squeeze(Means.forecast(V_a,:,peachcount+1))'];%estimation sample data
                        if V_a > nvar-auxCount
                            flp = [stateFinals(:,V_a);nan(qahead-bn,1)];%finals here
                        else
                            if strcmp(varnames{V_a},'Long Inf')
                                flp = [nan(size(Ys,1),1);vintend.longinf(:,1);nan(qahead-mn,1)];%finals here
                            else
                                flp = [nan(size(Ys,1),1);vintend.final(:,V_a);nan(qahead-mn,1)];%finals here
                            end
                        end
                        blp = [nan(size(Ys,1),1);jvint.forecast(:,V_a);nan(qahead-bn,1)];%judgemental forecast here
                        
                        %% Plot backwards looking phillips forecast (blue dash) and
                        %% forecast conditioned on ex-post mc_t (red dash)
                        if V_a == 4 && phillips_mc
                            load([spath,'phillips/phillips_GR.mat']);
                            m_ = size(phillips_fcast,1)-mnobss;
                            phillips_fcast = getyp(phillips_fcast(:,2)',m_+mnobss,1,cum_for(V_a),popadj(V_a),[],[],[],q_adj);
                            phillips = [nan(size(Ys,1)-mnobss,1);phillips_fcast(1,:)'/4;nan(qahead-m_,1)];
                            P = plot(sirf,phillips(sirf),'-.','Color','b');
                            set(P,'LineWidth',line.width);
                            
                            load([spath,'mc_cond/inf_GR_fcast_cond_mc_',num2str(mspec),'.mat']);
                            n_ = length(inf_fcast_cond_mc);
                            inf_fcast_cond_mc = getyp(inf_fcast_cond_mc,n_,1,cum_for(V_a),popadj(V_a),[],[],[],q_adj);
                            cond_mc = [nan(size(Ys,1)-1,1);mlp(size(Ys,1))/4;inf_fcast_cond_mc'/4;nan(qahead-n_,1)];
                            P = plot(sirf,cond_mc(sirf),'--*','Color','r');
                            set(P,'LineWidth',line.width);    
                        end
                        
                        if strcmp(figDir,'figure_0') && V_a == 4
                            cpce = importdata('data/cpce.txt');
                            %cpce = remean_cpce(priotheta,mspec,cpce);
                            itmp0 = find(length(tiI) == sirf)+1;
                            itmp = find(length(cpce) == sirf);
                            sirf0 = sirf(itmp0:itmp);
                            P = plot(sirf0,cpce(sirf0),'g-.');
                            set(P,'LineWidth',line.width); 
                        end
                        
                        %% Plot ex-ante data
                        P = plot(sirf,mlp(sirf)/4,'k-');
                        set(P,'LineWidth',line.width);
                        hold on;
                        
                        %% Plot ex-post finals
                        P = plot(sirf,flp(sirf),'--k');
                        set(P,'LineWidth',line.width);

                        if V_a == 5
                            sirf_bc = find(tiall==tiI(end))+1:find(tiall==tiI(end))+size(vintend.exp,1);
                            P = plot(sirf_bc,vintend.exp(:,3),'-d','Color','b','LineWidth',line.width);
                            set(P,'MarkerFaceColor','b');
                        end
                        
                        hold off;
                    else
                        cumSumPlot;
                    end
                    
            end
            
            if any(strcmp(plotType,{'Forecast'}))
                Title.name=[];
                Yaxis.axislabel=[];
                
                applyfigspecs; % For the counterfactuals (which have another loop in addition to the variable loop),
                % applyfigspecs is called within the loop so
                % individual figures can be modified
                
                set(gca,'FontSize',20);
            end
        end
    end
end

%% Record
% Save plotted values in .txt and .mat
if overwrite
    finalRecord = 1;
    [record] = recordFcn('',record,V_idx,V_a,peachcount,...
        tiall,Startdate,stime,qahead,...
        varnames,fid0,finalRecord);
   
    %% Save figures
    % Removed lambdas and plotNoShocks from figure names
    for plotnum = 1:length(plotList)
        plotType = plotList{plotnum};
        [figmain] = setfig(plotType);
        [Vseq,Vseq_alt,Shseq,Shseq_alt] = setVseq(plotType,mspec,varnames,cum_flag,phillips_mc);
        
        switch plotType
            case {'Forecast'}
                % The addition of 'onepctstr' deals with the case of
                % graphs with 99 percent bands. Otherwise it will be
                % blank.
                namestr = [lmodel,lprior,ds,num2str(100*dates),num2str(nlags),num2str(T0),onepctstr,parstr];
        end
        
        if history, namestr = [namestr,'_history']; end
        
        switch plotType
            case 'Forecast'
                for peachcount = peachloop
                    for V_a = Vseq
                        fignum = figmain+(250*peachcount)+V_a;
                        print(figure(fignum),'-depsc', [gpath,'forecast',peachstr{peachcount+1},namestr,char(graph_title(V_a)),'.eps']);
                        saveas(figure(fignum),[gpath,'forecast',peachstr{peachcount+1},namestr,char(graph_title(V_a))],'pdf');
                    end
                end
        end
    end
    fclose(fid0);
end

fprintf('Figures are saved in gpath (%s) \n',gpath);