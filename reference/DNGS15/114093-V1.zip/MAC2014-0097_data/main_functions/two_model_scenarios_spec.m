function scenario_name = two_model_scenarios_spec()
%% ------------------------------------------------------------------------
% Options: mrkup_only,no_mrkup,no_shocks
% -------------------------------------------------------------------------
scenario_name = 'no_mrkup';