%                                   OVERVIEW
% forecastFcn.m: a function called on by forecast_parallel.m. This function
%                takes draws allocated each worker to calculate forecasts,
%                counterfactuals, shock decompositions, and smoothed shock
%                estimates, both unconditional and conditional on Dick Peach's forecast.
%
% forecastFcn.m is broken up into 4 main steps:
%
% STEP 1: Get matrices of the state transition and
%         measurement equations. In gibb.m, these
%         matrices are computed and condensed, so here we read in and
%         reshape the input data.
% STEP 2: Run the Kalman filter.
% STEP 3: Run the Kalman smoother to get a sequence of smoothed states (S_0/T,...,S_T/T).
%         In this step, we also get a sequence of smoothed shocks, which we
%         plot (these figures are referred to as "shock histories").
% STEP 4: Using S_{T/T}, compute forecasts. With S_{0/T}, compute the
%         deterministic trend. Using a subset of the sequence of smoothed states,
%         we can compute the counterfactuals and shock decompositions.
%
% The state transition equation is: S_t = TTT*S_t-1+RRR*eps_t
% The measurement equation is: Y_t = ZZ*S_t+DD
%
%                           IMPORTANT INPUTS
% k: worker number index (used to ensure workers receive independently randomized seeds)
%
% priotheta: parameter draws
% TTTsim,RRRsim: state transition equation matrices
% zendsim: end-of-sample smoothed state vector (from gibb.m)
%
% zerobound: flag specifying zerobound model (incorporates anticipated shocks)
% bdd_int_rate: flag specifying bounded interest rate rule
% nant2,antlags: number of anticipated shocks, number of past periods in
%               which ZB was in effect.
% nshocks_all: total number of shocks (incl. anticipated shocks)
%
% peachflag: (if 0) no conditional data ("unconditional forecast")
%            (if 1) use conditional forecasts and data for all observables
%                   except labor share ("conditional forecast")
%            (if 2) use conditional data for spreads and FFR only
%                   ("semi-conditional forecast")
% peachdata, semi_peachdata: conditional, semi-conditional data
%
% simple_forecast: (if 1): just compute the unconditional forecast
% qahead, qahead_extra: number of quarters ahead to forecast if
%                       unconditional forecast, or if conditional or
%                       semi-conditional forecast.
% YY, YY0: observable data, pre-sample observable data
% nobs: length of observable time series
% stime: index for the current quarter, relative to the observable time series
%
% Startdate: Index for counterfactual start date. Also, index for shock
%            decomposition figure start date.
% Enddate_forecastfile: total number of quarters in the observable time
%                       series and the forecast period: stime + qahead

%                               OUTPUTS
% fcast: forecast; there are subfields for unconditional, semi-conditional,
%        conditional, and (if zerobound) their bounded forecast counterparts
%
% varargout (optional outputs):
% shocks: smoothed shock histories
% ytrend: steady state, for shock decomposition plots
% dettrend: deterministic trend, for shock decomposition plots
% shockdec_all: shock contributions to forecast, for shock decomposition plots
% counter_all: counterfactual forecasts
%
%                           IMPORTANT SUBFUNCTIONS
% augmentFilter.m, augmentSmoother.m: augments relevant matrices for the Kalman Filter and Smoother
% kalcvf2NaN.m: runs the Kalman Filter
% kalsmth_k93.m: runs the Kalman Smoother using algorithm in (Koopman 1993)


function [fcast,varargout] = vintage_forecastFcn_aux(k,priotheta,alternativeTheta,...
    mspec,peachflag,simple_forecast,...
    nvar,qahead,qahead_extra,nshocks_all,YY,nobs,peachdata,psize,peachvar,...
    Enddate_forecastfile,Startdate,stime,ShockremoveList,...
    varnames,names_shocks,...
    nstate_0,nshocks_0,sflag,YY0,...
    valid_para,nlags,npara,para_names,gensys2,nant2)

% Set new seed (random number sequence) for each worker
rand('state',sum(100*clock+k))
randn('state',sum(100*clock+k))

nDraws = size(priotheta,1); % Number of draws distributed. Matrices holding draws have already been indexed by jstep in forecast_parallel.m.

if sflag
    genHair = 1;
end

%% Initialize output variables

fcast.uncond_hist = zeros(nDraws,(nvar)*stime);
fcast.uncond = zeros(nDraws,(nvar)*qahead);

if peachflag
    fcast.cond_hist = zeros(nDraws,(nvar)*stime);
    fcast.cond = zeros(nDraws,(nvar)*qahead);
end

if ~simple_forecast
    shocks.data = zeros(nDraws,nshocks_all*size(YY',2));
    if peachflag
        shocks.dick = zeros(nDraws,nshocks_all*(size(peachdata,1)));
        shocks.datawdick = zeros(nDraws,nshocks_all*size(YY,1));
    end
    ytrend = zeros(nDraws,nvar);
%     dettrend = zeros(nDraws,nvar*(Enddate_forecastfile - Startdate + 1),peachflag+1);
    dettrend = zeros(nDraws,nvar*(Enddate_forecastfile),peachflag+1);
%         counter_all = zeros(nDraws,nvar*(Enddate_forecastfile - Startdate),peachflag+1,length(ShockremoveList));
    counter_all = zeros(nDraws,nvar*(Enddate_forecastfile - 1),peachflag+1,length(ShockremoveList)); % FOR FULL HIST COUNTER
%     shockdec_all = zeros(nDraws,nvar*(Enddate_forecastfile - Startdate + 1),peachflag+1,length(ShockremoveList) - 1);
    shockdec_all = zeros(nDraws,nvar*(Enddate_forecastfile),peachflag+1,length(ShockremoveList) - 1);
end


%% Loop through parameter draws
for a = 1:nDraws
    
    params=priotheta(a,:)';
    paramsAlt = alternativeTheta(a,:)';
    
    [TTT,RRR,CCC,valid] = dsgesolv(params,mspec);%GENERATE TTT RRR (sim), since all we save is parasim
    
    [ZZ,DD,DDcointadd,QQ,EE,MM,retcode] = getmeasur(mspec,TTT,RRR,valid,params,nvar,nlags,npara,0,0);
    
    %% Add auxilary variables to ZZ block
    eval(['[ZZ, DD, QQ] = auxMeasur',num2str(mspec),'(ZZ, DD, QQ, mspec, TTT, params, paramsAlt, 0);']);
    
    nstate=nstate_0;
    nshocks = nshocks_0;
    
    %% This section resolves the model if you are going to use the
    %% alternate Gensys
    model2_num = '001';
    if gensys2
        [Tcal, Rcal,Ccal,Tbar, num_z] = get_gensys2(params, mspec, model2_num, nshocks, nant2);
    end
    
    HH = EE+MM*QQ*MM';
    VV = QQ*MM';
    VVall = [[RRR*QQ*RRR',RRR*VV];[VV'*RRR',HH]];
    lead=1;
    
    %% Define the initial mean and variance for the state vector
    A0 = zeros(nstate,1);
    P0 = dlyap(TTT,RRR*QQ*RRR');
    
    [pyt0,zend,pend,pred0,vpred0] = kalcvf2NaN(YY0',1,zeros(nstate,1),TTT,DD,ZZ,VVall,A0,P0);
    
    [L,zend,pend,pred,vpred]=kalcvf2NaN(YY',lead, ...
        zeros(nstate,1),TTT,DD,ZZ,VVall,zend,pend);
    
    
    %% STEP 2 (Unconditional data): Kalman Filter
    
    % If we are only doing an unconditional forecast we can just skip
    % to the end since all we need is zend, which we already loaded in.
    if peachflag == 1 || simple_forecast == 0
        HH = EE+MM*QQ*MM';
        VV = QQ*MM';
        VVall = [[RRR*QQ*RRR',RRR*VV];[VV'*RRR',HH]];
        lead = 1;
        
        A0 = zeros(nstate,1);
        P0 = dlyap(TTT,RRR*QQ*RRR');
        
        % Kalman filtering over the presample
        if ~isempty(YY0)
            [pyt0,zend,pend,pred0,vpred0] = kalcvf2NaN(YY0',1,zeros(nstate,1),TTT,DD,ZZ,VVall,A0,P0);
        else
            zend = A0;
            pend = P0;
        end
        
        
        % Filter over the main sample.
        [L,zend,pend,pred,vpred] = kalcvf2NaN(YY',lead,zeros(nstate,1),TTT,DD,ZZ,VVall,zend,pend);

        zend_uncond = zend;
        pend_uncond = pend;
        
        
        %% STEP 3 (Unconditional data): Kalman Smoother
        
        if ~simple_forecast 
                pred_all = [pred0,pred];
                
                vpred_all = zeros(nstate,nstate,size(YY0,1)+size(YY,1));
                vpred_all(:,:,1:size(YY0,1)) = vpred0;
                vpred_all(:,:,size(YY0,1)+1:end) = vpred;
                
                YY_all = [YY0;YY];
                 
            % This section does the smoothing. For the zero bound,
            % this can be done in one step, since there is code in
            % both the Kalman Smoother and Simulation Smoother that
            % set the QQ matrix to zero in all periods before the
            % model switch, which ensures that the smoothed shocks
            % include no anticipated shocks prior to that time.
            [sm_states_all,sm_shocks_all] = kalsmth_k93(A0,P0,YY_all',pred_all,vpred_all,TTT,RRR,QQ,ZZ,DD,0,psize);
        end
        
        % Since we smoothed back farther than we needed to
        % (even before the presample), we only need parts of
        % sm_states_all and sm_shocks_all.
        z0T = zeros(nstate,peachflag+1);
        z0T(:,1) = sm_states_all(:,size(YY0,1));
        
        sm_states = sm_states_all(:,size(YY0,1)+1:end);
        sm_shocks = sm_shocks_all(:,size(YY0,1)+1:end);
        
        % z0T is the smoothed time 0 state vector. If peachflag
        % is on it will have two columns to hold one vector
        % smoothed without peachdata, and one smoothed with
        % peachdata.
        
        %% Generate Hairplots
        % saved = hairplots(mspec,sm_states,Startdate,TTT,20); % GR
        if genHair
            [TTThair,RRRhair,CCChair,validhair] = dsgesolv(paramsAlt,mspec);
            hair  = hairplots(mspec,sm_states,1,TTThair,200); % Full History
            hair_ar2  = hairplots_ar2(mspec,sm_states,1,20,TTThair,200); % Full History
            hair_rw  = hairplots_rw(mspec,sm_states,1,TTThair,200,0); % Full History
        end
        
        %% Calculate shock histories
        QQinv = zeros(nshocks);
        QQinv(QQ > 0) = QQ(QQ > 0).^(-1/2);
        sm_sdz_shocks = QQinv*sm_shocks;
        
        shocks.data(a,:) = sm_sdz_shocks(:)';
        
        
        total_filt=[];
        total_vfilt=[];
        total_smth=[];
        total_vsmth=[];
        
        %% Kalman filtering and smoothing over conditional data
        
        if peachflag  
            %% STEP 2 (Conditional Data): Kalman filter
            % Since the new smoothers and filter can automatically deal
            % with NaNs in the data matrix, the code can be much
            % simplified.
            VVall = zeros(nstate+length(peachdata));
            VVall(1:nstate,1:nstate) = RRR*QQ*RRR';
            VVall_peach = VVall;
            VVall_peach(nstate+1:nstate+nvar,nstate+1:nstate+nvar) = diag(peachvar);
            
            [L,zend_peach,pend_peach,pred_peach,vpred_peach] = kalcvf2NaN(peachdata',lead,zeros(nstate,1),TTT,DD,ZZ,VVall_peach,zend,pend);
            
            %% STEP 3 (Conditional Data): Kalman smoother
            YY_all_peach = [YY_all;peachdata];
            
            pred_all_peach = [pred_all,pred_peach];
            
            vpred_all_peach = zeros(length(TTT),length(TTT),size(YY_all_peach,1));
            vpred_all_peach(:,:,1:size(YY_all,1)) = vpred_all;
            vpred_all_peach(:,:,size(YY_all,1)+1:end) = vpred_peach;
            
            [sm_states_all_peach,sm_shocks_all_peach] = kalsmth_k93(A0,P0,YY_all_peach',pred_all_peach,vpred_all_peach,TTT,RRR,QQ,ZZ,DD,1,psize);
            
            z0T(:,2) = sm_states_all_peach(:,size(YY0,1));
            
            sm_states_peach = sm_states_all_peach(:,size(YY0,1)+1:end);
            sm_shocks_peach = sm_shocks_all_peach(:,size(YY0,1)+1:end);
            
            
            % Calculate conditional shocks histories
            sm_sdz_shocks_peach = QQinv*sm_shocks_peach;
            shocks.datawdick(a,:) = reshape(sm_sdz_shocks_peach(:,1:size(YY,1)),1,nshocks*size(YY,1));
            shocks.dick(a,:) = reshape(sm_sdz_shocks_peach(:,size(YY,1)+1:end),1,nshocks*psize);
            peachdataimplied = getpeachdataimplied(size(peachdata,1),ZZ,DD,sm_states_peach(:,end-size(peachdata,1)+1:end));
            
            sm_states_semipeach = [];
            sm_shocks_semipeach = [];   
        else  
            sm_states_peach = [];
            sm_shocks_peach = [];
            
            sm_states_semipeach = [];
            sm_shocks_semipeach = [];      
        end
        
    else
        % For simple_forecast with no conditional forecast, zend is all we need.
        zend_uncond = zend;
    end
    
    %% STEP 4: Compute forecasts
    
    ind_r = find(strcmp(varnames,'Interest Rate'));
    ind_r_sh = find(strcmp(names_shocks,'r_m'));
    
    % ALT POLICY
    %params(13) = 1.2;
    %params(14) = 0;
    %[TTT,RRR,CCC,valid] = dsgesolv(params,mspec);
    
    % Conditional forecast
    if peachflag
        [yypred] = getVForecast(qahead_extra,nvar,nshocks,TTT,RRR,DD,ZZ,QQ,zend_peach,sflag);
          
        if gensys2
            [yypred] = getForecast_plus(qahead_extra,nvar,nshocks,Tcal,Rcal,Ccal,DD,ZZ,QQ,zend_peach,Tbar, num_z, nant2);
        end
        
        yypred_nocoint = [peachdataimplied; yypred(:,1:nvar)];
        
        fcast.cond(a,:) = yypred_nocoint(:)';    
    end
       
    % Unconditional forecast
    [yypred] = getVForecast(qahead,nvar,nshocks,TTT,RRR,DD,ZZ,QQ,zend_uncond,sflag);
    fcast.uncond(a,:) = yypred(:)';
    
    % Counterfactuals, shock decompositions, deterministic trends, and steady states
    if ~simple_forecast
        ytrend(a,:) = DD';
        dettrend(a,:,:) = getdettrend_fullHist(Enddate_forecastfile,nvar,ZZ,TTT,DD,z0T,Startdate,peachflag);
        counter_all(a,:,:,:) = getcounter_fullHist(ShockremoveList,peachflag,psize,Enddate_forecastfile,...
            sm_states,sm_shocks,sm_states_peach,sm_shocks_peach,...
            Startdate,nobs,nshocks,qahead_extra,nvar,TTT,RRR,DD,ZZ);
        shockdec_all(a,:,:,:) = getshockdec_fullHist(ShockremoveList,peachflag,psize,Enddate_forecastfile,...
            sm_shocks,sm_shocks_peach,...
            Startdate,nobs,qahead_extra,nvar,TTT,RRR,DD,ZZ);
    end
end

if ~simple_forecast
    varargout{1} = shocks;
    varargout{2} = ytrend;
    varargout{3} = dettrend;
    varargout{4} = counter_all;
    varargout{5} = shockdec_all;
    if peachflag == 1
        varargout{6} = sm_states_peach(:,1:end-1);
    else
        varargout{6} = sm_states;
    end
    
    if genHair
        varargout{7} = {{'',hair},{'ar2',hair_ar2},{'rw',hair_rw}};
    end
    
end