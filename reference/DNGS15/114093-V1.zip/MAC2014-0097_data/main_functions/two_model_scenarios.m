clearvars -except figDir list_scenario
close all;fclose all;
spec_904_aux_full201250;
forecast_vintage_aux_2model;

scenario_name = two_model_scenarios_spec();

YY(:,11) = sm_states(11,:)';

spath = [spath,'two_model_fcast_decomp/'];
gpath = [gpath,'two_model_fcast_decomp/'];
if ~exist(gpath,'dir'); mkdir(gpath); end;

if ~strcmp(scenario_name,'no_shocks')
    if ~exist([spath,'scenarios_no_shocks_',num2str(tiI(end)*100),'.mat'],'file')
        error('Please run this code with scenario_name = ''no_shocks'' first to get baseline fcast');
    end
    load([spath,'scenarios_no_shocks_',num2str(tiI(end)*100),'.mat']);
    fcast_d_scenarios_noSh = fcast_d_scenarios;
    
    load([spath,'scenarios_',scenario_name,'_',num2str(tiI(end)*100),'.mat']);
    
else
    load([spath,'scenarios_',scenario_name,'_',num2str(tiI(end)*100),'.mat']);
    fcast_d_scenarios_noSh = fcast_d_scenarios;
end

[var_list,~,~,~] = setVseq('Forecast Decomposition',mspec,varnames,cum_flag);

for i_ = 1:length(var_list)
    v_ = var_list(i_);
    f = figure();
    
    P = plot(ti(158:end,1),[NaN*YY(158:175,v_);YY(176,v_);fcast_d_scenarios_noSh(:,v_,1)],'Color','r');
    set(P,'LineWidth',2.2);
    hold on;
    
    P = plot(ti(158:end),[NaN*YY(158:175,v_);YY(176,v_);fcast_d_scenarios(:,v_,2)],'--*','Color',rgb('Blue'));
    set(P,'LineWidth',2.2);
    
    P = plot(ti(177:end),YY(177:end,v_),'k--');
    set(P,'LineWidth',2.2);
    P = plot(ti(158:176),YY(158:176,v_),'k-');
    set(P,'LineWidth',2.2);
    
    set(gca,'XTick',ti(158:4:end));
    set(gca,'FontSize',20);
    
    if v_ == 4
        ylim([-0.5,1.5]);
    end
    
    xlim([ti(158),ti(end)]);
    saveas(f,[gpath,'scenarios_',...
        scenario_name,'_',strrep(varnames{v_},' ','_'),'_v3.pdf']);
end

