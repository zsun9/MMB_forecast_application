%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Run the usual code to get the modal results %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if mspec0 == 904 % choose model
    spec_904_aux_full201250;         
elseif mspec0 == 803
    spec_803_aux_sw;
end
forecast_vintage_aux;
forplot_vint_aux;

if auxFlag
    % update auxilary var data with smoothed state "actuals"
    loadParams;
    state_file =['states',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr{peachflag+1},num2str(jstep),parstr];
    eval(['[YY,stateFinals,auxCount] = auxUpdateYY',num2str(mspec),'(YY,state_file,mspec,nlags,nstate,dataset,originalTheta,priotheta);']);
end

Ys = getYs(YY(1:Idate,:),YY_p,dlpop,dlpop_p,cum_for,popadj,nvar,0,q_adj,0);

if mspec == 904
    model_col = 'b';
elseif mspec == 803
    model_col = 'm';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% choose the shocks to plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Demand
g_sh = getState(mspec,0,'g_sh');
b_sh = getState(mspec,0,'b_sh');
mu_sh = getState(mspec,0,'mu_sh');
dm_col = 'Orange';

% Markup
laf_sh = getState(mspec,0,'laf_sh');
mrk_col = 'LimeGreen';

% List of Shocks
shocks_list = {laf_sh};    %{[b_sh g_sh mu_sh];laf_sh};

% List of Colors
colors_list = {mrk_col};   %{dm_col;mrk_col};

% List of Names
names_list  = {'Markup'};  %{'Demand','Markup'};

%save_name   = 'Demand_Vs_Markup';
save_name   = 'Demand_Vs_Markup_PiTilOnly_mrkup';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% choose the variables %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if mspec == 803
    var_num = [12]; %[1 2 4 9 11 12];
elseif mspec == 904
    var_num = [14]; %[1 2 4 11 13 14];
end

% we want pitil baby -- replace St variable with pitil variable
kSt = find(strcmp(varnames,'\kappa (1+\iota_p\bar{\beta}) S^{\infty}_t'));
St  = find(strcmp(varnames,'S^{\infty}_t'));
A = fnGenPiTil(ti,Ys(2:end,:),Means.shockdec(:,1:I-1,1,laf_sh)',kSt,priotheta,mspec);
B = fnGenPiTil(ti,Means.shockdec(:,1:I-1,1,mu_sh)',Means.shockdec(:,1:I-1,1,b_sh)',kSt,priotheta,mspec);
C = fnGenPiTil(ti,Means.trend(:,1:I-1)',Means.trend(:,1:I-1)',kSt,priotheta,mspec);

Ys(:,St) = NaN;
Means.shockdec(St,:,1,:) = NaN;

Ys(2:end,St) = 4*A(:,1);
Means.shockdec(St,1:I-1,1,laf_sh) = 4*A(:,2)';
Means.shockdec(St,1:I-1,1,mu_sh) = 4*B(:,1)';
Means.shockdec(St,1:I-1,1,b_sh) = 4*B(:,2)';
Means.trend(St,1:I-1) = 4*C(:,1)';

varnames{St} = 'Fund. Infl.';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot our series %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% plotting 
N = length(var_num);
nfig = ceil(N/6);
figs = nan(1,nfig);

% indices of Means.shockdec to plot
% ind_sirf = sirf_shockdec-Startdate+1;
% ind_sirf = ind_sirf(1:end-1);

sirf_shockdec = 1:length(tiI);
ind_sirf = sirf_shockdec(1:end-1);

% object to store plot handles for the legend
shHandle = nan(1,length(shocks_list));

% plot that ish
for F = 1:nfig
    figs(F) = figure(2);
    for P = 1:min(6,N-(F-1)*6)
        ind = var_num((F-1)*6+P);                       % index
        
        dp = plot(tiall(sirf_shockdec(2:end)),...
            (Ys(sirf_shockdec(2:end),ind)-...
            Means.trend(ind,ind_sirf)')/4,'Color',...
            model_col,'LineStyle','-');                 % plot data
        hold on;
        
        plot(tiall((sirf_shockdec(2:end))),...
            0*tiall((sirf_shockdec(2:end))),'--','Color',rgb('Gray'));
        
        shock_plot_all= nan(length(shocks_list),...
            length(sirf_shockdec));
        
        for I = 1:length(shocks_list)                   % plot shock dec
            sh_num = shocks_list{I};
            shock_plot = zeros(size(sirf_shockdec));
            for J = 1:length(sh_num)
                shock_plot(2:end) = shock_plot(2:end) +...
                    squeeze(Means.shockdec(ind,ind_sirf,1,sh_num(J))) -...
                    Means.trend(ind,ind_sirf);
            end
            shock_plot(1) = NaN;
            shHandle(I) = plot(tiall(sirf_shockdec),...
                shock_plot/4,'Color',rgb(colors_list{I}));
            
            shock_plot_all(I,:) = shock_plot;
            
        end
        xlim([tiall(sirf_shockdec(2)),tiall(sirf_shockdec(end))]);
        
    end

    % save
    if ~exist(gpath,'dir'), mkdir(gpath); end
    saveas(figs(F),[gpath,'simple_shockdec_',num2str(F),'_',save_name,'_',...
        lmodel,lprior,ds,ssf,num2str(100*ti(I)),...
        num2str(nlags),num2str(T0),num2str(jstep),parstr],'pdf')
end
        
        
        
        

