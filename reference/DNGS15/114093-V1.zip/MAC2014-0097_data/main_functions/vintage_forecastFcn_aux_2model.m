%                                   OVERVIEW
% forecastFcn.m: a function called on by forecast_parallel.m. This function
%                takes draws allocated each worker to calculate forecasts,
%                counterfactuals, shock decompositions, and smoothed shock
%                estimates, both unconditional and conditional on Dick Peach's forecast.
% 
% forecastFcn.m is broken up into 4 main steps: 
%
% STEP 1: Get matrices of the state transition and
%         measurement equations. In gibb.m, these 
%         matrices are computed and condensed, so here we read in and
%         reshape the input data.  
% STEP 2: Run the Kalman filter. 
% STEP 3: Run the Kalman smoother to get a sequence of smoothed states (S_0/T,...,S_T/T). 
%         In this step, we also get a sequence of smoothed shocks, which we
%         plot (these figures are referred to as "shock histories"). 
% STEP 4: Using S_{T/T}, compute forecasts. With S_{0/T}, compute the
%         deterministic trend. Using a subset of the sequence of smoothed states, 
%         we can compute the counterfactuals and shock decompositions. 
% 
% The state transition equation is: S_t = TTT*S_t-1+RRR*eps_t
% The measurement equation is: Y_t = ZZ*S_t+DD
% 
%                           IMPORTANT INPUTS
% k: worker number index (used to ensure workers receive independently randomized seeds)
%
% priotheta: parameter draws
% TTTsim,RRRsim: state transition equation matrices
% zendsim: end-of-sample smoothed state vector (from gibb.m)
% 
% zerobound: flag specifying zerobound model (incorporates anticipated shocks)
% bdd_int_rate: flag specifying bounded interest rate rule
% nant,antlags: number of anticipated shocks, number of past periods in
%               which ZB was in effect. 
% nshocks_all: total number of shocks (incl. anticipated shocks)
% 
% peachflag: (if 0) no conditional data ("unconditional forecast")
%            (if 1) use conditional forecasts and data for all observables
%                   except labor share ("conditional forecast")
%            (if 2) use conditional data for spreads and FFR only
%                   ("semi-conditional forecast")
% peachdata, semi_peachdata: conditional, semi-conditional data
% 
% simple_forecast: (if 1): just compute the unconditional forecast
% qahead, qahead_extra: number of quarters ahead to forecast if
%                       unconditional forecast, or if conditional or 
%                       semi-conditional forecast.
% YY, YY0: observable data, pre-sample observable data
% nobs: length of observable time series
% stime: index for the current quarter, relative to the observable time series
% 
% Startdate: Index for counterfactual start date. Also, index for shock
%            decomposition figure start date. 
% Enddate_forecastfile: total number of quarters in the observable time 
%                       series and the forecast period: stime + qahead

%                               OUTPUTS
% fcast: forecast; there are subfields for unconditional, semi-conditional,
%        conditional, and (if zerobound) their bounded forecast counterparts
% 
% varargout (optional outputs): 
% shocks: smoothed shock histories
% ytrend: steady state, for shock decomposition plots
% dettrend: deterministic trend, for shock decomposition plots
% shockdec_all: shock contributions to forecast, for shock decomposition plots
% counter_all: counterfactual forecasts
% 
%                           IMPORTANT SUBFUNCTIONS
% augmentFilter.m, augmentSmoother.m: augments relevant matrices for the Kalman Filter and Smoother
% kalcvf2NaN.m: runs the Kalman Filter
% kalsmth_k93.m: runs the Kalman Smoother using algorithm in (Koopman 1993)


function [fcast,varargout] = vintage_forecastFcn_aux_2model(k,priotheta,alternativeTheta,...
    mspec,peachflag,simple_forecast,...
    nvar,qahead,qahead_extra,nshocks_all,YY,nobs,peachdata,psize,peachvar,...
    Enddate_forecastfile,Startdate,stime,ShockremoveList,...
    varnames,names_shocks,...
    nstate,nshocks,sflag,YY0,...
    valid_para,nlags,npara,para_names,Hbar)

% Set new seed (random number sequence) for each worker
rand('state',sum(100*clock+k))
randn('state',sum(100*clock+k))

nDraws = size(priotheta,1); % Number of draws distributed. Matrices holding draws have already been indexed by jstep in forecast_parallel.m. 

if sflag
    genHair = 1;
    fcastDecomp = 1;
end

%% Initialize output variables 

fcast.uncond_hist = zeros(nDraws,(nvar)*stime);
fcast.uncond = zeros(nDraws,(nvar)*qahead);

if peachflag
    fcast.cond_hist = zeros(nDraws,(nvar)*stime);
    fcast.cond = zeros(nDraws,(nvar)*qahead);    
end

if ~simple_forecast
    shocks.data = zeros(nDraws,nshocks_all*size(YY',2));
    if peachflag
        shocks.dick = zeros(nDraws,nshocks_all*(size(peachdata,1)));
        shocks.datawdick = zeros(nDraws,nshocks_all*size(YY,1));
    end
    ytrend = zeros(nDraws,nvar);
%     dettrend = zeros(nDraws,nvar*(Enddate_forecastfile - Startdate + 1),peachflag+1);
    dettrend = zeros(nDraws,nvar*(Enddate_forecastfile),peachflag+1);
%         counter_all = zeros(nDraws,nvar*(Enddate_forecastfile - Startdate),peachflag+1,length(ShockremoveList));
    counter_all = zeros(nDraws,nvar*(Enddate_forecastfile - 1),peachflag+1,length(ShockremoveList)); % FOR FULL HIST COUNTER
%     shockdec_all = zeros(nDraws,nvar*(Enddate_forecastfile - Startdate + 1),peachflag+1,length(ShockremoveList) - 1);
    shockdec_all = zeros(nDraws,nvar*(Enddate_forecastfile),peachflag+1,length(ShockremoveList) - 1);
end


%% Loop through parameter draws
for a = 1:nDraws

        %% NaN out FFR for 2model solution
        Tplus = size(YY,1)-length(Hbar);
        YY(Tplus+1:end,[5]) = YY(Tplus+1,[5])*NaN;
        
        params=priotheta(a,:)';
        paramsAlt = alternativeTheta(a,:)';
        
        [TTT,RRR,CCC,valid] = dsgesolv(params,mspec);%GENERATE TTT RRR (sim), since all we save is parasim
        
        [ZZ,DD,DDcointadd,QQ,EE,MM,retcode] = getmeasur(mspec,TTT,RRR,valid,params,nvar,nlags,npara,0,0);
        
        %% Add auxilary variables to ZZ block
        eval(['[ZZ, DD, QQ] = auxMeasur',num2str(mspec),'(ZZ, DD, QQ, mspec, TTT, params, paramsAlt, 0);']);
        
        %% This section generates the time-varying transition equation
        %% necessary to take into account the zerobound with the two model
        %% solution.
        
        model2_num = '001';
        TTT_T = repmat(TTT,[1,1,size(YY,1)]);
        RRR_T = repmat(RRR,[1,1,size(YY,1)]);
        CCC_T = repmat(CCC,[1,1,size(YY,1)]);
        
        TTT_T_all = repmat(TTT,[1,1,size(YY0,1)+size(YY,1)]);
        RRR_T_all = repmat(RRR,[1,1,size(YY0,1)+size(YY,1)]);
        CCC_T_all = repmat(CCC,[1,1,size(YY0,1)+size(YY,1)]);
        
        TTT_T_seq = cell(size(Hbar));
        RRR_T_seq = cell(size(Hbar));
        CCC_T_seq = cell(size(Hbar));

        for hh = size(Hbar,1):-1:1
       
            % solve
            [Tcal, Rcal,Ccal,Tbar, num_z] = get_gensys2(params, mspec, model2_num, nshocks, Hbar(end-hh+1,1));
            
            % saving the sequence of transition equations that arises from
            % receiving a new estimate of forward guidance in each period
            % (this sequence of forward guidance estimates is held in Hbar)
            TTT_T(:,:,end-hh+1) = Tcal(:,:,1);
            RRR_T(:,:,end-hh+1) = Rcal(:,:,1);
            CCC_T(:,:,end-hh+1) = Ccal(:,:,1);
            
            % longer version to deal with pre-sample
            TTT_T_all(:,:,end-hh+1) = Tcal(:,:,1);
            RRR_T_all(:,:,end-hh+1) = Rcal(:,:,1);
            CCC_T_all(:,:,end-hh+1) = Ccal(:,:,1);
            
            % save full sequences for 2-model solution hairplots
            TTT_T_seq{end-hh+1} = Tcal;
            RRR_T_seq{end-hh+1} = Rcal;
            CCC_T_seq{end-hh+1} = Ccal;
            
        end
        
        HH = EE+MM*QQ*MM';
        VV = QQ*MM';
        VVall = [[RRR*QQ*RRR',RRR*VV];[VV'*RRR',HH]];
        lead=1;

         %% Define the initial mean and variance for the state vector
         A0 = zeros(nstate,1);
         P0 = dlyap(TTT,RRR*QQ*RRR');
         
         
         [pyt0,zend,pend,pred0,vpred0] = kalcvf2NaN(YY0',1,zeros(nstate,1),TTT,DD,ZZ,VVall,A0,P0);
         
         % HERE IS WHERE WE USE KALCVF2NAN_ALL TO DEAL WITH TIME
         % VARYING TTT AND RRR AND CCC (RH: 2014-01-24)
         type = struct('C',{3},'T',{3},'R',{3},'Q',{1},'Z',{1},'H',{1},'b',{1});
         
         [L,zend,pend,pred,vpred,filt,vfilt] = kalcvf2NaN_all(YY',lead,CCC_T,TTT_T,DD,ZZ,...
             RRR_T,QQ,EE+MM*QQ*MM',RRR*VV,type,zend,pend);

    
    %% STEP 2 (Unconditional data): Kalman Filter
    
    % If we are only doing an unconditional forecast we can just skip
    % to the end since all we need is zend, which we already loaded in.
    if peachflag == 1 || simple_forecast == 0
            HH = EE+MM*QQ*MM';
            VV = QQ*MM';
            VVall = [[RRR*QQ*RRR',RRR*VV];[VV'*RRR',HH]];
            lead = 1;
            
            A0 = zeros(nstate,1);
            P0 = dlyap(TTT,RRR*QQ*RRR');
            
            % Kalman filtering over the presample
            if ~isempty(YY0)
                [pyt0,zend,pend,pred0,vpred0,a_,b_,c_,d_,filt0,vfilt0] = kalcvf2NaN(YY0',1,zeros(nstate,1),TTT,DD,ZZ,VVall,A0,P0);
            else
                zend = A0;
                pend = P0;
            end

                
            % Filter over the main sample.
            % HERE IS WHERE WE USE KALCVF2NAN_ALL TO DEAL WITH TIME
            % VARYING TTT AND RRR AND CCC (RH: 2014-01-24)
            zend_plus = zend;
            pend_plus = pend;
            
            type = struct('C',{3},'T',{3},'R',{3},'Q',{1},'Z',{1},'H',{1},'b',{1});
            
            [L,zend,pend,pred,vpred,filt,vfilt] = kalcvf2NaN_all(YY',lead,CCC_T,TTT_T,DD,ZZ,...
                RRR_T,QQ,EE+MM*QQ*MM',RRR*VV,type,zend,pend);
            
            % So now we want the filtered state at 2008Q3+
            YY_plus = YY(1:Tplus,:);
            YY_plus(end,[1:4 6:7 9:end]) = NaN;
            
            [L_plus,zend_plus,pend_plus,pred_plus,vpred_plus,filt_plus,vfilt_plus] =...
                kalcvf2NaN_all(YY_plus',lead,CCC_T(:,:,1:177),TTT_T(:,:,1:Tplus),DD,ZZ,...
                RRR_T(:,:,1:Tplus),QQ,EE+MM*QQ*MM',RRR*VV,type,zend_plus,pend_plus);
            
            
            zend_uncond = zend;
            pend_uncond = pend;
            
        %% STEP 3 (Unconditional data): Kalman Smoother
        
        if ~simple_forecast
            pred_all = [pred0,pred];
            
            vpred_all = zeros(nstate,nstate,size(YY0,1)+size(YY,1));
            vpred_all(:,:,1:size(YY0,1)) = vpred0;
            vpred_all(:,:,size(YY0,1)+1:end) = vpred;
            
            YY_all = [YY0;YY];
            
            % Short semicond YY
            
            pred_all_plus = [pred0,pred_plus];
            
            vpred_all_plus = zeros(nstate,nstate,size(YY0,1)+size(YY_plus,1));
            vpred_all_plus(:,:,1:size(YY0,1)) = vpred0;
            vpred_all_plus(:,:,size(YY0,1)+1:end) = vpred_plus;
            
            YY_all_plus = [YY0;YY_plus];
            
            % This section does the smoothing. For the zero bound,
            % this can be done in one step, since there is code in
            % both the Kalman Smoother and Simulation Smoother that
            % set the QQ matrix to zero in all periods before the
            % model switch, which ensures that the smoothed shocks
            % include no anticipated shocks prior to that time.
            
            
            [sm_states_all,sm_shocks_all] = kalsmth_k93(A0,P0,YY_all',pred_all,vpred_all,TTT,RRR,QQ,ZZ,DD,0,psize);
            
            % HERE IS WHERE WE USE KALCVF2NAN_ALL TO DEAL WITH TIME
            % VARYING TTT AND RRR AND CCC (RH: 2014-01-24)
            type = struct('C',{3},'T',{3},'R',{3},'Q',{1},'Z',{1},'H',{1},'b',{1});
            
            [sm_states_all,sm_shocks_all] = kalsmth_k93_all(A0,P0,YY_all',pred_all,...
                vpred_all,CCC_T_all,TTT_T_all,RRR_T_all,QQ,EE+MM*QQ*MM',ZZ,DD,type);
            
            % short 08Q3+ sample
            [sm_states_all_plus,sm_shocks_all_plus] = kalsmth_k93_all(A0,P0,YY_all_plus',...
                pred_all_plus,vpred_all_plus,CCC_T_all(:,:,1:Tplus+size(YY0,1)),...
                TTT_T_all(:,:,1:Tplus+size(YY0,1)),RRR_T_all(:,:,1:Tplus+size(YY0,1)),...
                QQ,EE+MM*QQ*MM',ZZ,DD,type);

            
            % Since we smoothed back farther than we needed to
            % (even before the presample), we only need parts of
            % sm_states_all and sm_shocks_all.
            
            z0T = zeros(nstate,peachflag+1);
            z0T(:,1) = sm_states_all(:,size(YY0,1));
            
            sm_states = sm_states_all(:,size(YY0,1)+1:end);
            sm_shocks = sm_shocks_all(:,size(YY0,1)+1:end);
            
            % z0T is the smoothed time 0 state vector. If peachflag
            % is on it will have two columns to hold one vector
            % smoothed without peachdata, and one smoothed with
            % peachdata.
            
            %% Decompose conditional GR foreasts into important components
            if fcastDecomp
                
                zend_Tf = zend_plus;
                shocks_Tf = sm_shocks(:,Tplus:end);
                shocks_Tf(:,1) = shocks_Tf(:,1) - sm_shocks_all_plus(:,Tplus+size(YY0,1));
                
                % no markup (or markup only)
                scenario_name = two_model_scenarios_spec();
                if strcmp(scenario_name,'no_shocks')
                    shocks_Tf(:,:) = 0;
                elseif strcmp(scenario_name,'mrkup_only')
                    shocks_Tf([1:4 6:end],:) = 0;
                elseif strcmp(scenario_name,'no_mrkup')
                    shocks_Tf(5,:) = 0;
                elseif ~strcmp(scenario_name,'all_shocks')
                    error([scenario_name,' is not a valid forecast decomposition option']);
                end
                
                resid_0 = sm_states_all(:,176+size(YY0,1)) - sm_states_all_plus(:,176+size(YY0,1));
                
                test_list = {'no_zlb','zlb'};
                fcast_d_scenarios = NaN(size(shocks_Tf,2),size(YY,2),size(test_list,2));
                
                for i = 1:length(test_list)
                    
                    for hh = size(Hbar,1):-1:1
                        
                        if strcmp(test_list{i},'no_zlb')
                            TTT_T(:,:,end-hh+1) = TTT;
                            RRR_T(:,:,end-hh+1) = RRR;
                            CCC_T(:,:,end-hh+1) = CCC;
                            
                            TTT_T_all(:,:,end-hh+1) = TTT;
                            RRR_T_all(:,:,end-hh+1) = RRR;
                            CCC_T_all(:,:,end-hh+1) = CCC;
                        elseif strcmp(test_list{i},'zlb')
                            [Tcal, Rcal,Ccal,Tbar, num_z] = get_gensys2(params, mspec,...
                                model2_num, nshocks, Hbar(end-hh+1,1));
                            TTT_T(:,:,end-hh+1) = Tcal(:,:,1);
                            RRR_T(:,:,end-hh+1) = Rcal(:,:,1);
                            CCC_T(:,:,end-hh+1) = Ccal(:,:,1);
                            
                            TTT_T_all(:,:,end-hh+1) = Tcal(:,:,1);
                            RRR_T_all(:,:,end-hh+1) = Rcal(:,:,1);
                            CCC_T_all(:,:,end-hh+1) = Ccal(:,:,1);
                        end
                    end
                    
                    TTT_Tf = TTT_T(:,:,177:end);
                    RRR_Tf = RRR_T(:,:,177:end);
                    CCC_Tf = CCC_T(:,:,177:end);
                    
                    [fcast_d,resid_fd] = forecast_decomp(ZZ,DD,CCC_Tf,TTT_Tf,RRR_Tf,shocks_Tf,zend_Tf,1,resid_0);
                    if strcmp(test_list{i},'_nozlb') && strcmp(scenario_name,'no_shocks')
                        fcast_d_scenarios(:,:,i) = fcast_d'; % get base forecast
                    else
                        fcast_d_scenarios(:,:,i) = fcast_d'+resid_fd'; % add in init conditions...
                    end
                    
                end    
            end
            
            %% Generate Hairplots
            if genHair
                
                hair = hairplots_tv(mspec,sm_states,1,178,TTT,TTT_T_seq,CCC,CCC_T_seq,200);
                
                % Alternative parameters
                [TTT_alt,RRR_alt,CCC_alt,valid_alt] = dsgesolv(paramsAlt,mspec,0);
                
                TTT_T_alt = repmat(TTT,[1,1,size(YY,1)]);
                RRR_T_alt = repmat(RRR,[1,1,size(YY,1)]);
                CCC_T_alt = repmat(CCC,[1,1,size(YY,1)]);
                
                TTT_T_seq_alt = cell(size(Hbar));
                RRR_T_seq_alt = cell(size(Hbar));
                CCC_T_seq_alt = cell(size(Hbar));
                
                for hh = size(Hbar,1):-1:1
                    [Tcal, Rcal,Ccal,Tbar, num_z] = get_gensys2(paramsAlt, mspec, model2_num, nshocks, Hbar(end-hh+1,1));
                    TTT_T_alt(:,:,end-hh+1) = Tcal(:,:,1);
                    RRR_T_alt(:,:,end-hh+1) = Rcal(:,:,1);
                    CCC_T_alt(:,:,end-hh+1) = Ccal(:,:,1);
                    
                    TTT_T_seq_alt{end-hh+1} = Tcal;
                    RRR_T_seq_alt{end-hh+1} = Rcal;
                    CCC_T_seq_alt{end-hh+1} = Ccal; 
                end
                
                hair_alt = hairplots_tv(mspec,sm_states,1,178,TTT_alt,TTT_T_seq_alt,CCC_alt,CCC_T_seq_alt,200);
            end
            
            % Calculate shock histories
            QQinv = zeros(nshocks);
            QQinv(QQ > 0) = QQ(QQ > 0).^(-1/2);
            sm_sdz_shocks = QQinv*sm_shocks;
            
            shocks.data(a,:) = sm_sdz_shocks(:)';
            
        end
        
        total_filt=[];
        total_vfilt=[];
        total_smth=[];
        total_vsmth=[];
        
        %% Kalman filtering and smoothing over conditional data
        
        if peachflag 
            
            %% STEP 2 (Conditional Data): Kalman filter
            % Since the new smoothers and filter can automatically deal
            % with NaNs in the data matrix, the code can be much
            % simplified.
            VVall = zeros(nstate+length(peachdata));
            VVall(1:nstate,1:nstate) = RRR*QQ*RRR';
            VVall_peach = VVall;
            VVall_peach(nstate+1:nstate+nvar,nstate+1:nstate+nvar) = diag(peachvar);

            [L,zend_peach,pend_peach,pred_peach,vpred_peach] = kalcvf2NaN(peachdata',lead,zeros(nstate,1),TTT,DD_e,ZZ_e,VVall_peach,zend,pend);
 
            %% STEP 3 (Conditional Data): Kalman smoother
            
            YY_all_peach = [YY_all;peachdata];
            
            pred_all_peach = [pred_all,pred_peach];
            
            vpred_all_peach = zeros(length(TTT),length(TTT),size(YY_all_peach,1));
            vpred_all_peach(:,:,1:size(YY_all,1)) = vpred_all;
            vpred_all_peach(:,:,size(YY_all,1)+1:end) = vpred_peach;
            
            [sm_states_all_peach,sm_shocks_all_peach] = kalsmth_k93(A0_,P0_,YY_all_peach',pred_all_peach,vpred_all_peach,TTT,RRR,QQ,ZZ_e,DD_e,nant,antlags,1,psize);
            
            z0T(:,2) = sm_states_all_peach(:,size(YY0,1));
            
            sm_states_peach = sm_states_all_peach(:,size(YY0,1)+1:end);
            sm_shocks_peach = sm_shocks_all_peach(:,size(YY0,1)+1:end);
            

            % Calculate conditional shocks histories
            sm_sdz_shocks_peach = QQinv*sm_shocks_peach;
            shocks.datawdick(a,:) = reshape(sm_sdz_shocks_peach(:,1:size(YY,1)),1,nshocks*size(YY,1));
            shocks.dick(a,:) = reshape(sm_sdz_shocks_peach(:,size(YY,1)+1:end),1,nshocks*psize);
            peachdataimplied = getpeachdataimplied(size(peachdata,1),ZZ,DD,sm_states_peach(:,end-size(peachdata,1)+1:end));
            
            sm_states_semipeach = [];
            sm_shocks_semipeach = [];
            
        else
            
            sm_states_peach = [];
            sm_shocks_peach = [];
            
            sm_states_semipeach = [];
            sm_shocks_semipeach = [];
            
        end
        
    else
        % For simple_forecast with no conditional forecast, zend is all we need.
        zend_uncond = zend;
    end
    
    %% STEP 4: Compute forecasts
    
    ind_r = find(strcmp(varnames,'Interest Rate'));
    ind_r_sh = find(strcmp(names_shocks,'r_m'));
        
    
    % ALT POLICY
    %params(13) = 1.2;
    %params(14) = 0;
    %[TTT,RRR,CCC,valid] = dsgesolv(params,mspec);
    
    % Conditional forecast
    if peachflag
        [yypred] = getVForecast(qahead_extra,nvar,nshocks,TTT,RRR,DD,ZZ,QQ,zend_peach,sflag);
        
        yypred_nocoint = [peachdataimplied; yypred(:,1:nvar)];
        
        fcast.cond(a,:) = yypred_nocoint(:)';
        
    end
    
    % Unconditional forecast
    [yypred] = getVForecast(qahead,nvar,nshocks,TTT,RRR,DD,ZZ,QQ,zend_uncond,sflag);
    fcast.uncond(a,:) = yypred(:)';
    
    
    % Counterfactuals, shock decompositions, deterministic trends, and steady states
    if ~simple_forecast
        ytrend(a,:) = DD';
        dettrend(a,:,:) = getdettrend_fullHist(Enddate_forecastfile,nvar,ZZ,TTT,DD,z0T,Startdate,peachflag);
        counter_all(a,:,:,:) = getcounter_fullHist(ShockremoveList,peachflag,psize,Enddate_forecastfile,...
            sm_states,sm_shocks,sm_states_peach,sm_shocks_peach,...
            Startdate,nobs,nshocks,qahead_extra,nvar,TTT,RRR,DD,ZZ);
        shockdec_all(a,:,:,:) = getshockdec_fullHist(ShockremoveList,peachflag,psize,Enddate_forecastfile,...
            sm_shocks,sm_shocks_peach,...
            Startdate,nobs,qahead_extra,nvar,TTT,RRR,DD,ZZ);
    end
end

if ~simple_forecast
    varargout{1} = shocks;
    varargout{2} = ytrend;
    varargout{3} = dettrend;
    varargout{4} = counter_all;
    varargout{5} = shockdec_all;
    if peachflag == 1
        varargout{6} = sm_states_peach(:,1:end-1);
    else
        varargout{6} = sm_states;
    end
    
    if genHair
        varargout{7} = hair;
        varargout{8} = hair_alt;
    end
    
    if fcastDecomp
        varargout{9} = fcast_d_scenarios;
    end
end