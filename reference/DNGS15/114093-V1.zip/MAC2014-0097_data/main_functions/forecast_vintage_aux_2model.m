% OVERVIEW
% forecast_parallel.m: Computes various forecasts using vcSubmitQueuedJobs.m to
%                      distribute draws among workers. Each worker
%                      constructs forecasts using vintage_forecastFcn_aux.m. 
%
%                      This program uses draws from gibb.m to create forecasts, 
%                      counterfactuals,shock decompositions, and smoothed shock 
%                      estimates, both unconditional and conditional on Dick Peach's forecast.
% 
% IMPORTANT SUBFUNCTIONS
% setInfiles.m, setOutfiles.m: specify infiles and outfiles
% vintage_forecastFcn_aux.m: subfunction distributed to each worker, to compute
%                forecasts.
% 
% CHANGES:                   
% DG 7/16/10
% This version includes the update that replaces the Kalman Smoother and
% Simulation Smoother with new versions. Since these automatically
% calculate or draw the shocks, there is no need to augment the states
% vector or model matrices to "catch" the shocks during smoothing. This
% means that the regular TTT,RRR,and ZZ matrices can be used, and the
% augmented versions are not needed.
%
% Additionally, since the new smoothers can automatically deal with NaNs in
% the data series, the code conditioning on Dick's forecast is
% significantly simplified.
%
% Finally in terms of naming conventions, what was called sm_sample and
% sm_revised are now broken up in to sm_states and sm_shocks, and
% sm_states_peach and sm_shocks_peach, respectively.
% 
% JC 11/10/2011
% This new version of our forecasting program uses vcSubmitQueuedJobs.m to
% distribute draws among workers. Old version: parforecast.m
% setInfiles.m, setOutfiles.m, augmentFilter.m, augmentSmoother.m are new. 

tic;

%% Initialization
keepVars;
spec_realtime;

% for modal analysis
sflag=1; 

initializePrograms;

%% For modal analysis
if sflag
    distr = 0;
    parstr = 'Mode';
    nsim = 1;
    jstep = 1;
    nblocks=1;
    nburn=0;
end

%% Specifications

if ~any(ShockremoveList == 0)
    ShockremoveList = [0 ShockremoveList];
end

%% Read infiles
%% SHOULD results stored in realtime mat file or in the usual binary file
loadParams;

% DETTREND THE WAGES!!!
if bol_detrend_w
    YY = detrend_wages(YY,mspec,priotheta,varnames,tiI,1980);
    YYall = detrend_wages(YYall,mspec,priotheta,varnames,tiI,1980);
end
%% Open outfiles 

% Use spath_overwrite if you want to save output files to a different
% folder than spath.
if exist('spath_overwrite','var'), spath = spath_overwrite; end 

% List data to be written
outdataType = {'hist','forecast'};

if peachflag,
    outdataType = union(outdataType,{'condhist','condforecast'});
end
if ~simple_forecast,
  outdataType = union(outdataType,{'states','condforecast','dickshocks','condshocks','datashocks',...
      'counter','shockdec','ytrend','dettrend','dettrend_peach'});
end

% Create outfile structure (output filenames)
[outfile] = setOutfiles(outdataType,...
    spath,lmodel,lprior,ds,ssf,ti,I,nlags,T0,jstep,parstr,...
    peachflag,peachstr,...
    ShockremoveList,Startdate,Enddate_forecastfile);

% Open outfiles to write
% fid*: output file handle (set to read)
if overwrite
  listOutfiles = fieldnames(outfile);
  for iOutfile = 1:length(listOutfiles)
    outfileName = listOutfiles{iOutfile};
    fid.(outfileName) = fopen(outfile.(outfileName),'w');
  end
end

%% Load in peachdata and specify qahead_extra
% peachdata (nT x nvar): a matrix of conditional data (usually Dick Peach's
%                        nowcast). If we are doing a conditional forecast, 
%                        we append peachdata to the end of our observed data. 
% qahead_extra: If we are doing a conditional forecast, we forecast
%               qahead_extra (59Q) quarters ahead (psize (1Q) quarters less 
%               than the unconditional forecast) instead of qahead (60Q). 
peachvar=nan(1,nvar);
if peachflag > 0,
  loadvintage;
  peachdata=nan(1,nvar);
  
  peachvar(5) = 0;%FFR Error
  peachdata(5) = vintend.exp(1,3);%FFR Nowcast
  
  if any(mspec==[804 904]);
    peachdata(8) = vintend.final(1,8);%spread nowcast?
    peachvar(8) = 0;
  end
  
  if size(peachdata,2) < nvar
    peachdata = [peachdata,NaN(size(peachdata,1),nvar-size(peachdata,2))];
  end
  
  qahead_extra = qahead - size(peachdata,1);
else
  peachdata = [];
  qahead_extra = qahead;
end

%% Load in parameter draws, state transition equation matrices, and zend (output from gibb.m)
% priotheta: parameter draws
% TTTsim, RRRsim, CCCsim: S_t = TTT*S_(t-1) + RRR*eps_t + CCC
% zendsim: end-of-sample smoothed state: S_(T/T)

priotheta = priotheta(jstep:jstep:nsim,:);

%% Distribute draws to nMaxWorkers, as input for vintage_forecastFcn_aux.m
% idx: how many draws to distribute to each worker
% JobOptions: holds input (to function irfsimFcn.m) for each of the nMaxWorkers
% nout: number of output arguments
% pathdep.m: a program that establishes variable PathDependencies
% JobOut: holds output from vintage_forecastFcn_aux.m

if distr
    if simple_forecast, nout = 1; else nout = 6; end

    JobOptions = cell(1,nMaxWorkers);
    for k = 1:nMaxWorkers
        idx = ceil(nsim/(jstep*nMaxWorkers))*(k-1)+(1:ceil(nsim/(jstep*nMaxWorkers)));
        idx = idx(idx<=nsim/jstep);
        JobOptions{k} = {k,originalTheta(idx,:),priotheta(idx,:),...
                         mspec,peachflag,simple_forecast,...
                         nvar,qahead,qahead_extra,nshocks,YY,nobs,peachdata,psize,peachvar,...
                         Enddate_forecastfile,Startdate,stime,ShockremoveList,...
                         varnames,names_shocks,...
                         nstate,nshocks,sflag,YY0,...
                         valid_para,nlags,npara,para_names,Hbar};

        pathdep;
    end

    JobOut = vcSubmitQueuedJobs(nMaxWorkers,@vintage_forecastFcn_aux_2model,nout,JobOptions,PathDependencies,nMaxWorkers);

    % Concatenate output across workers
    temp_fcast = [JobOut{:,1}]; 
    fcast.uncond = cat(1,temp_fcast(:).uncond);
    if peachflag
        fcast.cond = cat(1,temp_fcast(:).cond); 
    end

    if ~simple_forecast
        temp_shocks = [JobOut{:,2}]; 
        shocks.data = cat(1,temp_shocks(:).data);
        if peachflag 
            shocks.dick = cat(1,temp_shocks(:).dick);
            shocks.datawdick = cat(1,temp_shocks(:).datawdick);
        end
        ytrend = cat(1,JobOut{:,3});
        dettrend = cat(1,JobOut{:,4});
        counter_all = cat(1,JobOut{:,5});
        shockdec_all = cat(1,JobOut{:,6});
    end

    clear JobOut JobOptions;

else

%% Compute forecasts for each draw sequentially (if debugging, for example)
    k=1;
    if sflag
        [fcast,shocks,ytrend,dettrend,counter_all,shockdec_all,sm_states,hair,hair_alt,fcast_d_scenarios] = vintage_forecastFcn_aux_2model(k,originalTheta,priotheta,...
            mspec,peachflag,simple_forecast,...
            nvar,qahead,qahead_extra,nshocks,YY,nobs,peachdata,psize,peachvar,...
            Enddate_forecastfile,Startdate,stime,ShockremoveList,...
            varnames,names_shocks,...
            nstate,nshocks,sflag,YY0,...
            valid_para,nlags,npara,para_names,Hbar);
        
        if bol_cond_mc
            YY_mc = YY;
            cond_I = find(tiI==GR_dt);
            if isempty(cond_I), error('Sample doesn''t include any part of the GR! Therefore, we can''t condition on ex-post GR mc_t'); end
            
            mc_I = getState(mspec,0,'mc_t');
            
            YY_mc(cond_I+1:end,setdiff(1:nvar,[5 8])) = NaN;
            YY_mc(cond_I+2:end,[5 8]) = NaN;
            YY_mc(cond_I+1:end,mc_I) = sm_states(mc_I,cond_I+1:end)';
            
	    [~,~,~,~,~,~,cond_states,~] = vintage_forecastFcn_aux(k,originalTheta,priotheta,...
		mspec,peachflag,simple_forecast,...
		nvar,qahead,qahead_extra,nshocks,YY_mc,nobs,peachdata,psize,peachvar,...
		Enddate_forecastfile,Startdate,stime,ShockremoveList,...
		varnames,names_shocks,...
		nstate,nshocks,sflag,YY0,...
		valid_para,nlags,npara,para_names,0,0);
            
            inf_fcast_cond_mc = getInfCondMc(mspec,originalTheta,cond_states,cond_I+1);
        end
        
    else
        [fcast,shocks,ytrend,dettrend,counter_all,shockdec_all,sm_states] = vintage_forecastFcn_aux_2model(k,originalTheta,priotheta,...
            mspec,peachflag,simple_forecast,...
            nvar,qahead,qahead_extra,nshocks,YY,nobs,peachdata,psize,peachvar,...
            Enddate_forecastfile,Startdate,stime,ShockremoveList,...
            varnames,names_shocks,...
            nstate,nshocks,sflag,YY0,...
            valid_para,nlags,npara,para_names,Hbar);
    end
end

%% Save data
if overwrite
    fwrite(fid.forecast,fcast.uncond','single');

    if peachflag
        fwrite(fid.condforecast,fcast.cond','single');
    end

    if ~simple_forecast
        fwrite(fid.datashocks,shocks.data','single');
        for peachcounter = 0:peachflag
            shockcount = 0;
            for Shockremove = ShockremoveList
                shockcount = shockcount + 1;
                fwrite(fid.(['counter',num2str(peachcounter),num2str(Shockremove)]),counter_all(:,:,peachcounter+1,shockcount)','single');
            end
        end
        for peachcounter = 0:peachflag
            shockcount = 0;
            for Shockremove = ShockremoveList
                if Shockremove > 0
                    shockcount = shockcount + 1;
                    fwrite(fid.(['shockdec',num2str(peachcounter),num2str(Shockremove)]),shockdec_all(:,:,peachcounter+1,shockcount)','single');
                end
            end
        end

        if peachflag
            fwrite(fid.dickshocks,shocks.dick','single');
            fwrite(fid.condshocks,shocks.datawdick','single');
            fwrite(fid.dettrend_peach,dettrend(:,:,2)','single');
        end
        fwrite(fid.ytrend,ytrend','single');
        fwrite(fid.dettrend,dettrend(:,:,1)','single');
        
        stateOutfile = [spath,'/states',lmodel,lprior,ds,ssf,num2str(100*ti(I)),num2str(nlags),num2str(T0),peachstr{peachflag+1},num2str(jstep),parstr];
        fid.sm_states = fopen(stateOutfile,'w');
        fwrite(fid.sm_states,sm_states','single');
        
        if ~exist([spath,'hairs'],'dir'), mkdir([spath,'hairs']); end
        save([spath,'hairs/','hairplots_mc_tv_',num2str(mspec),'_',num2str(tiI(end)*100),'.mat'],'hair');
        hair = hair_alt;
        save([spath,'hairs/','hairplots_mc_tv_alt_',num2str(mspec),'_',num2str(tiI(end)*100),'.mat'],'hair');
        
        if ~exist([spath,'two_model_fcast_decomp'],'dir'), mkdir([spath,'two_model_fcast_decomp']); end
        scenario_name = two_model_scenarios_spec();
        save([spath,'two_model_fcast_decomp/','scenarios_',scenario_name,'_',num2str(tiI(end)*100),'.mat'],'fcast_d_scenarios');
        
        if bol_cond_mc
            if ~exist([spath,'mc_cond'],'dir'), mkdir([spath,'mc_cond']); end
            save([spath,'inf_GR_fcast_cond_mc_',num2str(mspec),'.mat'],'inf_fcast_cond_mc');
        end
    end
end

fclose('all');

fprintf('\n Elapsed time is %4.2f minutes',toc/60);
