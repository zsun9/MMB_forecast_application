function ok = write_two_model_scenarios_spec(scenario_name)

f = fopen('main_functions/two_model_scenarios_spec.m','w')

fprintf(f,'function scenario_name = two_model_scenarios_spec()\n');
fprintf(f,'%%%% ------------------------------------------------------------------------\n');
fprintf(f,'%% Options: mrkup_only,no_mrkup,no_shocks\n');
fprintf(f,'%% -------------------------------------------------------------------------\n');
fprintf(f,['scenario_name = ','''',scenario_name,''';']);

fclose(f);

ok = 1;