%% Plot multiple piTil series together
%% Use paraBlock to manually tinker with parameters

clearvars -except figDir mc_evol_exp; 
close all; fclose all;
[fpath,spath,gpath] = pathspec(700,figDir);
% choose swap case (1=nom rig, 2=zeta, 3=lambda rho,sig,eta, 
% 4=iota, 5=iota,zeta, 6=zeta and lambda rho,sig,eta)

if strcmp(mc_evol_exp,'pr_rigidity')
    swapOut = [0 12];
    lType   = {'r-','r--'};
    h1 = 170;        % startdate of first hair
    h2 = 177;        % staratdate of second hair (no tv) -- 2008Q3
else strcmp(mc_evol_exp, 'pr_rigidity_and_policy')
    swapOut = [0 12 7 13];
    lType = {'r','r--','bo-','bd--'};
    h1 = 177;        % only the 2008Q3 hair
end
legName = {};

%% ------------------------------------------------------------------------
% choose to plot all models / parameters to swap in
% -------------------------------------------------------------------------
allModels = 0;
swBlock   = 1;
m803Block = 0;
m805Block = 0;
m904toSWblock = 0;

%% ------------------------------------------------------------------------
% load parameter mappings between models 
% -------------------------------------------------------------------------
paraMappings;

%% ------------------------------------------------------------------------
% load parameters to swap 
% -------------------------------------------------------------------------
if swBlock
    f_sw   = fopen([spath,'smetsAndWouters2007ParaMode']);
    p_swap = fread(f_sw,'single');
    pMap   = map904toSW; 
elseif m803Block
    f_m803 = fopen([spath,'mhparam80392527000NaN20085020Mode']);
    p_swap = fread(f_m803,'single');
    pMap   = map904toSW;
elseif m805Block
    f_m805 = fopen([spath,'mhparam80592617000NaN20085020Mode']);
    p_swap = fread(f_m805,'single');
    pMap   = map904to805;
elseif m904toSWblock
    f_m904toSW = fopen([spath,'mhparam90493547000NaN20085020Mode']);
    p_swap = fread(f_m904toSW,'single');
    pMap   = mapSWto904;
end


f = figure();

for j = 1:length(swapOut)
    sO = swapOut(j);
    
    % ALL MODELS
    if m904toSWblock
        
        list = [2,10]';
        swapBlock = [list , p_swap(pMap(list))];
        
        modelInfo = struct( ...
            'specfile', { 'spec_904_aux', 'spec_803_aux_sw', 'spec_803_aux', 'spec_805_aux' },...
            'parablock', { [], swapBlock, swapBlock, swapBlock },...
            'plotName', { '904', 'SW w 904 {\zeta}s', '803 w 904 {\zeta}s', '805 w 904 {\zeta}s' },...
            'plotType', { 'k', 'b--', 'g--', 'r--' } );
        
        pltTitle = '{\zeta}s';
        fname = '904vOtherswZetas';
        
    elseif allModels
        modelInfo = struct( ...
            'specfile', { 'spec_904_aux', 'spec_805_aux', 'spec_805_aux_904p', 'spec_803_aux', 'spec_803_aux_904p', 'spec_803_aux_sw' },...
            'parablock', {[]},...
            'plotName', { '904', '805', '805w904p', '803', '803w904p', '803wSW' },...
            'plotType', { 'b-', 'r-', 'r--', 'g-', 'g--', 'm-' } );
    else
        
        switch sO
            case 0
                swapBlock = [];
                fname = '904';
                %pltTitle = '904';
                pltTitle = '';
                pltName = '';
            case 1
                % nominal rigidities swap (zeta's, iota's, lambda's)
                list = [2,3,10,11,29,30,40,41,48,49]';
                fname = '904v904wSWnomRig';
                pltTitle = '\zeta; \iota; \rho, \sigma and \eta on \lambda''s';
                pltName = '904 w SW nom. rigidities';
            case 2
                % zeta swap only
                list = [2,10]';
                fname = '904v904wSWzetas';
                pltTitle = '\zeta';
                pltName = '904 w SW \zeta';
            case 3
                % lambda rho/sigma/eta swap only
                list = [29,30,40,41,48,49]';
                fname = '904v904wSWrhosigmaeta';
                pltTitle = '\rho, \sigma and \eta on \lambdas''s';
                pltName = '904 w SW \rho,\sigma,\eta';
            case 4
                % iota swap only
                list = [3,11]';
                fname = '904v904wSWiotas';
                pltTitle = '\iota';
                pltName = '904 w SW \iota';
            case 5
                % iota and zeta swap only
                list = [2,3,10,11]';
                fname = '904v904wSWiotaszetas';
                pltTitle = '\iota, \zeta';
                pltName = '904 w SW \iota, \zeta';
            case 6
                % iota and zeta swap only
                list = [2,10,29,30,40,41,48,49]';
                fname = '904v904wSWzetaslambdas';
                pltTitle = '\zeta; \rho, \sigma and \eta on \lambda''s';
                pltName = '904 w SW nom. rig. less \iota';
            case 7
                % policy swap
                % list = [13,14,15]';
                list = [13]';
                fname = '904v904wSWpsi1_1.1';
                pltTitle = '';
                pltName = ' \psi_1 = 1.1';
                % pltTitle = '\psi_1, \psi_2, \psi_3';
                % pltName = '904 w SW policy';
                swapBlock = [13 1.1];
            case 8
                % other rhos and sigmas
                list = [25:28,31,36:39,42,47]';
                fname = '904v904wSWrhosigetaOther';
                pltTitle = '\rho, \sigma and \eta on all but {\lambda}s and FF';
                pltName = '904 w SW other \rho,\sigma,\eta';
            case 9
                % FF off
                fname = '904v904wFFoff';
                pltTitle = '\zeta{sp} = 0';
                pltName = '904 w \zeta_{sp} = 0';
                swapBlock = [21., 0.];
            case 10
                % S'', h psi, nu_l swap
                list = [6:9]';
                fname = '904v904wSWhSpsinul';
                pltTitle = 'S'''', h, \psi, \nu_l';
                pltName = '904 w SW S'''', h, \psi, \nu_l';
            case 11
                list = 1:length(pMap);
                list = list(logical(~isnan(pMap)))';
                fname = '904v904wSWTTT';
                pltTitle = '';
                pltName = '904 w SW TTT';
            case 12
                list = [2];
                fname = '904v904wSWzetap';
                pltTitle = '';
                pltName = '904 w SW \zeta_p';
            case 13
                list = [2];
                fname = '904v904wSWzetap_psi1_1_1';
                pltTitle = '';
                pltName = '904 w SW \zeta_p and \psi_1 = 1.1';
                swapBlock_1 = [13 1.1];
            otherwise
                warning('not a valid swap case');
        end
        
        if ~exist('swapBlock','var')
            swapBlock = [list , p_swap(pMap(list))];
        end
        
        if exist('swapBlock_1','var')
            swapBlock = [swapBlock;swapBlock_1];
        end
        
        modelInfo = struct( ...
            'specfile', { 'spec_904_aux_full201250' },...
            'parablock', { swapBlock },...
            'plotName', { pltName },...
            'plotType', { 'k-' } );
        
    end
    
    % Great Recession
    enddate = 235;   % enddate of plot
    startdate = 158; % startdate of plot
    
    
    T = enddate - startdate;
    series = nan*zeros( T, 4 );
    
    noMrkUp = 0;
    
    specFile      = modelInfo.specfile;
    paraBlock     = modelInfo.parablock;
    
    if exist('h3','var')
        [dates,series] = fnMcEvol( specFile, 'tv', paraBlock, startdate, enddate, h1, h2, h3);
    elseif exist('h2','var')
        [dates,series] = fnMcEvol( specFile, 'tv', paraBlock, startdate, enddate, h1, h2);
    else
        [dates,series] = fnMcEvol( specFile, 'tv', paraBlock, startdate, enddate, h1);
    end
    
    
   
    for i = 1 : size(series,2)
        if i == 1
            eval(['h',num2str(j),num2str(i),'=plot(dates, series(:,i), modelInfo.plotType,''LineWidth'',1.5);']);
        else
            if ~isempty(regexp(lType{j},'[o,^,s,v,d]'))
                eval(['h',num2str(j),num2str(i),'=plot(dates([h',num2str(i-1),'-startdate:4:end,end]), series([h',num2str(i-1),'-startdate:4:end,end],i), lType{j},''LineWidth'',1.5);']);
            else
                eval(['h',num2str(j),num2str(i),'=plot(dates, series(:,i), lType{j},''LineWidth'',1.5);']);
            end
        end
        hold on;
    end
    legName{j} = modelInfo.plotName;
    clear swapBlock;
end

ylim([-10 2]); %GR
% ylim([-6 3]); %90s
set(gca,'XTick',dates(9:16:end));
xlim([ dates(1) dates(end) ]);
title(pltTitle);
set(gca,'FontSize',20);

if ~exist(gpath,'dir'),mkdir(gpath);end
saveas(f,[gpath,'McEvol_tv',fname,'_compare.pdf']);

    
    