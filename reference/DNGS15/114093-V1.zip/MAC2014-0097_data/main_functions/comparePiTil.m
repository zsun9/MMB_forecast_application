%% Plot multiple piTil series together
%% Use paraBlock to manually tinker with parameters

%% ------------------------------------------------------------------------
% function: normalize series 
% -------------------------------------------------------------------------
normSeries = @(V) (V-nanmean(V))/nanvar(V)^.5;

%% ------------------------------------------------------------------------
% mod settings for plots 
% -------------------------------------------------------------------------
sInfBool = 0; % plot Sinf
noMrkUp  = 0; % plot counterfactual (ex markup)
addInf   = 0; % add GDPDEF
addMC    = 0; % add marginal cost
normalized = 0; % normalize series

%% ------------------------------------------------------------------------
% choose swap case (1=nom rig, 2=zeta, 3=lambda rho,sig,eta, 
% 4=iota, 5=iota,zeta, 6=zeta and lambda rho,sig,eta, ... and more)
% -------------------------------------------------------------------------
swapOut = 2;

%% ------------------------------------------------------------------------
% choose the models whose parameters we will swap in 
% -------------------------------------------------------------------------
swBlock   = 1;
m803Block = 0;
m805Block = 0;
m904toSWblock = 0;

%% ------------------------------------------------------------------------
% load parameter mappings between models 
% -------------------------------------------------------------------------
paraMappings;
[fpath,spath,gpath] = pathspec(700,figDir);

%% ------------------------------------------------------------------------
% load parameters to swap 
% -------------------------------------------------------------------------
if swBlock
    f_sw   = fopen([spath,'smetsAndWouters2007ParaMode']);
    p_swap = fread(f_sw,'single');
    pMap   = map904toSW; 
elseif m803Block
    f_m803 = fopen([spath,'mhparam80392527000NaN20085020Mode']);
    p_swap = fread(f_m803,'single');
    pMap   = map904toSW;
elseif m805Block
    f_m805 = fopen([spath,'mhparam80592617000NaN20085020Mode']);
    p_swap = fread(f_m805,'single');
    pMap   = map904to805;
elseif m904toSWblock
    f_m904toSW = fopen([spath,'mhparam90493547000NaN20085020Mode']);
    p_swap = fread(f_m904toSW,'single');
    pMap   = mapSWto904;
end


if exist('gdpdefV904VSW','var') && gdpdefV904VSW
    modelInfo = struct( ...
        'specfile', { 'spec_904_aux_full201250', 'spec_803_aux_sw' },...
        'parablock', {[]},...
        'plotName', { 'Fund. Infl.', 'SW Fund. Infl.' },...
        'plotType', { 'b-.','m--' } );
    pltTitle = '';
    fname = 'gdpdefVs904_2modelVsSWpitil';
    addInf = 1;
    
elseif exist('SWpiTilvMC','var') && SWpiTilvMC
%% ------------------------------------------------------------------------
% SW pitil vs mc normalized
% -------------------------------------------------------------------------
    modelInfo = struct( ...
        'specfile', { 'spec_803_aux_sw' },...
        'parablock', {[]},...
        'plotName', { 'SW Fund. Infl.'},...
        'plotType', {  'm-' } );
    normalized = 1;
    addMC      = 1;
    mcMspec    = 803;
    mcNm       = 'SW';
    fname = 'SW_pitil_v_mc';
    pltTitle = '';
else
%% ------------------------------------------------------------------------
% swap specific parameters from different model
% -------------------------------------------------------------------------    
    switch swapOut
        case 1
            % nominal rigidities swap (zeta's, iota's, lambda's)
            list = [2,3,10,11,29,30,40,41,48,49]';
            fname = '904v904wSWnomRig';
            pltTitle = '\zeta; \iota; \rho, \sigma and \eta on \lambda''s';
            pltName = '904 w SW nom. rigidities';
        case 2
            % zeta swap only
            %list = [2,10]';
            list = [2];
            fname = '904v904wSWzetaP';
            pltTitle = '\zeta';
            pltName = 'Fund. Infl. w/ SW \zeta_p';
        case 3
            % lambda rho/sigma/eta swap only
            list = [29,30,40,41,48,49]';
            fname = '904v904wSWrhosigmaeta';
            pltTitle = '\rho, \sigma and \eta on \lambdas''s';
            pltName = '904 w SW \rho,\sigma,\eta';
        case 4
            % iota swap only
            list = [3,11]';
            fname = '904v904wSWiotas';
            pltTitle = '\iota';
            pltName = '904 w SW \iota';
        case 5
            % iota and zeta swap only
            list = [2,3,10,11]';
            fname = '904v904wSWiotaszetas';
            pltTitle = '\iota, \zeta';
            pltName = '904 w SW \iota, \zeta';
        case 6
            % iota and zeta swap only
            list = [2,10,29,30,40,41,48,49]';
            fname = '904v904wSWzetaslambdas';
            pltTitle = '\zeta; \rho, \sigma and \eta on \lambda''s';
            pltName = '904 w SW nom. rig. less \iota';
        case 7
            % policy swap
            list = [13,14,15]';
            fname = '904v904wSWpolicy';
            pltTitle = '\psi_1, \psi_2, \psi_3';
            pltName = '904 w SW policy';
        case 8
            % other rhos and sigmas
            list = [25:28,31,36:39,42,47]';
            fname = '904v904wSWrhosigetaOther';
            pltTitle = '\rho, \sigma and \eta on all but {\lambda}s and FF';
            pltName = '904 w SW other \rho,\sigma,\eta';
        case 9
            % FF off
            fname = '904v904wFFoff';
            pltTitle = '\zeta{sp} = 0';
            pltName = '904 w \zeta_{sp} = 0';
            swapBlock = [21., 0.];
        case 10
            % S'', h psi, nu_l swap
            list = [6:9]';
            fname = '904v904wSWhSpsinul';
            pltTitle = 'S'''', h, \psi, \nu_l';
            pltName = '904 w SW S'''', h, \psi, \nu_l';
        otherwise
            warning('not a valid swap case');
    end
    
    if ~exist('swapBlock','var')
        swapBlock = [list , p_swap(pMap(list))];
    end
    
    modelInfo = struct( ...
        'specfile', { 'spec_904_aux', 'spec_904_aux' },...
        'parablock', { [],swapBlock },...
        'plotName', { 'Fund. Infl.',pltName },...
        'plotType', { 'k-', 'b--' } );
    
end

T = 192;
series = nan*zeros(T, 4, size( modelInfo,2 ) );

for i = 1 : length( modelInfo )
    specFile      = modelInfo(i).specfile;
    paraBlock     = modelInfo(i).parablock;
    
    if isfield( modelInfo, 'rwMC' )
        global rwMC;
        rwMC = modelInfo(i).rwMC;
    end
    
    if isfield( modelInfo, 'boolHelper' );
        [dates, series(:,:,i)] = fnPiTil( specFile, paraBlock, modelInfo(i).boolHelper );
    else
        [dates, series(:,:,i)] = fnPiTil( specFile, paraBlock );
    end
end

f = figure();
lwidth = 1.5;

%% ------------------------------------------------------------------------
% plot counterfactual with no markup? 
% -------------------------------------------------------------------------
if ~noMrkUp
    j = 1;
    mrkup = '';
else
    j = 2;
    mrkup = '_noMrkup';
end

%% ------------------------------------------------------------------------
% plot Sinf or PiTil? %
% -------------------------------------------------------------------------
if sInfBool
    sel = 2;
else
    sel = 0;
end

%% ------------------------------------------------------------------------
% plot GDPDEF 
% -------------------------------------------------------------------------
if exist('addInf','var') && addInf
    data = getData('spec_904_aux_full201250', 4);
    if normalized
        data = normSeries(data);
    end
    plot(dates, data,'k-','LineWidth',lwidth);
    modelInfo(end+1).plotName = 'GDPDEF';
    hold on;
end

%% ------------------------------------------------------------------------
% plot MC
% -------------------------------------------------------------------------
if exist('addMC','var') && addMC
    load([spath,'hairs/','hairplots_mc_',num2str(mcMspec),'_201250.mat']);
    hair = hair_save;
    mc = hair(1,1:T)';
    if normalized
        mc = normSeries(mc);
    end
    plot(dates,mc,'k--','LineWidth',lwidth);
    modelInfo(end+1).plotName = [mcNm,' ','mc'];
    hold on;
end

%% ------------------------------------------------------------------------
% plot series 
% -------------------------------------------------------------------------
for i = 1 : size(series,3)
    if normalized
        if iscell(modelInfo(i).plotType)
            plot(dates,normSeries(series(:,j+sel,i)), 'Color',modelInfo(i).plotType{1},'LineStyle',modelInfo(i).plotType{2},'LineWidth',lwidth);
        else
            plot(dates,normSeries(series(:,j+sel,i)), modelInfo(i).plotType,'LineWidth',lwidth);
        end
    else
        if iscell(modelInfo(i).plotType)
            plot(dates,series(:,j+sel,i), 'Color',modelInfo(i).plotType{1},'LineStyle',modelInfo(i).plotType{2},'LineWidth',lwidth);
        else
            plot(dates,series(:,j+sel,i), modelInfo(i).plotType,'LineWidth',lwidth);
        end
    end
    hold on;
end

%% ------------------------------------------------------------------------
% legend, title, xlim, ylim
% -------------------------------------------------------------------------
title(pltTitle);
xlim( [1965 2015] );
set(gca,'XTick',[1965:5:2015]);
set(gca,'FontSize',18);

%% ------------------------------------------------------------------------
% save plots
% -------------------------------------------------------------------------
if ~exist(gpath,'dir'),mkdir(gpath);end
saveas(f,[gpath,fname,'.pdf']);

    
    