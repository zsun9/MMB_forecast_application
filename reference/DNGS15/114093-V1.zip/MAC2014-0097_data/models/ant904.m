%% This defines the location of the anticipated policy shocks in TTT

ind_eq_ant = [];
ind_ant    = [];

for i = 1:nant
    ind_eq_ant(end+1) = eval(['eq_rml',num2str(i)]);
    ind_ant(end+1)    = eval(['rm_tl',num2str(i)]);
end