function [para,para_names,para_mask,para_fix,npara,polipar,polivalue,bounds] = mspec_parameters_803(subspec,dataset)

%% names of parameters
% the parameters in para_names must be lsited in the order they appear
% below and in the model's priorfile

para_names = { '\alpha';'\zeta_p';'\iota_p';'\Upsilon';'\Phi';'S''''';'h';'psi';'\nu_l';'\zeta_w';...
               '\iota_w';'\beta';...
               '\psi_1';'\psi_2';'\psi_3';'\pi^*';'\sigma_{c}';'\rho';'\gamma';'Lmean';...
               '\rho_{g}';'\rho_{b}';'\rho_{\mu}';'\rho_{z}';'\rho_{\lambda_f}';'\rho_{\lambda_w}';'\rho_{rm}';...
               '\sigma_{g}';'\sigma_{b}';'\sigma_{\mu}';'\sigma_{z}';'\sigma_{\lambda_f}';'\sigma_{\lambda_w}';'\sigma_{rm}';'\eta_{gz}';'\eta_{\lambda_f}';'\eta_{\lambda_w}'};
%               'z^*';'r^*';'r_{k}^*';'w^*';'c^*';'k^*';'\bar k^*';'i^*';'y^*';};

%% values for parameters

% fixing the parameters

para        = zeros(100,1);
para_mask   = zeros(100,1);   %npara x 1, set corresponding element to 1 to fix the parameters
para_fix    = zeros(100,1);   %npara x 1, contains values for fixed parameters

para(1)     = .24;    %para_mask(1) = 1;   para_fix(1) = para(1);              %% alp;         1
para(2)     = .7813;  %para_mask(2) = 1;   para_fix(2) = para(2);              %% zeta_p;      2
para(3)     = .3291;  %para_mask(3) = 1;   para_fix(3) = para(3);              %% iota_p;      3  
para(4)     = 1;      para_mask(4) = 1;   para_fix(4) = para(4);              %% ups; .1      5
para(5)     = 1.4672; %para_mask(5) = 1;   para_fix(5) = para(5);              %% Bigphi;      6
para(6)     = 6.3325; %para_mask(6) = 1;   para_fix(6) = para(6);              %% s2;          7
para(7)     = 0.7205; %para_mask(7) = 1;   para_fix(7) = para(7);              %% h;           8
para(8)     = 0.2648; %para_mask(8) = 1;   para_fix(8) = para(8);              %% ppsi;        9
para(9)     = 2.8401; %para_mask(9) = 1;   para_fix(9) = para(9);              %% nu_l         10
para(10)    = 0.7937; %para_mask(10) = 1;  para_fix(10) = para(10);            %% zeta_w;      11
para(11)    = 0.4425; %para_mask(11) = 1;  para_fix(11) = para(11);            %% iota_w;      12
para(12)    = 0.7420; %para_mask(12) = 1;  para_fix(12) = para(12);            %% bet;         14
para(13)    = 1.7985; %para_mask(13) = 1;  para_fix(13) = para(13);            %% psi1;        15
para(14)    = 0.0893; %para_mask(14) = 1;  para_fix(14) = para(14);            %% psi2;        16
para(15)    = 0.2239; %para_mask(15) = 1;  para_fix(15) = para(15);            %% psi3;        17
para(16)    = 0.7000; %para_mask(16) = 1;  para_fix(16) = para(16);            %% pistar;      18
para(17)    = 1.2312; %para_mask(17) = 1;  para_fix(17) = para(17);            %% sigmac;      19
para(18)    = 0.8258; %para_mask(18) = 1;  para_fix(18) = para(18);            %% rho;      19

npara       = 18;             %number of parameters

%% exogenous processes - level

para(npara+1) = 0.3982; %para_mask(npara+1) = 1;    para_fix(npara+1) = para(npara+1);      %% gam;     
para(npara+2) = 875;    %para_mask(npara+2) = 1;    para_fix(npara+2) = para(npara+2);      %% Lmean;

npara = npara+2;
    
% exogenous processes - autocorrelation
        
para(npara+1)   = 0.9930; %para_mask(npara+1) = 1;       para_fix(npara+1) = para(npara+1);      %% rho_g
para(npara+2)   = 0.2703; %para_mask(npara+2) = 1;       para_fix(npara+2) = para(npara+2);      %% rho_b;
para(npara+3)   = 0.5724; %para_mask(npara+3) = 1;       para_fix(npara+3) = para(npara+3);      %% rho_mu
para(npara+4)   = 0.9676; %para_mask(npara+4) = 1;       para_fix(npara+4) = para(npara+4);      %% rho_z;
para(npara+5)   = 0.8692; %para_mask(npara+5) = 1;       para_fix(npara+5) = para(npara+5);      %% rho_laf;
para(npara+6)   = 0.9546; %para_mask(npara+6) = 1;       para_fix(npara+6) = para(npara+6);      %% rho_law;
para(npara+7)   = 0.3000; %para_mask(npara+7) = 1;       para_fix(npara+7) = para(npara+7);      %% rho_rm;

npara = npara+7;
               
%% exogenous processes - standard deviation    
para(npara+1)   = 0.6090; %para_mask(npara+1) = 1;       para_fix(npara+1) = para(npara+1);      %% sig_g;
para(npara+2)   = 0.1818; %para_mask(npara+2) = 1;       para_fix(npara+2) = para(npara+2);      %% sig_b;
para(npara+3)  = 0.4601;  %para_mask(npara+3) = 1;       para_fix(npara+3) = para(npara+3);      %% sig_mu;
para(npara+4)  = 0.4618;  %para_mask(npara+4) = 1;       para_fix(npara+4) = para(npara+4);      %% sig_z;
para(npara+5)  = 0.1455;  %para_mask(npara+5) = 1;       para_fix(npara+5) = para(npara+5);      %% sig_laf;
para(npara+6)  = 0.2089;  %para_mask(npara+6) = 1;       para_fix(npara+6) = para(npara+6);      %% sig_law;
para(npara+7)  = 0.2397;  %para_mask(npara+7) = 1;       para_fix(npara+7) = para(npara+7);      %% sig_rm;


para(npara+8)  = 0.0500;  %para_mask(npara+8) = 1;      para_fix(npara+8) = para(npara+8);      %% eta_gz;
para(npara+9)  = 0.7652;  %para_mask(npara+9) = 1;      para_fix(npara+9) = para(npara+9);      %% eta_laf;
para(npara+10) = 0.8936;  %para_mask(npara+10) = 1;     para_fix(npara+10) = para(npara+10);    %% eta_law;

npara = npara+10;

para = para(1:npara);
para_mask = para_mask(1:npara);
para_fix = para_fix(1:npara);

%% initialize parameters at fixed value or 0   

para = para.*(1-para_mask)+para_fix.*para_mask;

%% identify policy and non policy parameters - I don't think we use these

polipar = 16;
polivalue = 2;

%% bounds for MH

bounds = zeros(100,2);

bounds(1,:) = [1E-5 .999];      %% alp;         1
bounds(2,:) = [1E-5 .999];      %% zeta_p;      2
bounds(3,:) = [1E-5 .999];      %% iota_p;      3
bounds(4,:) = [0    10];        %% ups;         5
bounds(5,:) = [1    10];        %% Bigphi;      6
bounds(6,:) = [-15   15];       %% s2;          7
bounds(7,:) = [1E-5 .999];      %% h;           8
bounds(8,:) = [1E-5 .999];      %% ppsi;        9
bounds(9,:) = [1E-5 10];        %% nu_l         10
bounds(10,:) = [1E-5 .999];     %% zeta_w;      11
bounds(11,:) = [1E-5 .999];     %% iota_w;      12
bounds(12,:) = [1E-5    10];    %% bet;         14
bounds(13,:) = [1E-5    10];    %% psi1;        15
bounds(14,:) = [-.5     .5];    %% psi2;        16
bounds(15,:) = [-.5     .5];    %% psi3;        17
bounds(16,:) = [1E-5  10];      %% pistar;      18
bounds(17,:) = [1E-5    10];    %% sigmac;      19
bounds(18,:) = [1E-5    .999];  %% rho;      19

npara = 18;

%% exogenous processes - level

bounds(npara+1,:) = [-5   5];        %% gam;     22
bounds(npara+2,:) = [-1000   1000];  %% Lstar;   23

npara = npara+2;    

%% exogenous processes - autocorrelation

bounds(npara+1,:) = [1E-5   .999];    %% rho_g;
bounds(npara+2,:) = [1E-5   .999];    %% rho_b;
bounds(npara+3,:) = [1E-5   .999];    %% rho_mu;
bounds(npara+4,:) = [1E-5   .999];    %% rho_z;
bounds(npara+5,:) = [1E-5   .999];    %% rho_laf;
bounds(npara+6,:) = [1E-5   .999];    %% rho_law;
bounds(npara+7,:) = [1E-5   .999];    %% rho_rm;

npara = npara+7;    

%% exogenous processes - standard deviation

bounds(npara+1,:) = [1E-8     5];       %% sig_g (sig_zP if mspec == 8);
bounds(npara+2,:) = [1E-8     5];       %% sig_b;
bounds(npara+3,:) = [1E-8     5];       %% sig_mu;
bounds(npara+4,:) = [1E-8     5];       %% sig_z;
bounds(npara+5,:) = [1E-8     5];       %% sig_laf;
bounds(npara+6,:) = [1E-8     5];       %% sig_law;
bounds(npara+7,:) = [1E-8     5];       %% sig_rm;
               
bounds(npara+8,:) = [1E-5  .999];       %% eta_gz;
bounds(npara+9,:) = [1E-5  .999];       %% eta_laf;
bounds(npara+10,:) = [1E-5  .999];      %% eta_law;

npara = npara+10;

bounds = bounds(1:npara,:);    

