%% Transformations:
%% format: type, a, b, c
%% Type 1:
%% x is [a,b] -> [-1,1] -> [-inf,inf] by (1/c)*c*z/sqrt(1-c*z^2)
%% Type 2:
%% x is [0,inf] -> [-inf,inf] by b + (1/c)*ln(para[i]-a);

function trspec = transp805(mspec)

	trspec = zeros(100,4);
	
	
	trspec(1,:) = [1	1E-5	.999	1]; 	%% alp;
	trspec(2,:) = [1        1E-5    0.999   1];   	%% zeta_p;
	trspec(3,:) = [1	1E-5	.999	1];	%% iota_p;
	trspec(4,:) = [2	1E-5	0	1];	%% ups;
	trspec(5,:) = [2	1.00	10.00	1];	%% Bigphi;
	trspec(6,:) = [0        -15.0   15.0    1];	%% s2;
	trspec(7,:) = [1	1E-5	.999	1]; 	%% h;
	trspec(8,:) = [1	1E-5	.999	1];	%% ppsi;
	trspec(9,:) = [2        1E-5     10     1];	%% nu_l;
	trspec(10,:) = [1       1E-5    0.999   1];   	%% zeta_w;
	trspec(11,:) = [1	1E-5	.999	1];	%% iota_w;
	trspec(12,:) = [2	1E-5	10	1];	%% bet;
	trspec(13,:) = [2	1E-5	10.00	1];	%% psi1;
	trspec(14,:) = [0	-0.5	0.5	1];	%% psi2;
        trspec(15,:) = [0	-0.5	0.5	1];	%% psi3;
	trspec(16,:) = [2	1E-5	10	1];	%% pistar;
        trspec(17,:) = [2	1E-5	10	1];	%% sigmac;
        trspec(18,:) = [1	1E-5	.999	1];	%% rho;
        trspec(19,:) = [1	1E-5	.999	1];	%% pistflag;
                
	npara = 19;
	
	%% exogenous processes - level
	trspec(npara+1,:) = [0	-5.0	5.0	1];	%% gam;
  	trspec(npara+2,:) = [0   -1000    1000      1]; %% Lmean;
	
	npara = npara+2;	
	
	%% exogenous processes - autocorrelation
	trspec(npara+1,:) = [1	1E-5	.999	1];	%% rho_g;
	trspec(npara+2,:) = [1	1E-5	.999	1];	%% rho_b;
	trspec(npara+3,:) = [1	1E-5	.999	1];	%% rho_mu;
	trspec(npara+4,:) = [1	1E-5	.999	1];	%% rho_z;
	trspec(npara+5,:) = [1	1E-5	.999	1];	%% rho_laf;
	trspec(npara+6,:) = [1	1E-5	.999	1];	%% rho_law;
	trspec(npara+7,:) = [1	1E-5	.999	1];	%% rho_rm;
	trspec(npara+8,:) = [1	1E-5	.999	1];	%% rho_psit;
        
	npara = npara+8;	
    
	%% exogenous processes - standard deviation
	trspec(npara+1,:) = [2	1E-8	5	1];	%% sig_g;
	trspec(npara+2,:) = [2	1E-8	5	1];	%% sig_b;
	trspec(npara+3,:) = [2	1E-8	5	1];	%% sig_mu;
	trspec(npara+4,:) = [2	1E-8	5	1];	%% sig_z;
	trspec(npara+5,:) = [2	1E-8	5	1];	%% sig_laf;
	trspec(npara+6,:) = [2	1E-8	5	1];	%% sig_law;
	trspec(npara+7,:) = [2	1E-8	5	1];	%% sig_rm;
	trspec(npara+8,:) = [2	1E-8	5	1];	%% sig_pist;        

  	trspec(npara+9,:) = [1   1E-5  0.999  1];	%% eta_gz;
   	trspec(npara+10,:) = [1   1E-5  0.999  1];	%% eta_laf;
   	trspec(npara+11,:) = [1   1E-5  0.999  1];	%% eta_law;       
	
	npara = npara+11;
	trspec = trspec(1:npara,:);



