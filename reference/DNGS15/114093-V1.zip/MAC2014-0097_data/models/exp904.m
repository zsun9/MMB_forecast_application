%% This defines the location of the expectation terms in the G0 matrix

ind_1 = [E_c, E_qk, E_i, E_pi, E_L, E_rk, E_w, E_Rktil, E_c_f, E_qk_f, E_i_f, E_L_f, E_rk_f];
ind_2 = [c_t, qk_t, i_t, pi_t, L_t, rk_t, w_t, Rktil_t, c_f_t, qk_f_t, i_f_t, L_f_t, rk_f_t];

ind_eq = [eq_Ec, eq_Eqk, eq_Ei, eq_Epi, eq_EL, eq_Erk, eq_Ew, eq_ERktil,...
    eq_Ec_f, eq_Eqk_f, eq_Ei_f, eq_EL_f, eq_Erk_f];
