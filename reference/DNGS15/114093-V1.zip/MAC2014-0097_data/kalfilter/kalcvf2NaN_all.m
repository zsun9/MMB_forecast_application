function [L,zend,Pend,varargout] = kalcvf2NaN_all(data, lead, a, F, b, H, R, Q, M, G, type, z, P)

% This version of the Kalman Filter is designed to handle time variation in
% some or all of T,R,Q,H,Z, with a number of options for how to input these
% matrices (see "type" comment, below).

% For this reason, additional inputs are needed. First the measurement
% volatilities must be included, in the "M" matrix, which should be Nshocks x T.
% Moreover, I am separating out the components of what would normally be
% called "var" or "VVall" to make it easier to adjust the shock covariance matrix.
% Therefore R and Q will be included instead of the standard "V" matrix
% that accounts for the effects of both.

% More generally, this program is adapted from kalcvf2NaN, which is designed
% to deal with missing data, which MUST correspond to NaN in the 'data' matrix
% if an element of the vector y(t) is missing (NaN) for the observation t, the corresponding row is ditched from the
% measurement equation.
%
% DG 1/19/2012
%
%KALCVF The Kalman filter
%
%   State space model is defined as follows:
%     z(t+1) = a+F*z(t)+R*eta(t)     (state or transition equation)
%       y(t) = b+H*z(t)+eps(t)     (observation or measurement equation)
%
%   [logl, <pred, vpred, <filt, vfilt>>]=kalcvf(data, lead, a, F, b, H, var, <z0, vz0>)
%   computes the one-step prediction and the filtered estimate, as well as their covariance matrices.
%   The function uses forward recursions, and you can also use it to obtain k-step estimates.
%
%   The inputs to the KALCVF function are as follows:
%     data is a Ny?T matrix containing data (y(1), ... , y(T)).
%     lead is the number of steps to forecast after the end of the data.
%        a is an Nz?1 vector for a time-invariant input vector in the transition equation.
%        F is an Nz?Nz matrix for a time-invariant transition matrix in the transition equation.
%        b is an Ny?1 vector for a time-invariant input vector in the measurement equation.
%        H is an Ny?Nz matrix for a time-invariant measurement matrix in the measurement equation.
%        R is an Nz x Nshocks matrix that translates the exogenous shocks
%           into states in the transition equation
%        Q is the Nshocks x Nshocks covariance matrix of the structural
%           shocks
%        M is the Ny x Nt matrix where each column is the diagonal of the
%           time t covariance matrix of the measurement error
%        G is the Nz x Ny covariance matrix of R*eta_t and epsilon_t

%       type is the (7 x 1) structure describing the type of the various matrices
%       a,F,R,Q,H,M,b. Individual entries are stored e.g., type.T, type.R,...
%       using the following translation scheme (due to different naming
%       conventions across files)

%       a: type.C
%       F: type.T
%       R: type.R
%       Q: type.Q
%       H: type.Z
%       M: type.H
%       b: type.b

%       type = 1: non-time-varying matrix (n x k)
%       type = 2: time-varying diagonal matrix (n x T), where each period's
%                   matrix is (n x n)
%       type = 3: time-varying non-diagonal matrix (n x k x T)

%        z is an optional Nz?1 initial state vector.
%        P is an optional Nz?Nz covariance matrix of an initial state vector.
%
%   The KALCVF function returns the following output:
%     logl is a value of the average log likelihood function of the SSM
%             under assumption that observation noise eps(t) is normally distributed
%     pred is an optional Nz?(T+lead) matrix containing one-step predicted state vectors.
%    vpred is an optional Nz?Nz?(T+lead) matrix containing mean square errors of predicted state vectors.
%     filt is an optional Nz?T matrix containing filtered state vectors.
%    vfilt is an optional Nz?Nz?T matrix containing mean square errors of filtered state vectors.
%
%   The initial state vector and its covariance matrix of the time invariant Kalman filters
%   are computed under the stationarity condition:
%          z0 = (I-F)\a
%         vz0 = (I-kron(F,F))\V(:)
%   where F and V are the time invariant transition matrix and the covariance matrix of transition equation noise,
%   and vec(V) is an Nz^2?1 column vector that is constructed by the stacking Nz columns of matrix V.
%   Note that all eigenvalues of the matrix F are inside the unit circle when the SSM is stationary.
%   When the preceding formula cannot be applied, the initial state vector estimate is set to a
%   and its covariance matrix is given by 1E6I. Optionally, you can specify initial values.
%
%   This is a M-file for MATLAB.
%   Copyright 2002-2003 Federal Reserve Bank of Atlanta
%   $Revision: 1.2 $  $Date: 2003/03/19 19:16:17 $
%   Iskander Karibzhanov 5-28-02.
%   Master of Science in Computational Finance
%   Georgia Institute of Technology
%==========================================================================
% Revision history:
%
%  03/19/2003  -  algorithm and interface were adapted from SAS/IML KALCVF subroutine for use in MATLAB M file
%
%==========================================================================

T = size(data,2);
Nz = size(a,1);
Ny = size(b,1);

nout = nargout;

if nout>3
    pred = zeros(Nz,T);
    vpred = zeros(Nz,Nz,T);
    if nout > 5
        filt = zeros(Nz,T);
        vfilt = zeros(Nz,Nz,T);
        if nout > 7
            yprederror = NaN*zeros(Ny,T);
            ystdprederror = NaN*zeros(Ny,T);
        end
    end
end

% Check if any data are NaN. If not, don't check again.
if any(isnan(data(:)))
    check_nan = 1;
else
    check_nan = 0;
    notis_nan = true(Ny, 1);
    
    G_t = G;
    Ny_t = Ny;
end

% Assign matrices if constant
if type.C == 1
    a_t = a;
elseif type.T ~= 3
    error('This type of input has not been coded yet');
end

if type.T == 1
    F_t = F;
elseif type.T ~= 3
    error('This type of input has not been coded yet');
end

if type.R == 1
    R_t = R;
elseif type.R ~= 3
    error('This type of input has not been coded yet');
end

if type.Q == 1
    Q_t = Q;
elseif type.Q ~= 2
    error('This type of input has not been coded yet');
end

if type.Z == 1
    H_t = H;
elseif type.Z ~= 3
    error('This type of input has not been coded yet');
end

if type.H == 1
    M_t = M;
elseif type.H ~= 2
    error('This type of input has not been coded yet');
end

if type.b == 1
    b_t = b;
elseif type.b ~= 3
    error('This type of input has not been coded yet');
end

if type.R == 1 && type.Q == 1
    RQR_t = R_t * Q_t * R_t';
end
    
L = 0;

for t=1:T
    
    % if an element of the vector y(t) is missing (NaN) for the observation t, the corresponding row is ditched from the
    % measurement equation.
    
    if check_nan
        notis_nan = ~isnan(data(:,t));
        
        data_t = data(notis_nan,t);
        G_t = G(:,notis_nan);
        Ny_t = length(data_t);
    else
        data_t = data(:, t);
    end
    
    if type.C == 3
        a_t = a(:,:,t);
    end
    
    if type.T == 3
        F_t = F(:,:,t);
    end
    
    if type.R == 3
        R_t = R(:,:,t);
    end
    
    if type.Q == 2
        Q_t = diag(Q(:,t));
    end
    
    if type.Z == 3
        H_t = H(:,:,t);
    end
    
    if type.H == 2
        M_t = diag(M(:,t));
    end
    
    if type.b == 3
        b_t = b(:,t);
    end
    
    if type.R ~= 1 || type.Q ~= 1
        RQR_t = R_t * Q_t * R_t';
    end
    
    if check_nan
        H_t_ = H_t(notis_nan,:);
        %     M_t = diag(M(notis_nan,t));
        M_t_ = M_t(notis_nan,notis_nan);
        b_t_ = b_t(notis_nan);
    end
    
    %% forecasting
    
    z = a_t + F_t* z;
    
    %     P = F*P*F'+V;
    
    % The w matrix will be used to scale the variances of the shocks, as
    % the shocks are equal to w*eta, where the elements of eta
    % are independent and normally distributed.
    
    P = F_t*P*F_t' + RQR_t;
    
    dy = data_t - H_t_*z - b_t_;
    
    HG = H_t_*G_t;
    D = H_t_*P*H_t_' + HG + HG' + M_t_;
    
    D = .5*(D+D');
    
    if nout > 3
        pred(:,t) = z;
        vpred(:,:,t) = P;
        if nout> 7
                yprederror(notis_nan,t) = dy;
                ystdprederror(notis_nan,t) = dy./sqrt(diag(D));
        end
    end
    
%     if det(D) < 10^(-4)
%         keyboard;
%     end

    ddy = D\dy;
    L = L-.5*log(det(D))-.5*dy'*ddy-.5*Ny_t*log(2*pi);
    
    
    %% updating
    PHG = (P*H_t_'+G_t);
    z = z+PHG*ddy;
    P = P-PHG/D*PHG';
    
    
    if nout > 5
        %       PH = P*H_t';
        filt(:,t) = z;
        vfilt(:,:,t) = P;
    end
end
zend = z;
Pend = P;

if lead>1 && nout>1
    error('kalcvf2NaN_tv does not currently work with lead > 1')
    %     for t=T+2:T+lead
    %       z = F*z+a;
    %       P = F*P*F'+V;
    %       pred(:,t) = z;
    %       vpred(:,:,t) = P;
    %     end
end

if nout > 3
    varargout(1) = {pred};
    varargout(2) = {vpred};
    if nout>5
        varargout(3) = {filt};
        varargout(4) = {vfilt};
        if nout > 7
            varargout(5) = {yprederror};
            varargout(6) = {ystdprederror};
            varargout(7) = {sqrt(mean(yprederror.^2,2))'};
            varargout(8) = {sqrt(mean(ystdprederror.^2,2))'};
        end
    end
end


