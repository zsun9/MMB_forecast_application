#include "matlib.h"

/*===== Linear Matrix Equation Solver ======*
 * DLINS solves the linear matrix equation: *
 *             A*X + B = X                  *
 *==========================================*/
void dlins(int n, int nrhs, double *a, double *b, int *info) {
		double *c;
		int *ipiv, nn=n*n, n1=n+1;

		info[0] = 0;
		c = (double *)mxCalloc(nn, sizeof(double));
		cblas_daxpy(nn, mone_d, a, one, c, one);
		cblas_daxpy(n, one_d, &one_d, zero, c, n1);
		ipiv = (int *)mxCalloc(n, sizeof(int));
		dgetrf(&n, &n, c, &n, ipiv, info);
		if ( info[0] < 0 ) {
			sprintf(msg, "The %dth parameter to DGETRF had an illegal value.", -info[0]);
			mexErrMsgTxt(msg);
		}
		if ( info[0] == 0) {
			dgetrs(chn, &n, &nrhs, c, &n, ipiv, b, &n, info);
			if ( info[0] < 0 ) {
				sprintf(msg, "The %dth parameter to DGETRS had an illegal value.", -info[0]);
				mexErrMsgTxt(msg);
			}
		}
		mxFree(ipiv);
		mxFree(c);
}

/* DTRIL copies lower part of n�n matrix X into its upper part */
void dtril(int n, double *x, int ldx) {
	double *u = x+ldx;

	x++;
	for (n--; n>0; n--) {
		cblas_dcopy(n, x, one, u, ldx);
		x += ldx+1;
		u += ldx+1;
	}
}
