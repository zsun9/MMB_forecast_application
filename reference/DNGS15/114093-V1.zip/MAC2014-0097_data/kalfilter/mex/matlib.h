#ifndef __MATLIB_H__
#define __MATLIB_H__

#include <mex.h>
#include <math.h>

static double one_d=1.0, mone_d=-1.0, zero_d=0.0, half_d=0.5;
static int one=1, mone=-1, zero=0;
static char *chn = "N", *cht = "T", *chc = "C", *chu = "U", *chl = "L", *chr = "R",
            *chv = "V", *chs = "S", msg[201];

#ifdef MATLAB_MEX_FILE
#define INFCHK(FUNC) \
   if (info < 0) { \
      sprintf(msg,"The %dth parameter to " #FUNC " had an illegal value.",-info); \
      mexErrMsgTxt(msg); \
   }
#else
#define INFCHK(FUNC) \
   if (info < 0) { \
      printf("The %dth parameter to " #FUNC " had an illegal value.",-info); \
	  return; \
   }
#define mexErrMsgTxt(MSG) \
{	printf(MSG); \
	return; }
#define mexWarnMsgTxt printf
#define mexPrintf printf
#define mxCalloc calloc
#define mxFree free
#endif


/* Kalman Filter function */
double kalcvf(double *data, int T, int lead, int Ny, int Nz,
              double *a, int inca, double *F, int incF,
              double *b, int incb, double *H, int incH,
              double *var, int incvar, double *z0, double *vz0,
              double *pred, double *vpred, double *filt, double *vfilt);

/* Discrete Lyapunov Equation Solver: A*X*A' + Q = X */
void dlyap(int n, double *A, double *Q, int ldQ, double *X, int *info);

/* Linear Matrix Equation Solver: A*X + B = X */
void dlins(int n, int nrhs, double *A, double *B, int *info);

/* DTRIL copies lower part of n�n matrix X into its upper part */
void dtril(int n, double *x, int ldx);

#ifdef MKL
#include <mkl_cblas.h>
#include <mkl_lapack.h>

#else
/*
When calling a LAPACK or BLAS function from MATLAB library, some platforms require
an underscore character following the function name in the call statement.
On the PC, IBM_RS, and HP platforms, use the function name alone, with no trailing underscore.
On the SGI, LINUX, Solaris, Alpha, and Macintosh platforms, add the underscore after the function name.
*/

#if defined(__sgi__) || defined(linux) || defined(__linux__) || defined(sun) || defined(__solaris__) || defined(__alpha) || defined(macintosh)
#define ddot ddot_
#define dcopy dcopy_
#define daxpy daxpy_
#define dscal dscal_
#define dsymm dsymm_
#define dgemm dgemm_
#define dtrmm dtrmm_
#define dsyrk dsyrk_
#define dgemv dgemv_
#define dtrsv dtrsv_
#define dtrsm dtrsm_
#define dgetrf dgetrf_
#define dgetrs dgetrs_
#define dgehrd dgehrd_
#define dorghr dorghr_
#define dhseqr dhseqr_
#define dtrsyl dtrsyl_
#define dpotrf dpotrf_
#define dpotri dpotri_
#define dpotrs dpotrs_
#endif

/* BLAS Level 1 */
#define cblas_daxpy(N, ALPHA, X, INCX, Y, INCY) \
   daxpy(&N, &ALPHA, X, &INCX, Y, &INCY)
#define cblas_dcopy(N, X, INCX, Y, INCY) \
   dcopy(&N, X, &INCX, Y, &INCY)
#define cblas_ddot(N, X, INCX, Y, INCY) \
   ddot(&N, X, &INCX, Y, &INCY)
#define cblas_dscal(N, ALPHA, X, INCX) \
   dscal(&N, &ALPHA, X, &INCX);
/* BLAS Level 2 */
#define cblas_dgemv(ORDER, TRANSA, M, N, ALPHA, A, LDA, X, INCX, BETA, Y, INCY) \
   dgemv(TRANSA, &M, &N, &ALPHA, A, &LDA, X, &INCX, &BETA, Y, &INCY)
#define cblas_dtrsv(ORDER, UPLO, TRANSA, DIAG, N, A, LDA, X, INCX) \
   dtrsv(UPLO, TRANSA, DIAG, &N, A, &LDA, X, &INCX)
/* BLAS Level 3 */
#define cblas_dgemm(ORDER, TRANSA, TRANSB, M, N, K, ALPHA, A, LDA, B, LDB, BETA, C, LDC) \
   dgemm(TRANSA, TRANSB, &M, &N, &K, &ALPHA, A, &LDA, B, &LDB, &BETA, C, &LDC)
#define cblas_dsymm(ORDER, SIDE, UPLO, M, N, ALPHA, A, LDA, B, LDB, BETA, C, LDC) \
   dsymm(SIDE, UPLO, &M, &N, &ALPHA, A, &LDA, B, &LDB, &BETA, C, &LDC)
#define cblas_dsyrk(ORDER, UPLO, TRANS, N, K, ALPHA, A, LDA, BETA, C, LDC) \
   dsyrk(UPLO, TRANS, &N, &K, &ALPHA, A, &LDA, &BETA, C, &LDC)
#define cblas_dtrmm(ORDER, SIDE, UPLO, TRANSA, DIAG, M, N, ALPHA, A, LDA, B, LDB) \
   dtrmm(SIDE, UPLO, TRANSA, DIAG, &M, &N, &ALPHA, A, &LDA, B, &LDB)
#define cblas_dtrsm(ORDER, SIDE, UPLO, TRANSA, DIAG, M, N, ALPHA, A, LDA, B, LDB) \
   dtrsm(SIDE, UPLO, TRANSA, DIAG, &M, &N, &ALPHA, A, &LDA, B, &LDB)

#define CblasRowMajor
#define CblasColMajor
#define CblasNoTrans chn
#define CblasTrans cht
#define CblasConjTrans chc
#define CblasUpper chu
#define CblasLower chl
#define CblasNonUnit chn
#define CblasUnit chu
#define CblasLeft chl
#define CblasRight chr

/* BLAS Level 1 */
extern void daxpy(int *n, double *alpha, double *x, int *incx, double *y, int *incy);
extern void dcopy(int *n, double *x, int *incx, double *y, int *incy);
extern double ddot(int *n, double *x, int *incx, double *y, int *incy);
extern void dscal(int *n, double *alpha, double *x, int *incx);
/* BLAS Level 2 */
extern void dgemv(char *transa, int *m, int *n, double *alpha, double *a, int *lda, double *x, int *incx, double *beta, double *y, int *incy);
extern void dtrsv(char *uplo, char *transa, char *diag, int *n, double *a, int *lda, double *x, int *incx);
/* BLAS Level 3 */
extern void dgemm(char *transa, char *transb, int *m, int *n, int *k, double *alpha, double *a, int *lda, double *b, int *ldb, double *beta, double *c, int *ldc);
extern void dsymm(char *side, char *uplo, int *m, int *n, double *alpha, double *a, int *lda, double *b, int *ldb, double *beta, double *c, int *ldc);
extern void dsyrk(char *uplo, char *trans, int *n, int *k, double *alpha, double *a, int *lda, double *beta, double *c, int *ldc);
extern void dtrmm(char *side, char *uplo, char *transa, char *diag, int *m, int *n, double *alpha, double *a, int *lda, double *b, int *ldb);
extern void dtrsm(char *side, char *uplo, char *transa, char *diag, int *m, int *n, double *alpha, double *a, int *lda, double *b, int *ldb);

/* LAPACK */
extern void dgetrf(int *m, int *n, double *a, int *lda, int *ipiv, int *info);
extern void dgetrs(char *trans, int *n, int *nrhs, double *a, int *lda, int *ipiv, double *b, int *ldb, int *info);
extern void dgehrd(int *n, int *ilo, int *ihi, double *a, int *lda, double *tau, double *work, int *lwork, int *info);
extern void dorghr(int *n, int *ilo, int *ihi, double *a, int *lda, double *tau, double *work, int *lwork, int *info);
extern void dhseqr(char *job, char *compz, int *n, int *ilo, int *ihi, double *h, int *ldh, double *wr, double *wi, double *z, int *ldz, double *work, int *lwork, int *info);
extern void dtrsyl(char *trana, char *tranb, int *isgn, int *m, int *n, double *a, int *lda, double *b, int *ldb, double *c, int *ldc, double *dscale, int *info);
extern void dpotrf(char *uplo, int *n, double *a, int *lda, int *info);
extern void dpotri(char *uplo, int *n, double *a, int *lda, int *info);
extern void dpotrs(char *uplo, int *n, int *nrhs, double *a, int *lda, double *b, int *ldb, int *info);

#endif

#endif
