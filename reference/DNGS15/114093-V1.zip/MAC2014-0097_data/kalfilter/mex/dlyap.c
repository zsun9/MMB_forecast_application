/* $Revision: 1.1 $ $Date: 2003/03/11 20:11:43 $ */
/*******************************************************************
 * DLYAP   Discrete Lyapunov equation solver.
 *
 *    X = DLYAP(A,Q) solves the discrete Lyapunov equation:
 *
 *     A*X*A' - X + Q = 0
 *
 * J.N. Little 2-1-86, AFP 7-28-94
 * Copyright 1986-2002 The MathWorks, Inc.
 *
 * How to prove the following conversion is true.  Re: show that if
 *        (1) Ad X Ad' + Cd = X             Discrete lyaponuv eqn
 *        (2) Ac = inv(Ad + I) (Ad - I)     From dlyap
 *        (3) Cc = (I - Ac) Cd (I - Ac')/2  From dlyap
 * Then
 *        (4) Ac X + X Ac' + Cc = 0         Continuous lyapunov
 *
 * Step 1) Substitute (2) into (3)
 *         Use identity 2*inv(M+I) = I - inv(M+I)*(M-I)
 *                                 = I - (M-I)*inv(M+I) to show
 *         (5) Cc = 4*inv(Ad + I)*Cd*inv(Ad' + I)
 * Step 2) Substitute (2) and (5) into (4)
 * Step 3) Replace (Ad - I) with (Ad + I -2I)
 *         Replace (Ad' - I) with (Ad' + I -2I)
 * Step 4) Multiply through and simplify to get
 *         X -inv(Ad+I)*X -X*inv(Ad'+I) +inv(Ad+I)*Cd*inv(Ad'+I) = 0
 * Step 5) Left multiply by (Ad + I) and right multiply by (Ad' + I)
 * Step 6) Simplify to (1)
 *
 *******************************************************************/

#include "matlib.h"

void dlyap(int n, double *ad, double *cd, int ldcd, double *x, int *info) {

   double *a, *b, *c, scale=1.0, *work, work1;
   int nn = n*n, *p, isgn=1, ilo=1, ihi=n, lwork;
   register int i, j;
   bool symm = true;

   info[0] = 0;
   for (j=0; symm && j<n; j++)
      for (i=j+1; symm && i<n; i++)
         if (cd[i+j*ldcd]!=cd[j+i*ldcd])
            symm = false;

   /* a = ad-eye(n); c = ad+eye(n); */
   a = (double *)mxCalloc(nn,sizeof(double));
   c = (double *)mxCalloc(nn,sizeof(double));

   cblas_dcopy(nn, ad, one, a, one);
   cblas_dcopy(nn, ad, one, c, one);
   for (i=0; i<n; i++) {
      a[i*(n+1)] -= 1;
      c[i*(n+1)] += 1;
   }

   /* a = c\a */
   p = (int *)mxCalloc(n,sizeof(int));
   dgetrf(&n, &n, c, &n, p, info);
   if (info[0] < 0) {
      sprintf(msg,"The %dth parameter to DGETRF had an illegal value.",-info[0]);
      mexErrMsgTxt(msg);
   }
   if (info[0] > 0) {
#ifndef _DLYAP_NOMSG_
      sprintf(msg, "u(%d,%d) is 0. The factorization has been completed, but U"
         "is exactly singular. Division by 0 will occur if you use the factor "
         "U for solving a system of linear equations.", info[0], info[0]);
      mexWarnMsgTxt(msg);
#endif
      mxFree(a);
      mxFree(c);
      mxFree(p);
      return;
   }
   dgetrs(chn, &n, &n, c, &n, p, a, &n, info);
   if (info[0] < 0) {
      sprintf(msg,"The %dth parameter to DGETRS had an illegal value.",-info[0]);
      mexErrMsgTxt(msg);
   }
   mxFree(p);

   /* b = a-eye(n) */
   b = (double *)mxCalloc(nn,sizeof(double));
   cblas_dcopy(nn, a, one, b, one);
   for (i=0; i<n; i++)
      b[i*(n+1)] -= 1;
   /* c = b*cd/2 */
   if (symm)
      cblas_dsymm(CblasColMajor, CblasRight, CblasUpper, n, n, half_d, cd, ldcd, b, n, zero_d, c, n);
   else
      cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, n, n, n, half_d, b, n, cd, ldcd, zero_d, c, n);
   /* x = c*b' */
   cblas_dgemm(CblasColMajor, CblasNoTrans, CblasTrans, n, n, n, mone_d, c, n, b, n, zero_d, x, n);

   /* Compute Schur form of matrix a:
      Step 1 - Reduce general matrix a to upper Hessenberg form. */
   lwork = -1;
   info[0] = 0;
   dgehrd(&n, &ilo, &ihi, a, &n, c, &work1, &lwork, info);
   if (info[0] < 0) {
      sprintf(msg,"The %dth parameter to DGEHRD had an illegal value.",-info[0]);
      mexErrMsgTxt(msg);
   }
   lwork = (int)work1;
   work = (double *)mxCalloc(lwork,sizeof(double));
   dgehrd(&n, &ilo, &ihi, a, &n, c, work, &lwork, info);
   if (info[0] < 0) {
      sprintf(msg,"The %dth parameter to DGEHRD had an illegal value.",-info[0]);
      mexErrMsgTxt(msg);
   }

   /* Step 2 - Generate the real orthogonal matrix b determined by dgehrd. */
   info[0] = 0;
   cblas_dcopy(nn, a, one, b, one);
   dorghr(&n, &ilo, &ihi, b, &n, c, work, &lwork, info);
   if (info[0] < 0) {
      sprintf(msg,"The %dth parameter to DORGHR had an illegal value.",-info[0]);
      mexErrMsgTxt(msg);
   }

   /* Step 3 - Compute all eigenvalues and the Schur factorization of
      matrix a reduced to Hessenberg form. */
   info[0] = 0;
   dhseqr(chs, chv, &n, &ilo, &ihi, a, &n, c, &c[n], b, &n, work, &lwork, info);
   mxFree(work);
   if (info[0] > 0) {
#ifndef _DLYAP_NOMSG_
      sprintf(msg,"The algorithm has failed to find all the eigenvalues after "
         "a total %d iterations. Elements 1,2, ..., %d and %d, %d,"
         " ..., %d of wr and wi contain the real and imaginary parts of the "
         "eigenvalues which have been found.", 30*(ihi-ilo+1), ilo-1, info[0]+1,
         info[0]+2, n);
      mexWarnMsgTxt(msg);
#endif
      mxFree(a);
      mxFree(b);
      mxFree(c);
      return;
   }
   if (info[0] < 0) {
      sprintf(msg,"The %dth parameter to DHSEQR had an illegal value.",-info[0]);
      mexErrMsgTxt(msg);
   }

   /* Transform x = b'*x*b */
   /* c = x'*b */
   if (symm)
      cblas_dsymm(CblasColMajor, CblasLeft, CblasUpper, n, n, one_d, x, n, b, n, zero_d, c, n);
   else
      cblas_dgemm(CblasColMajor, CblasTrans, CblasNoTrans, n, n, n, one_d, x, n, b, n, zero_d, c, n);
   /* x = c'*b */
   cblas_dgemm(CblasColMajor, CblasTrans, CblasNoTrans, n, n, n, one_d, c, n, b, n, zero_d, x, n);


   /* Solve Sylvester's equation a*x+x*a'=c for real quasi-triangular matrix a. */
   dtrsyl(chn, cht, &isgn, &n, &n, a, &n, a, &n, x, &n, &scale, info);
   if (info[0] < 0) {
      sprintf(msg,"The %dth parameter to DTRSYL had an illegal value.",-info[0]);
      mexErrMsgTxt(msg);
   }
   mxFree(a);
#ifndef _DLYAP_NOMSG_
   if (info[0] == 1) {
      sprintf(msg,"Solution does not exist or is not unique. A and C have common "
      "or close eigenvalues perturbed values were used to solve the equation.");
      mexWarnMsgTxt(msg);
   }
#endif
   /* Find untransformed solution x = b*x*b' */
   /* c = b*x */
   if (symm)
      cblas_dsymm(CblasColMajor, CblasRight, CblasUpper, n, n, one_d, x, n, b, n, zero_d, c, n);
   else
      cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, n, n, n, one_d, b, n, x, n, zero_d, c, n);
   /* x = c*b' */
   cblas_dgemm(CblasColMajor, CblasNoTrans, CblasTrans, n, n, n, one_d, c, n, b, n, zero_d, x, n);

   mxFree(b);
   mxFree(c);
}
