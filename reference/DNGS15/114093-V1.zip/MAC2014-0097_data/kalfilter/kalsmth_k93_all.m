function [alpha_hat,varargout] = kalsmth_k93_all(A0,P0,y,pred,vpred,C,T,R,Q,H,Z,b,type,Ny0)

% KALSMTH_K93_ALL.M

% This version of the Kalman Smoothing program is designed to handle time variation in
% some or all of T,R,Q,H,Z, with a number of options for how to input these
% matrices (see "type" comment, below).

% This is a Kalman Smoothing program based on S.J. Koopman's "Disturbance
% Smoother for State Space Models" (Biometrika, 1993), as specified in
% Durbin and Koopman's "A Simple and Efficient Simulation Smoother for
% State Space Time Series Analysis" (Biometrika, 2002). The algorithm has been
% simplified for the case in which there is no measurement error, and the
% model matrices do not vary with time.

% Unlike other Kalman Smoothing programs, there is no need to invert
% singular matrices using the Moore-Penrose pseudoinverse (pinv), which
% should lead to efficiency gains and fewer inversion problems. Also, the
% states vector and the corresponding matrices do not need to be augmented 
% to include the shock innovations. Instead they are saved automatically 
% in the eta_hat matrix.

% Nz will stand for the number of states, Ny for the number of observables,
% Ne for the number of shocks, and Nt for the number of periods of data.

% The state space is assumed to take the form:
% y(t) = Z*alpha(t) + b
% alpha(t+1) = T*alpha(t) + R*eta(t+1)

% INPUTS:

% A0, the (Nz x 1) initial (time 0) states vector.
% P0, the (Nz x Nz) initial (time 0) state covariance matrix.
% y, the (Ny x Nt) matrix of observable data.
% pred, the (Nz x Nt) matrix of one-step-ahead predicted states (from the Kalman Filter).
% vpred, the (Nz x Nz x Nt) matrix of one-step-ahead predicted covariance matrices.
% T, the (Nz x Nz) transition matrix.
% R, the (Nz x Ne) matrix translating shocks to states.
% Q, the (Ne x Nt) matrix, where each column is the diagonal of the
%       covariance matrix of the structural shocks
% H, the (Ny x Nt) matrix, where each column is the diagonal of the
%       covariance matrix of the measurement errors
% Z, the (Ny x Nz) measurement matrix.
% b, the (Ny x 1) constant vector in the measurement equation.

% type, the (6 x 1) structure describing the type of the various matrices
%       T,R,Q,H,Z,b. Individual entries are stored e.g. type.T, type.R,...

%       type = 1: non-time-varying matrix (n x k)
%       type = 2: time-varying diagonal matrix (n x T), where each period's
%                   matrix is (n x n)
%       type = 3: time-varying non-diagonal matrix (n x k x T)

% Ny0, an optional scalar indicating the number of periods of presample
%       (i.e. the number of periods for which smoothed states are not required).

% OUTPUTS:

% alpha_hat, the (Nz x Nt) matrix of smoothed states.
% eta_hat, the optional (Ne x Nt) matrix of smoothed shocks.

% If Ny0 is nonzero, the alpha_hat and eta_hat matrices will be shorter by
% that number of columns (taken from the beginning).

% Dan Greenwald, 1/19/2012.

% Adapted to deal with transition equations of the form:
% alpha(t+1) = C + T*alpha(t) + R*eta(t+1)

% Raiden Hasegawa, 1/31/2014

% if nargin < 12, error('At least twelve inputs required'); end
% if nargin == 13, error('Zero, two, or three optional inputs required'); end
% if nargin > 15, error('At most 15 inputs allowed'); end

Ne = size(R,2);
Nt = size(y,2);
% Ny = size(y,1);
Nz = size(T,1);

alpha_hat = zeros(Nz,Nt);

if nargout > 1
    [r,eta_hat] = distsmth_k93_all(y,pred,vpred,T,R,Q,H,Z,b,type);
else
    r = distsmth_k93_all(y,pred,vpred,T,R,Q,H,Z,b,type);
end

ah_t = A0 + P0*r(:,1);
% ah_t = pred(:,1) + vpred(:,:,1)*r(:,1);
alpha_hat(:,1) = ah_t;

for t = 2:Nt
    
    if type.T == 1
        T_t = T;
    elseif type.T == 3
        T_t = T(:,:,t);
    else
        error('This type of input has not been coded yet');
    end
    
    if type.C == 1
        C_t = C;
    elseif type.C == 3
        C_t = C(:,t);
    else
        error('This type of input has not been coded yet');
    end
    
    if type.R == 1
        R_t = R;
    elseif type.R == 3
        R_t = R(:,:,t);
    else
        error('This type of input has not been coded yet');
    end
    
    if type.Q == 1
        Q_t = Q;
    elseif type.Q == 2
        Q_t = diag(Q(:,t));
    else
        error('This type of input has not been coded yet');
    end
    
    ah_t = T_t*ah_t + C_t + R_t*Q_t*R_t'*r(:,t);
%     ah_t = pred(:,t) + vpred(:,:,t)*r(:,t);
    alpha_hat(:,t) = ah_t;

end

if exist('Ny0','var')
    if Ny0 > 0
       alpha_hat = alpha_hat(:,Ny0+1:end);
       if nargout > 1, eta_hat = eta_hat(:,Ny0+1:end); end
    end
end

if nargout > 1, varargout(1) = {eta_hat}; end