function [r,varargout] = distsmth_k93_all(y,pred,vpred,T,R,Q,H,Z,b,type)

% DISTSMTH_K93_MVTVME.M

% This version of the Disturbance Smoother is designed to handle time variation in
% some or all of T,R,Q,H,Z, with a number of options for how to input these
% matrices (see "type" comment, below).

% This is a Disturbance Smoothing program based on S.J. Koopman's "Disturbance
% Smoother for State Space Models" (Biometrika, 1993), as specified in
% Durbin and Koopman's "A Simple and Efficient Simulation Smoother for
% State Space Time Series Analysis" (Biometrika, 2002). The algorithm has been
% simplified for the case in which there is no measurement error, and the
% model matrices do not vary with time.

% This disturbance smoother is intended for use with the state smoother
% kalsmth_93.m from the same papers (Koopman 1993, Durbin and Koopman
% 2002). It produces a matrix of vectors, r, that is used for state 
% smoothing, and an optional matrix, eta_hat, containing the smoothed
% shocks. It has been adjusted to account for the possibility of missing
% values in the data, and to accommodate the zero bound model, which
% requires that no anticipated shocks occur before the zero bound window,
% which is achieved by setting the entries in the Q matrix corresponding to
% the anticipated shocks to zero in those periods.

% Nz will stand for the number of states, Ny for the number of observables,
% Ne for the number of shocks, and Nt for the number of periods of data.

% The state space is assumed to take the form:
% y(t) = Z*alpha(t) + b
% alpha(t+1) = T*alpha(t) + R*eta(t+1)

% INPUTS:

% y, the (Ny x Nt) matrix of observable data.
% pred, the (Nz x Nt) matrix of one-step-ahead predicted states (from the Kalman Filter).
% vpred, the (Nz x Nz x Nt) matrix of one-step-ahead predicted covariance matrices.
% T, the (Nz x Nz) transition matrix.
% R, the (Nz x Ne) matrix translating shocks to states.
% Q, the (Ne x Ne) covariance matrix of the structural shocks
% H, the (Ny x Nt) matrix, where each column is the diagonal of the
%       covariance matrix of the measurement errors
% Z, the (Ny x Nz) measurement matrix.
% b, the (Ny x 1) constant vector in the measurement equation.

% type, the (6 x 1) structure describing the type of the various matrices
%       T,R,Q,H,Z,b. Individual entries are stored e.g. type.T, type.R,...

%       type = 1: non-time-varying matrix (n x k)
%       type = 2: time-varying diagonal matrix (n x T), where each period's
%                   matrix is (n x n)
%       type = 3: time-varying non-diagonal matrix (n x k x T)

% OUTPUTS:

% r, the (Nz x Nt) matrix used for state smoothing.
% eta_hat, the optional (Ne x Nt) matrix of smoothed shocks.

% Dan Greenwald, 7/7/2010.

% if nargin < 10, error('At least ten inputs required'); end
% if nargin == 11, error('Zero or two optional inputs required'); end
% if nargin > 12, error('At most twelve inputs allowed'); end

Nt = size(y,2);
Nz = size(T,1);

r = zeros(Nz,Nt); % holds r_T-1,...r_0 (JC)
r_t = zeros(Nz,1);

if nargout > 1
    Ne = size(R,2);
    eta_hat = zeros(Ne,Nt);
end

for t = Nt:-1:1
    
    if type.T == 1
        T_t = T;
    elseif type.T == 3
        if t ~= Nt
            T_t = T(:,:,t+1);
        else 
            T_t = T(:,:,1);
        end
    else
        error('This type of input has not been coded yet');
    end
    
    if type.R == 1
        R_t = R;
    elseif type.R == 3
        R_t = R(:,:,t);
    else
        error('This type of input has not been coded yet');
    end
    
    if type.Q == 1
        Q_t = Q;
    elseif type.Q == 2
        Q_t = diag(Q(:,t));
    else
        error('This type of input has not been coded yet');
    end
    
    if type.Z == 1
        Z_t = Z;
    elseif type.Z == 3
        Z_t = Z(:,:,t);
    else
        error('This type of input has not been coded yet');
    end
    
    if type.H == 1
        H_t = H;
    elseif type.H == 2
        H_t = diag(H(:,t));
    else
        error('This type of input has not been coded yet');
    end
    
    if type.b == 1
        b_t = b;
    elseif type.b == 3
        b_t = b(:,t);
    else
        error('This type of input has not been coded yet');
    end
    
    y_t = y(:,t);
    
    % This section deals with the possibility of missing values in the y_t
    % vector (especially relevant for smoothing over peachdata).
    notnan = ~isnan(y_t);
    y_t = y_t(notnan);
    Z_t = Z_t(notnan,:);
    b_t = b_t(notnan);
    H_t = H_t(notnan,notnan);
    
    a = pred(:,t);
    P = vpred(:,:,t);
    
    F = Z_t*P*Z_t' + H_t;
    v = y_t - Z_t*a - b_t;
    K = T_t*P*Z_t'/F;
    L = T_t - K*Z_t;
    
    r_t = Z_t'/F*v + L'*r_t;
    r(:,t) = r_t;
    
    if nargout > 1
        eta_hat(:,t) = Q_t*R_t'*r_t;
    end
    
end

if nargout > 1, varargout(1) = {eta_hat}; end