%% ------------------------------------------------------------------------
% figures_script.m: run the code to generate figures for paper
% -------------------------------------------------------------------------

setpath;

%% ------------------------------------------------------------------------
% figures 0
% -------------------------------------------------------------------------
clear;close all;fclose all;
% generate ex-post smoothed states and shocks
spec_904_aux_full201250;
forecast_vintage_aux_2model;
clear;

% generate forecast plots
spec_904_aux;
figDir = 'figure_0';
forecast_vintage_aux;
forplot_vint_aux;
plotVintage_aux;

%% ------------------------------------------------------------------------
% figures 1,2 & 3
% -------------------------------------------------------------------------
clear;close all;fclose all;

% generate backward looking phillips forecast for right panel of figure 2
phillips_script;
clear;

% get forecast conditioned on expost marginal cost
spec_904_aux_full201250;
bol_cond_mc = 1;
forecast_vintage_aux;
clear;

% generate ex-post smoothed states and shocks
spec_904_aux_full201250;
forecast_vintage_aux_2model;
clear;

% generate forecast plots (figure 1, left panel of figure 2 and figure 3)
spec_904_aux;
figDir = 'figure_1_2_3';
forecast_vintage_aux;
forplot_vint_aux;
plotVintage_aux;
close all;

% generate forecast plots (right panel of figure 2)
phillips_mc = 1;
plotVintage_aux;

%% ------------------------------------------------------------------------
% figure 4
% -------------------------------------------------------------------------
clear;close all;fclose all;
list_scenario = {'no_shocks';'mrkup_only';'no_mrkup'};
figDir = 'figure_4';
for i = 1:length(list_scenario)
    write_two_model_scenarios_spec(list_scenario{i});
    two_model_scenarios;
end
    
%% ------------------------------------------------------------------------
% figure 6
% -------------------------------------------------------------------------
clear;close all;fclose all;
figDir = 'figure_6';
mc_evol_exp = 'pr_rigidity';
compareMcEvol;

close all;fclose all;
mc_evol_exp = 'pr_rigidity_and_policy';
compareMcEvol;

%% ------------------------------------------------------------------------
% figure 7
% -------------------------------------------------------------------------
clear;close all;fclose all;
figDir = 'figure_7';
gdpdefV904VSW = 1;
comparePiTil;

%% ------------------------------------------------------------------------
% figure 8
% -------------------------------------------------------------------------
clear;close all;fclose all;
figDir = 'figure_8';

% left panel
spec_904_aux_full201250;
bol_detrend_w = 0;
forecast_vintage_aux_2model;
if ~exist(gpath,'dir'), mkdir(gpath); end
hairplots_plotting(mspec,ti,20,[spath,'hairs/'],gpath,bol_detrend_w,'tv');

clearvars -except figDir;

% right panel
spec_904_aux_full201250;
bol_detrend_w = 1;
forecast_vintage_aux_2model;
hairplots_plotting(mspec,ti,20,[spath,'hairs/'],gpath,bol_detrend_w,'tv');

%% ------------------------------------------------------------------------
% figure A-1
% -------------------------------------------------------------------------
clear;close all;fclose all;
figDir = 'figure_A1';
spec_904_aux;
cum_flag = 1;
forecast_vintage_aux;
forplot_vint_aux;
plotVintage_aux;

%% ------------------------------------------------------------------------
% figure A-2
% -------------------------------------------------------------------------
clear;close all;fclose all;
figDir = 'figure_A2';
plotInfHist;

%% ------------------------------------------------------------------------
% figure A-3
% -------------------------------------------------------------------------
clear;close all;fclose all;
figDir = 'figure_A3';
SWpiTilvMC = 1;
comparePiTil;

%% ------------------------------------------------------------------------
% figure A-4
% -------------------------------------------------------------------------
% left panel
clear;close all;fclose all;
figDir = 'figure_A4';
mspec0 = 904;
simpleShockDec;
% right panel
clear;close all;fclose all;
figDir = 'figure_A4';
mspec0 = 803;
simpleShockDec;

%% ------------------------------------------------------------------------
% figure A-5
% -------------------------------------------------------------------------
clear;close all;fclose all;
figDir = 'figure_A5';
spec_904_aux_full201250;
forecast_vintage_aux;
f = figure();
fcastType = {'','_ar2','_rw'};
lineStyles = {'rs-','cs-','gs-'};
leg = {'DSGE','AR(2) recursive','Random Walk'};
dts = tiI;
start = 1989.75;
hairs_rmse_fn(mspec,fcastType,lineStyles,leg,gpath,spath,dts,start);

%% ------------------------------------------------------------------------
% figure A-6
% -------------------------------------------------------------------------
clear;close all;fclose all;
% generate ex-post smoothed states and shocks
spec_904_aux_full201250;
bol_detrend_w = 1;
forecast_vintage_aux_2model;
clear;

% generate forecast plots (figure 1, left panel of figure 2 and figure 3)
spec_904_aux;
bol_detrend_w = 1;
figDir = 'figure_A6';
forecast_vintage_aux;
forplot_vint_aux;
plotVintage_aux;

