function [dt,Y_f, fig_insample,fig_fcast] = phillips(data_file,start_dt,est_dt,L_i,L_u,model_type,varargin)

%% Some argument checks
if nargin == 7
    bol_plot = varargin{1};
else
    bol_plot = 0;
end

if ~strcmp(model_type,'dPi') && ~strcmp(model_type,'Pi')
    error(['model type [',model_type,'] not supported... (supported types: dPi and Pi)']);
end

%% DATA pre-processing

% load data, get dates
RAW = load(data_file);
dt  = RAW(:,1);
if isempty(find(dt == start_dt)) || isempty(find(dt == est_dt))
    error([data_file,' does not have data back to ',num2str(start_dt),...
        ' or up to ',num2str(est_dt)]);
end

I_end = size(RAW, 1);

% Dependent variable
Y  = [NaN; 400 * log(RAW(2:end,2)./RAW(1:end-1,2))];
dY = [NaN; Y(2:end) - Y(1:end-1)];

% Unemployment
tmp_u = 100*log(RAW(:,3));     % u_t
X_u = nan(size(tmp_u,1), L_u);  % unemployment data matrix

for i = 1:L_u
    X_u(1+i:end,i) = tmp_u(1:end-i);
end

% Inflation
tmp_i  = Y;
dtmp_i = dY;
X_i    = nan(size(tmp_i,1), L_i);
dX_i   = nan(size(dtmp_i,1), L_i);

for i = 1:L_i
    X_i(1+i:end,i)  = tmp_i(1:end-i);
    dX_i(1+i:end,i) = dtmp_i(1:end-i);
end

% End of estimation period date
I_est  = find(dt == est_dt);

if strcmp(model_type,'dPi') 
%% MODEL 1 dPi(t+1) = phi + beta(L)u(t) + gamma(L)dPi(t) + e(t+1)    
    % Estimate
    %I0 = 1 + max(L_u, L_i + 2);
    I0 = find(dt == start_dt);
    disp(sprintf('Startdate = %4.2f', dt(I0)));
    
    dY1 = dY(I0:I_est);
    X1 = [ones(I_est-I0+1,1), X_u(I0:I_est,:), dX_i(I0:I_est,:)];
    
    B1 = (X1' * X1)^-1 * X1' * dY1;
    
    Y_insample = cumsum([Y(I0-1);(X1*B1)]);
    Y_insample = Y_insample(2:end,1);
    
    % Forecast
    dY_f = nan(I_est,1);
    dY_f(I0:I_est) = dY1;
    
    for i = I_est+1:I_end
        dY_f(i) = [1, X_u(i,:), dY_f(i-1:-1:i-L_i)'] * B1;
    end
    
    Y_f = [Y(1:I_est-1);cumsum([Y(I_est); dY_f(I_est+1:end)])];
elseif strcmp(model_type,'Pi')
%% MODEL 2 Pi(t+1) = phi + beta(L)u(t) + gamma(L)Pi(t) + e(t+1)
    
    % Estimate
    %I0 = 1 + max(L_u, L_i + 1);
    I0 = find(dt == start_dt);
    disp(sprintf('Startdate = %4.2f', dt(I0)));
    
    Y2 = Y(I0:I_est);
    X2 = [ones(I_est-I0+1,1), X_u(I0:I_est,:), X_i(I0:I_est,:)];
    
    B2 = (X2' * X2)^-1 * X2' * Y2;
    
    Y_insample = X2*B2;
    
    % Forecast
    Y_f = nan(I_est,1);
    Y_f(I0:I_est) = Y2;
    
    
    for i = I_est+1:I_end
        Y_f(i) = [1, X_u(i,:), Y_f(i-1:-1:i-L_i)'] * B2;
    end
end

%% Produce plots
if bol_plot
    % in-sample fit
    fig_insample = figure();
    plot(dt(I0:I_est),Y(I0:I_est),'k-');
    hold on;
    plot(dt(I0:I_est),Y_insample,'r-');
    title('in-sample fit');
    
    % forecast
    fig_fcast = figure();
    plot(dt(I_est:I_end),Y(I_est:I_end),'k-');
    hold on;
    plot(dt(I_est:I_end),Y_f(I_est:I_end),'r-');
    title('forecast');
else
    fig_insample = [];
    fig_fcast = [];
end

%% Shorten
dt  = dt(I0:I_end);
Y_f = Y_f(I0:I_end); 

    
    

