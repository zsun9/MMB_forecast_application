
%% This script runs the backward looking phillips curve estimation

%% Initialization
spec_904_aux;
spec_realtime;
initializePrograms;

keep tiI spath mnobss;

%% set arguments
model_type = 'Pi';
start_dt = tiI(1);
est_dt = tiI(end);
data_file = './phillips/phillips_data.csv';
L_i = 4;
L_u = 4;
bol_plot = 1;

%% run estimation
[dt,Y_f, fig_insample,fig_fcast] = phillips(data_file,start_dt,est_dt,L_i,L_u,model_type,bol_plot);

ii = find(dt==est_dt)-mnobss+1;

phillips_fcast = [dt(ii:end,1),Y_f(ii:end,1)/4];

%% save
if ~exist([spath,'phillips','dir']), mkdir([spath,'phillips']); end
save([spath,'phillips/phillips_GR.mat'],'phillips_fcast');
