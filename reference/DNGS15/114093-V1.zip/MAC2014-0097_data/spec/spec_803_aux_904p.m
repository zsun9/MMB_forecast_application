%% MODEL 700 is Model 6 with real wage growth;

baseDir = fileparts(which('spec_904_aux'));
inFile  = 'mhparam9049354700020085020Mode'
paramFile = fullfile(baseDir, '..', 'save', inFile);
paramSpecFile = 'spec_904_aux';

%MODEL SPECIFICATIONS
mspec=803;
subspec=9;
pf_mod='52';
dataset=700;

paramDate = 2008.50;
peachfile='peachdata_2012_04_17';

bolUseFinals=1;
% bolUseFinals=2;

% aux variables
auxFlag=1;
%saveSemiCondStShFlag = 1;
useRtParallelResults = 0;

% ovint=71;
%ovint=83;
ovint=86;
%OOS specific settings
OOS='FULL';
fmean=1;

PLOTDRAWS=0;
lastvint=0;
vcov=0;

judge='BC';

compound=0;

first=0;

qahead=40;

nantmax=2;
%nantmax=1;
%nantmax = 3;

%   nant=7;
nant=0;

%nantmax=10;
%nant=7;

antlags=15;
%antlags=0;

dsge=1;
gbook=1;
bluechip=0;
roch=1;

%vindex=[59];
qvint=1;

%dates=2011;
%stime=[];%111;
mnobss=16;

REMAX_MODE=1;

%SAVE SETTINGS
overwrite = 1;


%FORECAST SETTINGS
zerobound = 0;
bdd_int_rate = 0;

dsflag = 0;
peachflag = 0;

simple_forecast = 0;


%NEWSLETTER SETTINGS
issue_num=10;

newsletter = 0;
system = 0;
pres = 1;

useSavedMB = 0;


%PARALLEL SETTINGS
%parallelflag = 1;
%parflag = 1;
distr=1;
nMaxWorkers=20;
