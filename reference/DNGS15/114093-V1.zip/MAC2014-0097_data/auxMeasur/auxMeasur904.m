%% auxilary ZZ block
function [ZZZ, DDD, QQQ] = auxMeasur904(ZZ, DD, QQ, mspec, varargin)

global rwMC;

if nargin == 8
    TTT = varargin{1};
    para = varargin{2};
    paraAlt = varargin{3};
    zb = varargin{4};
end

%% Parameters
[alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,ppsi,nu_l,zeta_w,iota_w,law,laf,bet,Rstarn,psi1,psi2,psi3,pistar,sigmac,rho,epsp,epsw...
    gam,Lmean,Lstar,gstar,rho_g,rho_b,rho_mu,rho_z,rho_laf,rho_law,rho_rm,rho_sigw,rho_mue,rho_gamm,rho_pist...
    sig_g,sig_b,sig_mu,sig_z,sig_laf,sig_law,sig_rm,sig_sigw,sig_mue,sig_gamm,sig_pist,eta_gz,eta_laf,eta_law...
    zstar,rstar,rkstar,wstar,wl_c,cstar,kstar,kbarstar,istar,ystar,sprd,zeta_spb,gammstar,vstar,nstar,...
    zeta_nRk,zeta_nR,zeta_nsigw,zeta_spsigw,zeta_nmue,zeta_spmue,zeta_nqk,zeta_nn] = getpara00_904(para);

eval(strcat('states',num2str(mspec)));

y_t1 = n_end+n_exo+n_exp+1;
w_t1 = n_end+n_exo+n_exp+4;
pi_t1 = n_end+n_exo+n_exp+5;
L_t1 = n_end+n_exo+n_exp+6;

% for psi swap
% tmp = para;
% para = paraAlt;
% paraAlt = tmp;

% % Labor Share
% ZZ(10,w_t) = 1;
% ZZ(10,L_t) = 1;
% ZZ(10,y_t) = -1;

% Return on Capital
ZZ(10,rk_t) = 1;

% Marginal Cost
ZZ(11,mc_t) = 1;
% Wages
ZZ(12,w_t) = 1;

% Output Gap
ZZ(13,y_t) = 1;
ZZ(13,y_f_t) = -1;


K = -1;

% kappaBar = getKappa( paraAlt, mspec );
% [SSS, bbar] = getSSS( para, mspec, K, 'spec_904_aux', zb );

kappaBar = getKappa( para, mspec ); % for exp to calc states with 904 and Sinf with SW
[SSS, bbar]   = getSSS( paraAlt, mspec, K); % for exp to calc states with 904 and Sinf with SW


if rwMC
    % S^K_t (K=-1 -> K=infinity)
    ZZ(14,mc_t) = (1-bbar)^-1;
    
    % kappa*S^K_t
    ZZ(15,mc_t) = kappaBar*(1-bbar)^-1;
    
    % kappa*S^inf_t + iota_p*pi_{t-1}
    %ZZ(16,mc_t) = kappaBar*(1-bbar)^-1;
else
    % S^K_t (K=-1 -> K=infinity)
    ZZ(14,:) = SSS(mc_t,:);
    
    % kappa*S^K_t
    ZZ(15,:) = kappaBar*SSS(mc_t,:);
    
    % kappa*S^inf_t + iota_p*pi_{t-1}
    %ZZ(16,:) = kappaBar*SSS(mc_t,:);
end

%ZZ(16,pi_t1) = ZZ(16,pi_t1) + iota_p;

% log labor share
%ZZ(16,w_t)  = 1;
%ZZ(16,w_t1) = -1;
%ZZ(16,L_t)  = 1;
%ZZ(16,L_t1) = -1;
%ZZ(16,y_t)  = 1;
%ZZ(16,y_t1) = -1;
% entrepreneur net worth
ZZ(16,n_t) = 1;
% pi* + pi*_t

ZZ(17,pist_t) = 1;
DD(17) = 100*(pistar-1);

% 5-yr implied inflation expectations

% TTT5 = (1/20)*((eye(size(TTT,1)) - TTT)\(TTT - TTT^21));
% ZZ(18,:) =  TTT5(pi_t,:);
% DD(18) = 100*(pistar-1);

% leverage

ZZ(18,qk_t) = 1;
ZZ(18,kbar_t) = 1;
ZZ(18,n_t) = -1;

ZZZ = ZZ;
QQQ = QQ;
DDD = DD;
