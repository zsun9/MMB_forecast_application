function [lnpost,lnpy,zend,ZZ,DD,QQ] = objfcnmhdsge(para,bounds,YY,YY0,nobs,lambda,nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,TTT,RRR,CCC,valid,para_mask,coint,cointadd,cointall,YYcoint0,varargin);

if valid < 1;
    lnpost = -1E10;
    lnpy   = -1E20;
    zend = [];
    ZZ = [];
    DD = [];
    QQ = [];
    return;
end

ind1 = (para > bounds(:,2));
ind1(logical(para_mask)) = [];
ind2 = (para < bounds(:,1));
ind2(logical(para_mask)) = [];

if any(ind1) || any(ind2)
    lnpost = -1E10;
    lnpy   = -1E20;
    zend = [];
    ZZ = [];
    DD = [];
    QQ = [];
else

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% step 2: define the measurement equation: X_t = ZZ S_t +D+u_t
%% where u_t = eta_t+MM* eps_t with var(eta_t) = EE
%% where var(u_t) = HH = EE+MM QQ MM', cov(eps_t,u_t) = VV = QQ*MM'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ZZ,DD,DDcointadd,QQ,EE,MM,retcode] = ...
  feval(['measur' num2str(mspec)], TTT,RRR,valid,para,nvar,nlags,mspec,npara,coint,cointadd);

if retcode == 0
    % invalid parameterization
    pyt = -1E10;
    return;
end;

nstate  = size(TTT,1);
nshocks = size(RRR,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% step 3: compute log-likelihood using Kalman filter - written by Iskander
%%         note that Iskander's program assumes a transition equation written as:
%%         S_t = TTT S_{t-1} +eps2_t, where eps2_t = RRReps_t 
%%         therefore redefine QQ2 = var(eps2_t) = RRR*QQ*RRR'
%%         and  VV2 = cov(eps2_t,u_u) = RRR*VV
%%         define VVall as the joint variance of the two shocks VVall = var([eps2_t;u_t])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

if coint == 0,

    %% truncate system matrices
    ZZ = ZZ(1:nvar,:);
    DD = DD(1:nvar,:);
    EE = EE(1:nvar,1:nvar);
    MM = MM(1:nvar,:);

    HH = EE+MM*QQ*MM';
    VV = QQ*MM';
    VVall = [[RRR*QQ*RRR',RRR*VV];[VV'*RRR',HH]];

    if any(CCC ~= 0)
      DDadd = ZZ*((eye(size(TTT))-TTT)\CCC);
    else
      DDadd = 0;
    end
    DD= DD+DDadd;

    %% Define the initial mean and variance for the state vector
    A0 = zeros(nstate,1);
    P0 = dlyap(TTT,RRR*QQ*RRR');

    if ~isempty(YY0)
      %% run Kalman filter on initial observations
      [xxx,zend,Pend] = ...
          kalcvf2NaN(YY0',1,zeros(nstate,1),TTT,DD,ZZ,VVall,A0,P0);
    else
      zend = A0;
      Pend = P0;
    end

    %% run Kalman filter on main sample                              
    [pyt,zend,Pend] = kalcvf2NaN(YY',1,zeros(nstate,1),TTT,DD,ZZ,VVall,zend,Pend);

else
    
    %% use system matrices for extended system
    if find(CCC) ~= nan,
        dfgdfsgdfgdf % if we get this error, we need to fix something
    end;
       
    DDcoint = DD(nvar+1:nvar+coint,:);
    ZZcoint = ZZ(nvar+1:nvar+coint,:);

    HH = EE+MM*QQ*MM';
    VV = QQ*MM';
    VVall = [[RRR*QQ*RRR',RRR*VV];[VV'*RRR',HH]];
       
    %% if you have constant, change the st st of observables and rewrite kalman as deviations from stst

    %% Define the initial mean and variance for the state vector
    A0 = zeros(nstate,1);
    P0 = dlyap(TTT,RRR*QQ*RRR');

    %% run Kalman filter for initial observations on extended system
        [pytcoint,zend,Pend] = ...
            kalcvf2NaN([YY0(1,:),YYcoint0]',1,zeros(nstate,1),TTT,DD,ZZ,VVall,A0,P0);

    %% run Kalman filter on remainder of initialization sample                              
    %% first, remove cointegration component from the system
    ZZ = ZZ(1:nvar,:);
    DD = DD(1:nvar,:);
    EE = EE(1:nvar,1:nvar);
    MM = MM(1:nvar,:);

    HH = EE+MM*QQ*MM';
    VV = QQ*MM';
    VVall = [[RRR*QQ*RRR',RRR*VV];[VV'*RRR',HH]];
    nstate = size(TTT,1);

    if nlags > 1
      [pyt0,zend,Pend] = ...
            kalcvf2NaN(YY0(2:end,:)',1,zeros(nstate,1),TTT,DD,ZZ,VVall,zend,Pend);
    end                              

    %% run Kalman filter on main sample                              
    [pyt,zend,Pend] = ...
          kalcvf2NaN(YY',1,zeros(nstate,1),TTT,DD,ZZ,VVall,zend,Pend);
                                                                                        
end;   

    lnpy    = real(pyt);
    lnprio  = priodens(para,pmean,pstdd,pshape);
    lnpost  = lnpy + real(lnprio);
    
end
