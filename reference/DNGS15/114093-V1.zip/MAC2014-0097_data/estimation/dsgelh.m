function pyt = dsgelh(para,YY,YY0,nobs,nlags,nvar,mspec,npara,coint,cointadd,YYcoint0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% step 1: solution to DSGE model - delivers transition equation for the state variables  S_t
%% transition equation: S_t = TC+TTT S_{t-1} +RRR eps_t, where var(eps_t) = QQ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[TTT,RRR,CCC,valid] = dsgesolv(para,mspec);

if valid < 1;
  pyt = -1E10;
  return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% step 2: define the measurement equation: X_t = ZZ*S_t + D + u_t
%% where u_t = eta_t+MM* eps_t with var(eta_t) = EE
%% where var(u_t) = HH = EE+MM QQ MM', cov(eps_t,u_t) = VV = QQ*MM'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%keyboard;
[ZZ,DD,DDcointadd,QQ,EE,MM,retcode] = ...
  feval(['measur' num2str(mspec)],TTT,RRR,valid,para,nvar,nlags,mspec,npara,coint,cointadd);

if retcode == 0
    % invalid parameterization
    pyt = -1E10;
    return;
end;

nstate  = size(TTT,1);
nshocks = size(RRR,2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% step 3: compute log-likelihood using Kalman filter - written by Iskander
%%         note that Iskander's program assumes a transition equation written as:
%%         S_t = TTT S_{t-1} +eps2_t, where eps2_t = RRReps_t
%%         therefore redefine QQ2 = var(eps2_t) = RRR*QQ*RRR'
%%         and  VV2 = cov(eps2_t,u_u) = RRR*VV
%%         define VVall as the joint variance of the two shocks VVall = var([eps2_t;u_t])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% truncate system matrices
ZZ = ZZ(1:nvar,:);
DD = DD(1:nvar,:);
EE = EE(1:nvar,1:nvar);
MM = MM(1:nvar,:);

HH = EE+MM*QQ*MM';
VV = QQ*MM';
VVall = [[RRR*QQ*RRR',RRR*VV];[VV'*RRR',HH]];

if any(CCC ~= 0)
  DDadd = ZZ*((eye(size(TTT))-TTT)\CCC);
else
  DDadd = 0;
end

DD= DD+DDadd;

%% Define the initial mean and variance for the state vector
A0 = zeros(nstate,1);
P0 = dlyap(TTT,RRR*QQ*RRR');


if ~isempty(YY0)
  %%copied from dsge99's dsgelh.m
  if size(YY0,2) ~= size(ZZ,1)
    nvar0 = size(YY0,2);
    ZZ0 = ZZ(1:nvar0,:);
    DD0 = DD(1:nvar0,:);
    EE0 = EE(1:nvar0,1:nvar0);
    MM0 = MM(1:nvar0,:);

    HH0 = EE0+MM0*QQ*MM0';
    VV0 = QQ*MM0';
    VVall0 = [[RRR*QQ*RRR',RRR*VV0];[VV0'*RRR',HH0]];
  else
    ZZ0 = ZZ;
    DD0 = DD;
    VVall0 = VVall;
  end
  %%copied from dsge99's dsgelh.m

  %% run Kalman filter on initial observations
  [pyt0,zend,Pend] = ...
        kalcvf2NaN(YY0',1,zeros(nstate,1),TTT,DD0,ZZ0,VVall0,A0,P0);
else
  zend = A0;
  Pend = P0;
end

%% run Kalman filter on main sample
[pyt,zend,Pend] = kalcvf2NaN(YY',1,zeros(nstate,1),TTT,DD,ZZ,VVall,zend,Pend);
