% OVERVIEW
% gibb.m: Applies the Random Walk Metropolis Hastings algorithm to produce parameter draws
%         from the high-dimensional posterior distribution. The output from
%         this program is a set of parameter draws, as well as the matrices
%         of the solved system corresponding to these parameter draws (T, R, and C),
%         and the end-of-sample filtered state (S_T/T, also known as zend).

%         gibb.m is set so that:
%         (1) We always re-maximize from an input mode
%         (2) We always re-calculate the Hessian corresponding to the mode
%
%         gibb.m clears the workspace and re-runs if any diagonal elements
%         of the hessian are negative or if csminwel.m (program that
%         re-maximizes from an input mode, to find a new mode) does not
%         converge within <nit> iterations.
%
%         Comments are are based on: An and Schorfeide (2007) "Bayesian
%         Analysis of DSGE Models (p. 131).

% IMPORTANT VARIABLES
% infile0: this string variable is a name of a file that holds a posterior
%          mode, typically from a similar model either of the same quarter
%          or of the previous quarter.
% nit: number of iterations in which we run csminwel.m. csminwel.m stops
%      if it meets the convergence criterion or if does not converge within
%      nit iterations.
% cc: a constant that scales the inverse Hessian, which is used to calculate
%     the variance of the proposal distribution for drawing new parameters
%     vectors.
% nblock: The MH algorithm is run in <nblock> blocks. We typically discard
%         the first block when we use the parameter draws for forecasting.
% ntimes: Each block consists of <ntimes*nsim> iterations of Step 4 of
%         the algorithm specified in An and Schorfeide (2007) "Bayesian
%         Analysis of DSGE Models (p. 131).

% CHANGES
% 6/20/2011: Removed sections under conditional "if ~isnan(lambdas)".
%            "lambda is the weighting factor used in the DSGEVAR model.
%             It determines how strongly weighted the VAR is relative to the
%             DSGE. Lambda = NaN is a DSGE model."
%            This program now applies to lambda = NaN only.
%
%            Removed sections under conditional "if coint".
%            Removed sections under conditional "if ROLL".
%            Removed sections under conditional if(any(mspec==[2,3]))


%%  Basic Initialization (Reads in data and model specifications)
initializePrograms;
marglh = 'marglh';

MPol = 0;

%%  Configure the Metropolis Algorithm

% Setting the jump size for sampling
cc0 = 0.01;
cc = .09;
date_q = (1:1:qahead)';
nobs = size(YY,1);
lambda = NaN*nobs;


%% Evaluate posterior at a parameter vector, para

% para is set in mspec_parameters<mspec>.m
[post_values,like_values,prior_values] = feval(strcat('objfcndsge'),para,...
    YY,YY0,nobs,lambda,nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,para_mask,...
    para_fix,marglh,coint,cointadd,cointall,YYcoint0,0);


Ob = feval(strcat('objfcndsge'),para,...
    YY,YY0,nobs,lambda,nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,para_mask,...
    para_fix,marglh,coint,cointadd,cointall,YYcoint0,0);

format long g
disp('Objective Fcn at Starting Value');
disp(Ob)

%% Step 1: Finding the posterior mode (An and Schorfheide (2007) p 131)
%% Step 1a: Finding the posterior mode: starting point

% Finding the posterior mode involves
% (1) Setting an initial parameter vector as a starting point (params)
% (2) Re-maximizing from the starting point

% The initial parameter vector, params, can take one of the following
% values in order of descending preference:
%
%   1. The ideal option is a previously re-maximized posterior mode from the same quarter.
%   2. The next best option is a previously re-maximized posterior mode from
%      the previous quarter.
%   3. If neither of these is available, we usually specify infile0 in a
%      pre-spec (a user's personal version of spec, ie spec_jc.m). The string
%      variable infile0 is the name of a file that contains a posterior mode
%      from a similar model, either of the same quarter or of the previous quarter.
%   4. Finally, if all of these options are not available or preferable,
%      we use the para vector (created is mspec_paramters<mspec>.m), a
%      default vector of plausible parameter values.

% If we must use the default vector para as the starting point, gibb.m
% automatically re-maximizes from this point. Otherwise, we can choose
% whether or not we want to re-maximize (default option is to re-maximize).

% Theoretically, the MH algorithm should converge to the same value with
% any starting point. However, using starting points at the top of the list
% will result in faster convergence and will increase the likelihood that we
% get results in line with previous runs of gibb.m.

clear params*;

% Set infile0
if ~exist('infile0','var'),
  infile0 = [spath,'/mhpara',lmodel,'Mode'];
else
  if exist(infile0,'file')
    disp('Using pre-specified posterior mode file.')
  end
end

%% Step 1b: Finding the posterior mode: re-maximization

% In order to re-maximize from a starting point, csminwel.m
% minimizes the inverse of the objective function (the posterior value),
% calculated in objfcndsge.m.

% objfcndsge.m calculates the posterior value as
% ln(P(theta|Y)) = - (ln(P(Y|theta)) + ln(P(theta))),
% since P(Y) is constant across parameters.

% The following variables are inputs to csminwel.m:
%   objfcndsge: name of the objective function
%   x0: initial inverse parameter vector.
%       These are parameters transformed from ?? modal to ?? max
%       using invtrans.m and trspec (specified in transp<mspec>.m).
%       Note: trans.m and invtrans.m are complement functions.
%   H0: initial inverse Hessian
%   nit: number of iterations in which we run csminwel.m
%   crit: convergence criterion
%   MIN: 1 = minimize inverse of objective function (value of posterior);
%        0 = maximize objective function
if exist(infile0,'file');

    % If infile0 exists, we read it in, and we can choose whether or not
    % we % want to re-maximize from this point (reoptimize = 1 or 0) - but by
    % default, we always choose to do so (reoptimize = 1).
    fid0 = fopen(infile0,'r');
    params = fread(fid0,[npara,1],'single');
    params = params.*(1-para_mask)+para_fix.*para_mask;
    fclose(fid0);

    Ob = feval(strcat('objfcndsge'),params,...
    YY,YY0,nobs,lambda,nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,para_mask,...
    para_fix,marglh,coint,cointadd,cointall,YYcoint0,0)

    if ~exist('reoptimize','var'), reoptimize = 1; end

    if reoptimize == 1
      x0 = invtrans(params,trspec);% +.01*randn(npara,1);
      H0 = eye(npara)*1E-4;
      nit = 80; % input('number of iterations?');
      crit= 1E-10;
      MIN = 1;
      [fh,xh,g,H,itct,fcount,retcode] = csminwel('objfcndsge',x0,H0,[],crit,nit,...
          YY,YY0,nobs,lambda,nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,para_mask,...
          para_fix,marglh,coint,cointadd,cointall,YYcoint0,MIN);

      % Transform modal parameters so they are no longer bounded (i.e., allowed 
      % to lie anywhere on the real line).
      xh = real(xh);
      params = trans(xh,trspec);

      % If we choose to fix any of the parameters (i.e., not estimate them), here
      % we reset those parameters to those fixed values.
      params = params.*(1-para_mask)+para_fix.*para_mask;
    end

else

    % If we must use the default vector para as the starting point,
    % gibb.m automatically re-maximizes from this point.
    disp('No posterior mode file for current or previous period, using para vector as starting point.')
    reoptimize = 1;

    params = para;
    x0 = invtrans(params,trspec);% +.1*randn(npara,1);
    H0 = eye(npara)*1E-4;
    nit = 100;
    crit= 1E-10;
    MIN = 1;

    [fh,xh,g,H,itct,fcount,retcode] = csminwel('objfcndsge',x0,H0,[],crit,nit,...
        YY,YY0,nobs,lambda,nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,para_mask,...
        para_fix,marglh,coint,cointadd,cointall,YYcoint0,MIN);

    xh = real(xh);
    params = trans(xh,trspec);
    params = params.*(1-para_mask)+para_fix.*para_mask;
end

% Once we get a re-maximized mode, we evaluate the objective function at
% this point and save the parameter vector in a binary file named
% mhparam*Mode.
Ob = feval(strcat('objfcndsge'),params,...
           YY,YY0,nobs,lambda,nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,para_mask,...
           para_fix,marglh,coint,cointadd,cointall,YYcoint0,0);
outfile0 = [spath,'/mhpara',lmodel,'Mode'];
fid0 = fopen(outfile0,'w');
fwrite(fid0,params','single');
fclose(fid0);

% csminwel.m will stop if it reaches its convergence criterion, or if it
% reaches nit iterations. If the latter happens, we want gibb.m to save the
% parameter vector it has arrived at as the mode, and then re-run gibb so
% that it re-maximizes from this point (don't pre-specify infile0, since
% gibb.m automatically chooses an infile0 consistent with the model and
% quarter specified), which will allow csminwel.m to refresh its gradient.

% We only want a re-maximized mode that csminwel.m arrives at when it
% satisfies its convergence criterion, not when it exceeds nit iterations.

% gibb.m is set up to stop and re-run if nit iterations is exceeded.
if CH==1
  if itct >= nit
    clear infile0;
    gibb_recall=1;
    gibb;
    return;
  end
end

return;  %% We just want to replicate the mode. Comment this line out to compute
         %% Hessian matrix and run MCMC.

%% Step 2: Compute the inverse Hessian
%% Step 2a: Calculate the Hessian corresponding to the posterior mode
% Once we find and save the posterior mode, gibb.m calculates the hessian
% at the mode. The hessian is used to calculate the variance of the proposal distribution,
% which is used to draw a new parameter in each iteration of the algorithm.
% Like the posterior mode, if there is a pre-specified file,
% the hessian is loaded in from there. Otherwise, the hessian is loaded in
% from a file consistent with the model and quarter. Whether or not the
% file exists, we re-compute the hessian. If any of the hessian diagonals
% are negative, we terminate and re-run gibb.m. saddle point??
if ~exist('infile00','var')
    infile00 = [spath,'/cov',lmodel];
end

if exist(infile00,'file') && ~CH;
    fid00 = fopen(infile00,'r');
    theta_cov = fread(fid00,[npara,npara],'single')';
    fclose(fid00);

    [u,s,v] = svd(theta_cov);
    sigpropinv = theta_cov;
    md = min(size(s));
    bigev = find(diag(s(1:md,1:md))>1e-6);
    sigpropdim = length(bigev);

    sigproplndet = 0;

    for i = 1:npara
        if i > sigpropdim
            s(i,i) = 0;
        else
            sigproplndet = sigproplndet + log(s(i,i));
        end
    end

    sigscale = u*sqrt(s);

    fprintf('\n \n Using pre-calculated covariance matrix for transition density.');

else
    if ~exist('infile01','var')
      infile01 = [spath,'/hessian',lmodel,'Mode'];
    else
      disp('Using pre-specified hessian file');
    end

    if exist(infile01,'file');
      fid01 = fopen(infile01,'r');
      hessian = fread(fid01,[npara,npara],'single')';
      fclose(fid01);

      if ~exist('CH','var'), CH = 1; end
      if CH == 1
        MIN = 0;
        hessian = hessizero('objfcndsge',[params,para_mask],1,...
                  YY,YY0,nobs,lambda,nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,para_mask,...
                  para_fix,marglh,coint,cointadd,cointall,YYcoint0,MIN);
      end

      outfile01 = [spath,'/hessian',lmodel,'Mode'];
      fid01 = fopen(outfile01,'w');
      fwrite(fid01,hessian(:),'single');
      fclose(fid01);
    else
        CH = 1;
        if CH == 1
            MIN = 0;
            hessian = hessizero('objfcndsge',[params,para_mask],1,...
                      YY,YY0,nobs,lambda,nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,para_mask,...
                      para_fix,marglh,coint,cointadd,cointall,YYcoint0,MIN);
            outfile01 = [spath,'/hessian',lmodel,'Mode'];
            fid01 = fopen(outfile01,'w');
            fwrite(fid01,hessian(:),'single');
            fclose(fid01);
        else
            hessian = eye(npara);
        end;
    end

    if any(diag(hessian)<0) && any(mspec==[804 805]) % then terminate program, clear workspace and re-run
        display('switching signs');
        negs=find(diag(hessian)<0)
        hessian(negs,negs)=-hessian(negs,negs);
    end

    if any(diag(hessian)<0)
        error('negative in diagonal of hessian');
    end


    %% Step 2b: Create inverse by Singular Value Decomposition

    rankhhm = npara;
    [u,s,v] = svd(hessian);
    sigpropinv  =  hessian;
    md = min(size(s));
    bigev = find(diag(s(1:md,1:md))>1e-6);
    sigpropdim = length(bigev);

    sigproplndet = 0;

    for i = 1:npara
        if i > sigpropdim
            s(i,i) = 0;
        else
            s(i,i)    = 1/s(i,i);
            sigproplndet = sigproplndet+log(s(i,i));
        end
    end

    invhhm  = u*s*u';
    sigscale = u*sqrt(s);
    clear hessian*;

    if length(bigev) ~= (npara-length(find(para_mask)))
      disp('problem -- shutting down dimensions')
      pause
    end
end % else for infile00

%% Step 3: Initialize algorithm by drawing para_old from a normal distribution centered on the posterior mode (propdens).

% para_old is used to solve the model to check for indeterminancy, and it is
% passed through objfcnmhdsge.m to calculate the posterior value.

% objfcnmhdsge.m is similar to objfcndsge.m, except it also checks that parameters
% are within the bounds specified in mspec_parameters<mspec>.m. Until the parameters
% are within bounds, or until the posterior value is sufficiently large, gibb.m
% keeps drawing a new para_old (if you see multiple lines of "initializing"
% in the command window, this is the problem)

[TTT,RRR,CCC,valid] = dsgesolv(params,mspec);
retcode = valid;
[lnpost0,lnpy0,zend0,ZZ0,DD0,QQ0] = feval('objfcnmhdsge',params,bounds,YY,YY0,nobs,lambda,...
                                    nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,...
                                    TTT,RRR,CCC,valid,para_mask,coint,cointadd,cointall,YYcoint0);

jc = 1;
valid0 = 0;
while ~valid0
  jc = jc+1;

  para_old   = params + cc0*(sigscale*randn(npara,1));
  para_old = para_old.*(1-para_mask)+para_fix.*para_mask;

  [TTT_old,RRR_old,CCC_old,valid_old] = dsgesolv(para_old,mspec);
  nstate = length(TTT_old);
  nshocks = size(RRR_old,2);

  retcode = valid_old;
  [post_old,like_old,zend_old,ZZ_old,DD_old,QQ_old] = feval('objfcnmhdsge',para_old,bounds,YY,YY0,nobs,lambda,...
                                                      nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,TTT_old,...
                                                      RRR_old,CCC_old,valid_old,para_mask,coint,cointadd,cointall,YYcoint0);

  propdens  = -0.5*sigpropdim*log(2*pi) - 0.5*sigproplndet - 0.5*sigpropdim*log(cc0^2) ...
              -0.5*(para_old - params)'*sigpropinv*(para_old - params)/cc0^2;

  if post_old > -10000000;
      valid0 = 1
  end

  record(jc) = post_old;
  disp('Initializing Metropolis-Hastings Algorithm')

end

tic
fprintf(1,'\n Time %3.2f ',ti(I));
fprintf(1,'\n Peak = %2.3f',lnpost0);

%% Open files for saving
% Once you open files for writing, the original files (if they existed)
% have been overwritten.

% Draws from the posterior
outfile1 = [spath,'/mhpara',lmodel];
fid1 = fopen(outfile1,'w');

% Posterior value
outfile4 = [spath,'/post',lmodel];
fid4 = fopen(outfile4,'w');

outfile11 = [spath,'/TTT',lmodel];
fid11 = fopen(outfile11,'w');

outfile12 = [spath,'/RRR',lmodel];
fid12 = fopen(outfile12,'w');

outfile14 = [spath,'/zend',lmodel];
fid14 = fopen(outfile14,'w');

Tim = 0;
eT = 0;
reje = 0;

%% Step 4: For nsim*ntimes iterations within each block, generate a new parameter draw.
%%         Decide to accept or reject, and save every ntimes_th draw that is accepted.

for iblock = 1:nblocks

    if iblock >1; fprintf(1,' block: %2.0f %3.2f ;',[iblock,toc/(iblock-1)]); end;

    parasim = zeros(nsim,npara);
    likesim = zeros(nsim,1);
    postsim = zeros(nsim,1);
    rej     = zeros(nsim*ntimes,1);
    TTTsim = zeros(nsim,nstate^2);
    RRRsim = zeros(nsim,nstate*nshocks);
    CCCsim = zeros(nsim,nstate);
    zsim = zeros(nsim,nstate);

    for j = 1:nsim*ntimes

        Tim = Tim+1;

        %% Step 4a
        % Draw para_new from the proposal distribution (a multivariate normal
        % distribution centered on the previous draw, with standard
        % deviation cc*sigscale).

        para_new = para_old + cc*(sigscale*randn(npara,1));
        para_new = para_new.*(1-para_mask)+para_fix.*para_mask;
        [TTT_new,RRR_new,CCC_new,valid_new] = dsgesolv(para_new,mspec);
        retcode = valid_new;

        % Solve the model, check that parameters are within bounds, and
        % evalue the posterior.
        [post_new,like_new,zend_new,ZZ_new,DD_new,QQ_new] = feval('objfcnmhdsge',para_new,bounds,YY,YY0,nobs,lambda,...
            nlags,nvar,mspec,npara,trspec,pmean,pstdd,pshape,TTT_new,RRR_new,CCC_new,valid_new,para_mask,coint,cointadd,cointall,YYcoint0);


        % Calculate the multivariate log likelihood of jump from para_old to para_new
        propdens = -0.5*sigpropdim*log(2*pi) - 0.5*sigproplndet - 0.5*sigpropdim*log(cc^2) ...
                   -0.5*(para_new - para_old)'*sigpropinv*(para_new - para_old)/cc^2;


        % Choose to accept or reject the new parameter by calculating the
        % ratio (r) of the new posterior value relative to the old one
        % We compare min(1,r) to a number drawn randomly from a
        % uniform (0,1) distribution. This allows us to always accept
        % the new draw if its posterior value is greater than the previous draw's,
        % but it gives some probability to accepting a draw with a smaller posterior value,
        % so that we may explore tails and other local modes.

        r = min([1 ; exp( post_new - post_old)]);

        if rand(1,1) < r;
            % Accept proposed jump
            para_old = para_new;
            post_old = post_new;
            like_old = like_new;

            TTT_old = TTT_new;
            RRR_old = RRR_new;
            CCC_old = CCC_new;
            valid_old = valid_new;

            zend_old = zend_new;
            ZZ_old = ZZ_new;
            DD_old = DD_new;
            QQ_old = QQ_new;

        else
            % Reject proposed jump
            rej(j) = 1;
            reje = reje+1;

        end

        % Save every (ntime)th draw
        if (j/ntimes) == round(j/ntimes)
            likesim(j/ntimes,1) = like_old;
            postsim(j/ntimes,1) = post_old;
            parasim(j/ntimes,:) = para_old';
            TTTsim(j/ntimes,:) = TTT_old(:)';
            RRRsim(j/ntimes,:) = RRR_old(:)';
            CCCsim(j/ntimes,:) = CCC_old(:)';
            zsim(j/ntimes,:) = zend_old(:)';

        end

        if j == nsim*ntimes
            fprintf(1,'\nRejection perct %2.4f ',[sum(rej)/j]);
        end



    end % end j=1:nsim

    fwrite(fid1,parasim','single');
    fwrite(fid4,postsim','single');
    fwrite(fid11,TTTsim','single');
    fwrite(fid12,RRRsim','single');
    fwrite(fid14,zsim','single');

end % end iblock

toc

fprintf(1,'rejection rate = %2.4f',reje/Tim);


%% Calculate Parameter Covariance Matrix
infile1 = [spath,'/mhpara',lmodel];
num1 = nblocks*nsim*npara*4;            % number of bites per file
numb1 = nburn*npara*4;                  % number of bites to dicard
fid1 = fopen(infile1,'r');
status = fseek(fid1,numb1,'bof');


% Reshape parameter draws into a matrix so can calculate covariance
theta = [];
while ( ftell(fid1) < num1 ) % Read blocks of size nsim
  theta_add = fread(fid1,[npara,nsim],'single')';
  theta = [theta; theta_add];
end

% Calculate covariance and save
cov_theta = cov(theta);
outfile100 = [spath,'/cov',lmodel];
fid100 = fopen(outfile100,'w');
fwrite(fid100,cov_theta(:),'single');
fclose('all');

