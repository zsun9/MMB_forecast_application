% Run this at the start of most DSGE programs

%% Preliminary
Verbose = 0; 
run setpath
!hostname;
!ps -C matlab;
rand('state',sum(100*clock))
randn('state',sum(15*clock))

%% Call on spec.m
spec; 

%% Display important specifications
fprintf(1,'\n overwrite: %1.0f \n',[overwrite]);
fprintf(1,'\n zerobound: %1.0f \n peachflag: %1.0f \n dsflag: %1.0f \n jstep: %3.0f \n',[zerobound,peachflag,dsflag,jstep]);
fprintf(1,'\n model: %2.0f, subspec: %2.0f, prior: %2.0f, pf_mod: %1.0f, dataset: %2.1f \n',[mspec,subspec,mprior,str2double(pf_mod),dataset]);
fprintf(1,'\n newsletter: %1.0f system: %1.0f pres: %1.0f \n',[newsletter,system,pres]);

%% Set paths
[fpath,spath,gpath] = pathspec(dataset,figDir);

%% Load data
[YYall,XXall,ti,nobsall,dlpopall,dlMA_pop,MA_pop,population] = loaddata(dataset,fpath,T0,Tend,nvar,nlags,stime,mspec,pf_mod,auxFlag,psize,peachflag);

Iseq = find(ti == dates);
I = Iseq;

if stime<I
    YY = YYall(I-stime+1:I,:);
    XX = XXall(I-stime+1:I,:);
    tiI = ti(I-stime+1:I);
    % dlpop = dlpopall(endpop-stime+1:endpop);
    dlpop = dlpopall(I-stime+1:I);
    pop_smth = population(I-stime+2+nlags:I+1+nlags); % NEW - FOR AGG HOURS
    YY_p = YYall(1:I-stime,:);
    XX_p = XXall(1:I-stime,:);
    dlpop_p = dlpopall(1:I-stime);
    nobs_p = size(YY_p,1);
else 
    YY     = YYall(1:I,:);
    XX     = XXall(1:I,:);
    tiI = ti(1:I);
    
    % dlpop = dlpopall(endpop-I+1:endpop);
    dlpop = dlpopall(1:I,:);
    pop_smth = population(2+nlags:I+nlags); %% NEW - FOR AGG HOURS
    YY_p = nan(1,size(YY,2));
    XX_p = nan(1,size(YY,2));
    dlpop_p = NaN;%dlpopall(1:I-stime);
    nobs_p = 0;%size(YY_p,1);
end

nobs = size(YY,1);

Idate = find(tiI == dates);
tiall    = [tiI(1:end-1);(tiI(end):0.25:(tiI(end)+.25*(qahead+stime-Startdate)))'];
datesall = strcat(num2str(floor(tiall)),'-',num2str(round(1+4*(tiall-floor(tiall)))));


%% Calculate lagged growth rates
YY0 = zeros(nlags,size(YY,2)); 
nobs0 = size(YY0,1);
for lagind = 1:nlags
    YY0(nlags-lagind+1,:) = XX(1,1+(lagind-1)*nvar+1:1+lagind*nvar); 
end

% Possibly for ~isnan(lambdas)

YYYY = YY'*YY;
XXYY = XX'*YY;
XXXX = XX'*XX;

k = 1+nlags*nvar;
npsipara = (nvar-1)*k;
nsigpara = nvar*(nvar+1)/2;

%% Cumulative forecasts
ICUM = find(cum_for);
INCUM = find(cum_for == 0);

%% Load information for prior distribution
priorfile = ['pri',lprior];
prior = feval(priorfile);

pmean  = prior(1:npara,1);
pstdd  = prior(1:npara,2);
pshape = prior(1:npara,3);

pshape = pshape.*(1-para_mask);
pmean = pmean.*(1-para_mask)+para_fix.*para_mask;
pstdd = pstdd.*(1-para_mask);

nonpolipar = [1:1:npara];
nonpolipar(polipar) = [];

%% Load transformation scheme for parameters
trspec = eval(['transp',num2str(mspec),'(',num2str(mspec),')']);
trspec(:,1) = trspec(:,1).*(1-para_mask);
%% Set number of states and shocks
[TTT,RRR,CCC,valid] = dsgesolv(para,mspec);
valid_para = valid;
[nstate,nshocks] = size(RRR);

%% YYcoint0: lagged cointegration vector
if coint > 0
  YYcoint0 = XX(1,1+cointadd:cointall);
  for lagind = 1:(nlags-1)
    YYcoint0 = YYcoint0-XX(1,1+cointall+(lagind-1)*nvar+1:1+cointall+lagind*nvar)*cointvec';
  end
else
  YYcoint0 = [];
end
