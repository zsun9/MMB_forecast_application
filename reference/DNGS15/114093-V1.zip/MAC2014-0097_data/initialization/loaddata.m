%% loaddata
%
% Description: reads time series data from ASCII 
% Output: 
%        1) YYall ---> matrix of observables (5 columns)
%        2) XXall --->
%        3) ti -->
%        4) nobs --> number of periods in data imported  (e.g.1984.00 - 2010.50)
%        4) dlpopall --> log differences of the population obtained from Haver Analaytics
%        5) dlMA_pop --> log differences of the population forecasted by Macro Advisers
function [YYall,XXall,ti,nobs,dlpopall,dlMA_pop,MA_pop,population] = loaddata(dataset,fpath,T0,Tend,nvar,nlags,stime,mspec,pf_mod,auxFlag,psize,peachflag)

if dataset==700
    
    
    %load specific vintage (for correct judge) to generate specific plots
    load('./data/vintend.mat');
    
    
    if any(mspec==[809]);%dump long term inf %% temp move 804 to where 906 is
        vintend.series(:,end-1:end)=[];
    elseif any(mspec==[905 8051 815 816]);%dump spread, long term gdp %% TEMPORARILY MOVE 805 BELOW SINCE WE NEED TO UPDATE LONG RUN GDP EXP. STILL (RH: 2012-11-26)
        vintend.series(:,[end-2, end])=[];
    elseif any(mspec==[805]) %% TEMPORARILY PUT 805 HERE SINCE WE NEED TO UPDATE LONG RUN GDP EXP. STILL (RH: 2012-11-26)
        vintend.series(:,end-1)=[];
    elseif any(mspec==[305 303]);%dump spread
        vintend.series(:,end-2)=[];
    elseif any(mspec==[514 5142 5143 5144]);%dump consumption, investment, put in labor share
        vintend.series=[vintend.series(:,1:2),vintend.lshare,vintend.series(:,[4:5 8:end-1])];
    elseif any(mspec==[804 906]);%dump long term gdp %% TEMPORARILY MOVE 904 BELOW SINCE WE NEED TO UPDATE LONG RUN GDP EXP. STILL (RH: 2012-11-26)
        vintend.series(:,end)=[];
    elseif mspec==304 || any(mspec == [904 907]) ;%keep everything %% TEMPORARILY PUT 904 HERE SINCE WE NEED TO UPDATE LONG RUN GDP EXP. STILL (RH: 2012-11-26)
    elseif mspec == 803 %% TEMPORARILY PUT 803 HERE SINCE WE NEED TO UPDATE LONG RUN GDP EXP. STILL (RH: 2013-2-7)
        vintend.series(:,end-1:end)=[];
    else%dump long term inf,long term gdp, and spread
        vintend.series(:,end-2:end)=[];
    end
    
    if mspec==816;
        vintend.series(:,end+1:end+7) = vintend.ant(:,1:7);
        nvar=15;
    end
    
    % Adding Auxilary vars
    
    if auxFlag
        vintend.series(:,end+1:end+9) = nan(size(vintend.series,1),9);
    end
    
    j=length(vintend);
    
    ti=vintend.odate(1+nlags:end);
    nobs=length(vintend(j).odate);
    if mspec==745;
        YYall     = vintend(j).series(1+nlags:nobs,1:nvar);
        
        XXall     = ones(nobs-nlags, 1+nvar*nlags);
        for i = 1:1:nlags;
            XXall(:,1+(i-1)*nvar+1:1+i*nvar) = vintend(j).series(nlags-i+1:nobs-i,1:nvar);
        end
    else
        YYall     = vintend(j).series(1+nlags:nobs,1:nvar);%%nlags switched from T0, DF
        
        XXall     = ones(nobs-nlags, 1+nvar*nlags);
        %ti     = tii(1+nlags:nobs,:);
        
        for i = 1:1:nlags;
            XXall(:,1+(i-1)*nvar+1:1+i*nvar) = vintend(j).series(nlags-i+1:nobs-i,1:nvar);
        end
        
        XXall = [XXall;[1,YYall(end,:),XXall(end,1+1:1+nvar*nlags-nvar)]];
    end
    
    dlpopall = vintend(end).pop(~isnan(vintend(end).pop));
    dlpopall = (log(dlpopall(2:end)) - log(dlpopall(1:end-1)))/4;
    population = zeros(size(YYall,1)+nlags+1,1); %quick fix for addition of new return variable (RH 2012-10-15)
    %     MA_file = strcat(fpath,'MApop_forecast.txt'); % 1st data point should be Dick Peach's forecast of poulation growth
    %     MA_pop2 = importdata(MA_file);
    
    MA_pop2 = [239316.000;
        239868.896;
        240442.322;
        241045.384;
        241648.447;
        242235.000;
        242821.554;
        243408.108;
        243994.661;
        244578.302;
        245163.884];
    
    dlMA_pop2 = log(MA_pop2(2:end)) - log(MA_pop2(1:end-1));
    dlMA_pop = dlMA_pop2;
    % vintage(end).rfinal(end,end)/100;%vintage(end).pop(length(vintage(j).pop):end);
    MA_pop = MA_pop2;
    %dlMA_pop=[vintend.mapop;dlMA_pop2];
    dlpopall=vintend.dlpop(1+nlags:end)/100;
    
    nobs=size(YYall,1);
    
end