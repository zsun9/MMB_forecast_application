    if strcmp(judge,'BC');

        load('./data/vintagesBCTEST.mat');
        load('./data/bluechipTEST.mat');
        
        jvint=bchip;
    end
    
    if qvint
    qmat=zeros(1,length(vintage));
        for j=1:length(vintage)-1
            if vintage(j).fdate(1)~=vintage(j+1).fdate(1)
                qmat(j)=1;
            end
        end
        qmat(end)=1;
        vintage=vintage(logical(qmat));
        jvint=jvint(logical(qmat));
    end
       
    if  exist('ovint','var'),
        if exist('bolUseFinals','var') && ~bolUseFinals || ~exist('bolUseFinals','var')
            vintend=vintage(ovint);
        elseif exist('bolUseFinals','var') && bolUseFinals == 2
            vintage(ovint).series = vintend.series(1:size(vintage(ovint).series,1),:);
            vintage(ovint).dlpop = vintend.dlpop(1:size(vintage(ovint).dlpop,1),:);
            vintage(ovint).lshare = vintend.lshare(1:size(vintage(ovint).lshare,1),:);
            vintage(ovint).ant = vintend.ant(1:size(vintage(ovint).ant,1),:);
            
            if any(mspec == [803 805 904])
                vintage(ovint).longinf = vintend.series(size(vintage(ovint).series,1)+1:end,end);
            end
            
            %estVintDate = vintend.odate(end);
            vintend = vintage(ovint);
        end
        jvint=jvint(ovint);
    end
    
    jvint.forecast=[jvint.forecast(:,1),nan(length(jvint.fdate),2),jvint.forecast(:,2:end),nan(length(jvint.fdate),5)];

    display(sprintf('\n ******REALTIME******\n %s Vintage: %s',judge,vintend.date));
    
    vintend.mapop= vintage(1).rfinal(end-length(vintend.fdate)+1:end,end)/100;
  
    save('./data/vintend.mat','vintend','jvint');
    
    nlags=2;
    stime=length(vintend.odate)-nlags;
    dates=vintend.odate(end);
    if ~exist('mnobss','var'); mnobss=(dates-floor(dates-4))*4; end
    
    if ovint==length(vintage);
        r_exp = repmat(0.25/4,antlags+1,7);
    else
        r_exp = vintend.exp(:,3)';
        r_exp = r_exp(~isnan(r_exp));
    end
    % Create bluechip ExpFFR matrix
    if exist('antlags','var') %&& antlags > 0
        min_ = 100;
        ExpFFRbc = nan(antlags+1,100);
        
        if bolUseFinals == 1
            min_ = sum(~isnan(vintend.exp(:,3)));
            ExpFFRbc(end,1:min_) = vintend.exp(1:min_,3)';
        else
            min_ = sum(~isnan(vintage(ovint).exp(:,3)));
            ExpFFRbc(end,1:min_) = vintage(ovint).exp(1:min_,3)';
        end
        
        for i = 1:antlags
            nn_ = sum(~isnan(vintage(ovint-i).exp(:,3)));
            ExpFFRbc(end-i,1:nn_) = ...
                vintage(ovint-i).exp(1:nn_,3)';
            if nn_ < min_
                min_ = nn_;
            end
        end
        ExpFFRbc = ExpFFRbc(:,1:min_);
    end
       
    % choose Hbar for each date based on Bluechip < 0.5 rule
    zb_2model=1;
    if zb_2model
       Hbar = nan(antlags+1,1);
       
       for i = 1:antlags+1
           ix = find(ExpFFRbc(i,:) < 0.5/4,1,'last');
           if isempty(ix)
               ix = 0;
           end
           Hbar(i,1) = ix;
       end
           
    end
    
    hbar_OIS=1;
    if hbar_OIS
        Hbar = [2;3;2;2;2;2;4;6;4;3;5;9;9;8;11]; % From ExpFFR_OIS.m
    end
    
    nHb = length(Hbar);
      
    if nantmax==1
        nant=length(r_exp);
        zerobound=1;
    elseif nantmax==2
        nant;
        zerobound;
    elseif nantmax==3
        nant=size(ExpFFRbc,2);
        zerobound=1;
    else
        nant=0;
        zerobound=0;
     end