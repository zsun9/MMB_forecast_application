% filename: spec.m -- updated with 2010:Q2 data specifications
% description: 

%% Main model specifications and important flags
% Read more about these variables in the sections below. 
if ~exist('noTitles','var'),noTitles = 0;end
if ~exist('pistflag','var'),pistflag = 0;end
if ~exist('iter','var'), iter = 1; end
if ~exist('mspec','var'), mspec = 803; end
if ~exist('subspec','var'), subspec = 9; end
if ~exist('pf_mod','var'), pf_mod ='52'; end
if ~exist('figDir','var'), figDir = ''; end

% run model on dettrended wages?
if ~exist('bol_detrend_w','var'),bol_detrend_w = 0; end

if ~exist('dataset','var'),
    switch mspec
        case {803 804 805 904}, dataset = 700;
        otherwise
            error('Set dataset');
    end
end

if ~exist('peachflag','var'), peachflag = 1; end

if ~exist('history','var'), history = 0; end

%Set Gensys_plus to 1 to use alternate model solution method
if ~exist('gensys2','var'), gensys2 = 0; end
if ~exist('model2_num','var'), model2_num = ''; end
if ~exist('nant2','var'), nant2 = 0; end

% start of the great recession
if ~exist('GR_dt','var'), GR_dt = 2008.5;end

if ~exist('CH','var'), CH = 1; end
 
if ~exist('auxFlag','var'), auxFlag = 0; end

% name the figure output folder by the paper figure number
if ~exist('fig_str','var'), fig_str = ''; end

% get full history counterfactuals?
if ~exist('full_hist','var'), full_hist = 0; end

% get forecasts conditional on marginal cost?
if ~exist('bol_cond_mc','var'), bol_cond_mc = 0; end

if ~exist('cum_flag','var'), cum_flag = 0; end
if ~exist('ngdpflag','var'), ngdpflag = 0; end
if ~exist('phillips_mc','var'), phillips_mc = 0; end

% Set overwrite to 0 to keep parforecast, forplot from overwriting output files (i.e. for debugging).
if ~exist('overwrite','var'), overwrite = 1; end
           
% Set save_states to [4,5,6] if you want to save the path for states
% corresponding to 4,5, and 6 in states_{mspec}
if ~exist('save_states','var'), save_states = []; end

% Plotting product options
if ~exist('pres','var'), pres = 0; end % turning pres on will create eps files in addition to pdf files
if ~exist('system','var'), system = 0; end
if ~exist('newsletter','var'), newsletter = 1; end

%% Cointegration
coint = 0 
cointadd = 0
cointall = coint + cointadd;

%% Model Descriptions
[mspecdesc,subspecdesc,pf_moddesc,dsdesc] = modDesc(mspec,subspec,pf_mod,dataset);

%% Set prior
switch mspec
    case {803 805}, mprior=2;
    case {804 904}, mprior = 3;
end

%% Forecast: general options 
% peachflag==0: only unconditional forecast will be calculated
% peachflag==1: both unconditional and conditional forecasts will be calculated

if ~exist('qahead','var'),qahead = 60; end

% Do a simple forecast, with no smoothing or filtering the past. 
% This flag is used in the forecast program to allow for very quick forecasting.
if ~exist('simple_forecast','var'), simple_forecast = 0; end

%% Forecast: conditional data
peachstr = {'';'_peach'};

if peachflag
    psize = 1;
else
    psize = 0;
end

%% Parallel Processing

% For parallel programs using parfor loop(s)
if ~exist('parflag','var'), parflag = 1; end
if ~exist('pargibbflag','var'), pargibbflag = 0; end

% For alternative parallel programs using vcSubmitQueuedJobs
if ~exist('nMaxWorkers','var'),nMaxWorkers = 20; end
if ~exist('parallelflag','var'), parallelflag = 0; end % GET RID OF parallelflag, replace parallelflag with distr 
if ~exist('distr','var'); distr = 0; end;

%% Disturbance Smoothing
% Set this flag to 1 to use disturbance smoothing for states and
% counterfactuals as in Carter and Kohn (1994). Otherwise only the means
% from Kalman Smoothing will be used.

%% Turn Shocks off
if ~exist('sflag','var'), sflag = 0; end % sflag = 1: Turn all shocks off in the forecast

%% Forecast
if ~exist('useMode','var'), useMode = 0; end

%% Plotting: general specifications (forplot.m and plot_all.m)
if ~exist('useSavedMB','var'), useSavedMB = 0; end

if ~exist('fancharts','var'), fancharts = 1; end

%% Plotting: shockdec settings (forplot.m and plot_all.m)
if ~exist('shockdec_history','var'), shockdec_history = 0; end

%% Plotting: counterfactual settings (forplot.m and plot_all.m)
if ~exist('Shockremove','var'), Shockremove = 1; end

if ~exist('ShockremoveList','var'),
    switch mspec
        case {904}, ShockremoveList = [0:11];
        case {805}, ShockremoveList = [0:8];
        case {803 804}, ShockremoveList = [0:7];
        otherwise, error('Set ShockremoveList variable');
    end
end

Enddate_forecastfile = stime+qahead; % We always do a counterfactual forecast in case we want to plot it

%% Plotting: presentation options (forplot.m)
% Note: specifications for make_presentation.m are now in pres_spec.m
if ~exist('plotList','var')
    plotList = {'Forecast'};
end

%% Plotting: one percent bands (forplot.m)
percent = 0.9;

%% mspec_add
% try to incorporate graphing variables into forplot, group with other graphing variables
[nvar,varnames,graph_title,cum_for,popadj,varnames_YL,varnames_irfs,varnames_YL_4Q,varnames_YL_irfs,...
names_shocks,names_shocks_title,nl_shocks_title,shocksnames,cum_irf,vardec_varnames,shockcats,list,shockdec_color] = mspec_add(mspec,dataset);

if cum_flag
    cum_for(find(strcmp(varnames,'Output Growth'))) = 6;
    cum_for(find(strcmp(varnames,'GDP Deflator'))) = 6;
end

if auxFlag
    %% add specs for auxilary variables
    eval(['auxSpecs',num2str(mspec)]);
end

if any(mspec==[803 804 805 904])
    q_adj = 100; 
    plotList={'Forecast';'Shock Decomposition'};
else
    q_adj=400;
end

%% To plot 99 percent bands
if ~exist('onepctflag','var'), onepctflag = 0; end
if onepctflag
    onepctstr = '1pct'; 
else
    onepctstr = '';
end

%% Set end date for data (loaddata.m, forplot.m, plot_all.m)
if ~exist('dates','var')
    error('set dates');
end

if ~exist('mnobss','var'), mnobss = (dates - 2007)*4; end % use for graphs starting in 2007Q1 for DSGE system output.18
pnobss=psize;
plot_forward = 13; %plot_forward = 8;
%plot_forward = 25; %plot_forward = 8;
if auxFlag
    plot_forward = 17;
    if exist('bolUseFinals','var') && bolUseFinals == 1
        plot_forward = -1;
%         plot_forward = 17;
    end
end
future = plot_forward+4-round(1+4*(dates-floor(dates)));

if exist('shockdec_history','var') && shockdec_history==1
    Startdate = 1;
else
    Startdate= stime - mnobss;
end

Enddate =stime + future;

if full_hist
    counter_ahead = Enddate_forecastfile - 1;
else
    counter_ahead = (Enddate_forecastfile - Startdate);
end
    
%% Set start and end dates for X-axis 
% sirf different for each type of figure
% sirf needs to be created here so that means and bands have correct pre-allocated size 
% remove sirf from figspecs
sirf = (Startdate:stime+future); % Startdate and future are set in spec
sirf_shockdec = (Startdate:Enddate);
sirf_counter = (Startdate:Enddate);
sirf_shock_1 = (Startdate:stime); % further modified in plotNL

%% Configure the Metropolis Algorithm (number of simulations) (gibb.m, parforecast.m, forplot.m)
if ~exist('nblocks','var'), nblocks = 11; end
if ~exist('nsim','var'), nsim = 10000; end
if ~exist('nburn','var'), nburn = nsim; end % initial simulations to 'burn'
if ~exist('jstep','var'), jstep = 5; end  % decreasing jstep to make forecasts and bands smoother
nsimgibbs = 10;
ntimes = 5;
ROLL = 0;
SAVEALL = 1; % Save matrices of the state transition equation (T,R,C) and end-of-sample filtered state (S_T/T). Parameter draws are always saved. 

%% mspec_parameters; mspec_parameters_'mspec'(subspec,dataset);
eval(['[para,para_names,para_mask,para_fix,npara,polipar,polivalue,bounds] = mspec_parameters_',num2str(mspec),'(',num2str(subspec),',',num2str(dataset),');']); 


%% Name string variables
lmodel = ['m',num2str(mspec),num2str(subspec)];
lprior = [num2str(mprior),num2str(pf_mod)];
ds = num2str(10*dataset); 
if sflag==0;
    ssf='';
else
    ssf=num2str(sflag);
end

if parflag,                 parstr = 'par'; else parstr = ''; end
if pargibbflag,             pargibbstr = 'par'; else pargibbstr = ''; end
if parallelflag,            parallelstr = ['parallel',num2str(nMaxWorkers)]; else parallelstr = ''; end
if simple_forecast,         sf = '1'; else sf = ''; end

%% number of lags
nlags = 2;


%% End of Presample
%T0 = nlags; %%0
T0 = 0; % Set this to nlags unless you want no presample - then do 0.
Tend = 0; % End of Estimation Sample
