% OVERVIEW
% pathspec.m: Set general paths

% INPUT
% dat: data set

% OUTPUT 
% spath: general directory for saving binary files 
% gpath: general directory for saving figures

% IMPROVEMENTS TO BE MADE: 
% Input to include model specifications
% Simplify paths
% Output npath and rpath

% CHANGES
% 6/16/2011: Removed very old old commented out sections.

function [fpath,spath,gpath] = pathspec(dat,figdir)

TIN = './';

if isempty(regexp(figdir,'/')) && ~strcmp(figdir,'')
    figdir = [figdir,'/'];
end

switch dat
    case {700}
        fpath = strcat(TIN,'files/');
        spath = strcat(TIN,'save/');
        gpath = strcat(TIN,'graphs/',figdir);	

    otherwise
        disp('set up path!!!')
end