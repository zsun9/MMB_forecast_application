
function [mspecdesc,subspecdesc,pf_moddesc,dsdesc] = modDesc(mspec,subspec,pf_mod,dataset)

%% Mspec descriptions
mspecdesclist{803}='ADAPTED SMETS AND WOUTERS';
mspecdesclist{804}='803 w financial frictions';
mspecdesclist{805}='803 w time varying pistar,';
mspecdesclist{904}='804 with time varying pistar';

mspecdesc = char(mspecdesclist(mspec));

%% Subspec descriptions
subspecdesclist(9) = {'all shocks, indexation off'};

if isempty(subspec)
    subspecdesc = 'all shocks';
else
    subspecdesc = char(subspecdesclist(subspec));
end

%% pf_mod (priorfile modifaction) descriptions
% This is to allow us to set different prior files for the same model. It
% is currently being used to test the 83Q4 forecast. DF 8.17.08
pf_moddesclist{50}='FROM SW';
pf_moddesclist{52}='FROM SW - longif  added corrected lmean prior';
pf_moddesclist{54}='change st, zeta_sp';
pf_moddesclist{61}='FROM SW - longif';

pf_moddesc = char(pf_moddesclist(str2double(pf_mod)));

%% dataset descriptions
dsdesclist{700}='realtime vintage datasets';

dsdesc = dsdesclist(dataset);
