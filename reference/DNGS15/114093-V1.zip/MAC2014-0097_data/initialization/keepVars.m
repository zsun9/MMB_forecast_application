% OVERVIEW
% keepVars.m: Keep important variables in the workspace. This allows us to
%             loop over programs. 
%
% IMPORTANT VARIABLES
% keepList: a list of variables to keep

%% Important
keepList = {'overwrite'};

%% Model 
keepList = union(keepList,{'mspec','subspec','pf_mod','peachsm','dataset','dates','stime', ...
                            'altdata'});

%% Zerobound 
keepList = union(keepList,{'zerobound','nant','nant_implied','antlags'});

%% Parallel
keepList = union(keepList,{'parallelflag','parflag','distr','nMaxWorkers'});

%% Conditional 
keepList = union(keepList,{'peachfile','peachfileold'});

%% Forecasting 
keepList = union(keepList,{'simple_forecast','bdd_int_rate','peachflag','dsflag','jstep','save_states','qahead','nplotstates'});

%% Forplot
keepList = union(keepList,{'plot*','fancharts','fourq_flag','Q4Q4table','q_adj', 'vars_to_plot'});

%% Plotting 
keepList = union(keepList,{'useSavedMB','plotList'});

%% PLT
keepList = union(keepList,{'MODEstr','experiment_flag','useMode'});

%% Debugging
keepList = union(keepList,{'nsim','nblocks'});

%% Paths
keepList = union(keepList,{'spath','fpath','spath_overwrite','fpath_overwrite','gpath_overwrite'});

%% Aux variables
keepList = union(keepList,{'auxFlag','bolUseFinals','mnobss','shockdec_history','useRtParallelResults','saveSemiCondStShFlag',...
    'paramFile','paramSpecFile', 'replaceBlock','edate','sdate','h1','h2','h3','hairType','haircompare','swapKapSSS','rwMC','varName','list_scenario',...
    'sh_ind','st_ind','sh_cmp','st_cmp','nant2','gensys2','bol_detrend_w','bol_cond_mc','GR_dt','phillips_mc','cum_flag','ngdpflag','full_hist','figDir'});

%% Misc
% iter save_states iInput stime dates mnobss shockdec_history
% experiment_flag useMode MODEstr input
% irfStates vdec_states sd_states
% modeonly ssonly ShockremoveList

%% Realtime 
keepList = union(keepList,{'judge','qvint','ovint','sflag','r_exp','nantmax','antpolflag','mant','first','compound','paramDate'});

%% Alternate Gensys
keepList = union(keepList,{'gensys2', 'model2_num', 'add', 'mspec1', 'mspec2', 'infile0', 'param_555', 'param_556'});
    
eval(['keep ', sprintf(repmat('%s ',1,length(keepList)),keepList{:})]); 


	
    
