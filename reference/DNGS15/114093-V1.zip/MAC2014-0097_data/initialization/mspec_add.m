
function [nvar,varnames,graph_title,cum_for,popadj,varnames_YL,varnames_irfs,varnames_YL_4Q,varnames_YL_irfs,...
names_shocks,names_shocks_title,nl_shocks_title,shocksnames,cum_irf,vardec_varnames,shockcats,list,shockdec_color] = mspec_add(mspec,dataset)

%% Default Settings
nvar = 5;
varnames = {'Per Capita Output Growth';'Per Capita Hours Growth';'Labor Share';'Core PCE Inflation';'Interest Rate'};
graph_title = {'Output';'Labor_Supply';'Labor_Share';'Inflation';'Interest_Rate'};

cum_for =  [       1              2              3             1            0       ];
popadj =   [       1              1              0             0            0       ];

varnames_YL_4Q = {'Percent 4Q Growth';'Percent 4Q Growth';'Level';'Percent 4Q Growth';'Percent Annualized'};
varnames_YL = {'Percent Q-to-Q Annualized';'Percent Q-to-Q Annualized';'Level';'Percent Q-to-Q Annualized';'Percent Annualized'};
varnames_irfs = {'Per Capita Output Growth';'Per Capita Hours Growth';'Labor Share';'Core PCE Inflation';'Interest Rate'};
varnames_YL_irfs = {'Percent Annualized';'Percent Annualized';'Percent';'Percent Annualized';'Percent Annualized'};

names_shocks = {'TFP Shock';'\phi';'\mu';'b';'g';'\lambda_f';'Money'};
names_shocks_title = {'TFPShock';'phi';'mu';'b';'g';'lambda_f';'Money'};

nl_shocks_title = {'Technology';'phi';'Financial';'b';'g';'Mark-Up';'Monetary Policy'}; 
shocksnames=names_shocks';
cum_irf = [];
vardec_varnames = {'Per Capita Output Growth';'Per Capita Hours, Log Level';'Labor Share';'Core PCE Inflation';'Interest Rate'};

if popadj(1) == 1
    varnames(1) = {'Output Growth'};
    varnames_irfs(1) = {'Output Growth'};
    vardec_varnames(1) = {'Output Growth'};
end

if popadj(2) == 1
    varnames(2) = {'Aggregate Hours Growth'};
    varnames_irfs(2) = {'Aggregate Hours Growth'};
    vardec_varnames(2) = {'Aggregate Hours Growth'};
end

eval(['states',num2str(mspec)]);
    
%% Modifications for other mspecs
if any(mspec==[803 804 805 904]) 
    nvar = nvar+2;
    
    varnames(end+1:end+2) = {'Per Capita Consumption Growth';'Per Capita Investment Growth'};
    graph_title(end+1:end+2) = {'Consumption';'Investment'};
    graph_title(4)={'GDP_Deflator'};
    cum_for(end+1:end+2) =  [1	1];
    popadj(1:2) = [1 1 ];
    popadj(end+1:end+2) =   [1	1];
    %varnames(1) = {'Per Capita Output Growth'};
    varnames_YL(3)={'Levels'};
    varnames_YL(end+1:end+2) = {'Percent Q-to-Q Annualized';'Percent Q-to-Q Annualized'};
    varnames_irfs(end+1:end+2) = {'Per Capita Consumption Growth';'Per Capita Investment Growth'};
    % varnames_YL_irfs(end+1:end+2) = {'Percent Q-to-Q Annualized';'Percent Q-to-Q Annualized'};
    varnames_YL_irfs(end+1:end+2) = {'Percent Annualized';'Percent Annualized'};
    vardec_varnames(end+1:end+2) = {'Per Capita Consumption Growth';'Per Capita Investment Growth';};
    if any(mspec==[700 701 702 801 802 803 821 822 823 824 8241 825 826 835 836 8351 8361 8352 8362 827 828 8281:8284 8285 8286 8287 829 830 330 332 804 809 900:908 305 303 805 815 816 8051])
        varnames(3:4) = {'Real Wage Growth';'GDP Deflator'}; %replace 'Labor Share' with 'Wage growth', core pce with gdp deflator
        varnames_YL(3)={'Percent Q-to-Q Annualized'};
        varnames_YL_4Q(3) = {'Percent 4Q Growth'};
        varnames_irfs(3) = {'Real Wage Growth'};
        varnames_YL_irfs(3) = {'Percent Annualized'};
        cum_for(3)  = 1;
        %popadj=zeros(size(popadj));
    end
    if popadj(6) == 1
        varnames(6) = {'Consumption Growth'};
        varnames_irfs(6) = {'Consumption Growth'};
        vardec_varnames(6) = {'Consumption Growth'};
    end
    if popadj(7) == 1
        varnames(7) = {'Investment Growth'};
        varnames_irfs(7) = {'Investment Growth'};
        vardec_varnames(7) = {'Investment Growth'};
    end
    
    if any(mspec==[803]); %removed 823,826
       
        shockcats = {g_sh; b_sh; mu_sh; z_sh; laf_sh; law_sh;  rm_sh; 0};

        %list = {'neutral tech','investment tech', ...
               % 'Policy','Mark-Up','Wage Mark Up','Gov''t','asset','Det. Trend'};
        list = {'g','b','\mu','z','\lambda_f','\lambda_w','r_m','dt'};
        shockdec_color = {'firebrick',[0.3,0.3,1],'darkorange','yellowgreen','gold','indigo','teal','gray'};          % Deterministic Trend
        names_shocks = {'g';'b';'\mu';'z';'\lambda_f';'\lambda_w';'r_m'};
        %names_shocks_title = {'g','b','mu','z','lambda_f','lambda_w','rm'};
        names_shocks_title={'govt';'asset';'inv_tech';'neutral_tech';'price_mkp';'wage_mkp';'Money'};
        graph_title{3}='Real_Wage';
        
        %cum_for(end+1)=0;
    end
    
    if any(mspec==[805]);
        names_shocks = {'g';'b';'\mu';'z';'\lambda_f';'\lambda_w';'r_m';'\pi_*'};
        %names_shocks_title = {'g','b','mu','z','lambda_f','lambda_w','rm','pistar'};
        names_shocks_title={'govt';'asset';'inv_tech';'neutral_tech';'price_mkp';'wage_mkp';'Money';'pist'};
        shockcats = {g_sh; b_sh; mu_sh; z_sh; laf_sh; law_sh;  rm_sh; pist_sh};
        list = {'g','b','\mu','z','\lambda_f','\lambda_w','r_m','\pi^*'};
        shockdec_color = {'firebrick',[0.3,0.3,1],'darkorange','yellowgreen','gold','indigo','teal','pink'};          % Deterministic Trend
        cum_for(end+1)=1;
        popadj(end+1)=0;
        varnames{end+1} = 'Long Inf';
        varnames_YL{end+1} = 'Level';
        graph_title{end+1} = 'Long_Inf';
        varnames_irfs{end+1} = 'Long Inf';
        varnames_YL_irfs{end+1} = 'Percent Annualized';
        nvar=8;
        graph_title{3}='Real_Wage';
        if mspec==305;
            names_shocks{end+1}='\gamma';
            names_shocks_title = 'gamma';
            shockcats{end} = gamm_sh;
            shockdec_color{end+1} = 'green';
            cum_for(end+1)=1;
            popadj(end+1)=0;
            list{end} = '\gamma';
        end
        shocksnames = names_shocks';
        shockcats{end+1} = 0;
        list{end+1} = 'dt';
        shockdec_color{end+1} = 'gray';
    end
    

    if any(mspec==[804 904])
        nvar=8;
        varnames(end+1) = {'Spread'};
        graph_title(end+1) = {'Spread'};
        varnames_YL(end+1) = {'Level'};
        varnames_irfs(end+1) = {'Spread'};
        varnames_YL_irfs(end+1) = {'Percent Annualized'};
        vardec_varnames{3} = {'Real Wage'};
        graph_title{3}='Real_Wage';
        shockcats = {g_sh; b_sh; mu_sh; z_sh; laf_sh; law_sh;  rm_sh; sigw_sh};

        list = {'g','b','\mu','z','\lambda_f','\lambda_w','r_m','\sigma_w'};
        shockdec_color = {'firebrick',[0.3,0.3,1],'darkorange','yellowgreen','gold','indigo','teal','green'}; 
        %names_shocks = {'Gov';'b';'mu';'z';'lam_f';'lam_w';'Money';'spread';'mue';'gamm'}; % should follow order of shocks in QQ (measur<mspec>.m)
        names_shocks = {'g';'b';'\mu';'z';'\lambda_f';'\lambda_w';'r_m';'\sigma_w';'\mu_e';'\gamma'};
        %names_shocks_title = {'Gov';'b';'mu';'z';'lam_f';'lam_w';'policy';'spread';'mue';'gamm'}; % should follow order of shocks in QQ (measur<mspec>.m)
        names_shocks_title={'govt';'asset';'inv_tech';'neutral_tech';'price_mkp';'wage_mkp';'Money';'spread';'mue';'gamma'};
        cum_for(end+1)=1;
        popadj(end+1)=0;
        if any(mspec==[904])
            names_shocks{end+1}='\pi_*';
            names_shocks_title{end+1} = 'pistar';
            %%% Comment out top three lines to break up shocks, comment out
            %%% bottom three to group shocks
            shockcats = {g_sh;b_sh;[ gamm_sh mue_sh sigw_sh]; z_sh; laf_sh; law_sh;  rm_sh};
            list = {'g','b','FF','z','p-mrkup','w-mrkup','pol.'};
            shockdec_color = {'firebrick',[0.3,0.3,1],'indigo','darkorange','yellowgreen','teal','gold'};
%             shockcats = {[g_sh b_sh mu_sh gamm_sh sigw_sh pist_sh law_sh]; z_sh; laf_sh;  rm_sh};
%             list = {'other';'z';'markup';'policy'};
%             shockdec_color = {'firebrick','darkorange';'yellowgreen','gold'};
            list{end+1}='pi-LR';
            shockcats{end+1} = pist_sh;
            shockdec_color{end+1} = 'pink';
            %%%
            cum_for(end+1)=1;
            popadj(end+1)=0;
            nvar=nvar+1;
            varnames{nvar}='Long Inf';
            graph_title{nvar}='Long_Inf';
            varnames_YL{nvar} = 'Level';
            graph_title{nvar} = 'Long_Inf';
            varnames_irfs{nvar} = 'Long Inf';
            varnames_YL_irfs{nvar} = 'Percent Annualized';
        end
        shocksnames = names_shocks';
        %%% Comment out when grouping shocks. Otherwise leave as is
%        shockcats = {};
%        list = {};
%        shockdec_color= {};
        shockcats{end+1} = mu_sh;
        list{end+1} = 'mu';
        shockdec_color{end+1} = 'cyan';
        
        shockcats{end+1} = 0;
        list{end+1} = 'dt';
        shockdec_color{end+1} = 'gray';

    end      
    shocksnames=names_shocks'; 

end
