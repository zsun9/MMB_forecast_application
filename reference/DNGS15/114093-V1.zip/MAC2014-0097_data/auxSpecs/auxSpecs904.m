%% auxilary specs
nvar = nvar+9;

cum_for(end+1:end+9) = [5 5 5 5 5 5 5 5 5];
popadj(end+1:end+9) = [0 0 0 0 0 0 0 0 0];
varnames(end+1:end+9) = {'Return on Capital'; 'Marginal Cost'; 'Real Wage'; 'Output Gap';'S^{\infty}_t';'\kappa (1+\iota_p\bar{\beta}) S^{\infty}_t';'entrepreneur net worth';'\pi^* + \pi^*_t';'leverage'};%'5yr inf. exp.'};%'\kappa (1+\iota_p\bar{\beta}) S^{\infty}_t+\iota_p \hat{\pi}_{t-1}';'\kappa S^{\infty}_t+\iota_p \hat{\pi}_{t-1}'};%'Return on Capital'};
graph_title(end+1:end+9) = {'Return_on_Capital'; 'Marginal_Cost'; 'Real_Wage_Level'; 'Output_Gap';'St';'kSt';'entrepreneur_net_worth';'pist+pist_t';'leverage'};%'5yr_inf_exp'};%'kSt+ipi_t1';'kSt+ipi_t1'};%'Return_on_Capital'};
varnames_YL(end+1:end+9) = {'','','','','','','','',''};
varnames_irfs(end+1:end+9) = {'Return on Capital'; 'Marginal Cost'; 'Real Wage'; 'Output Gap';'S^{\infty}_t';'\kappa (1+\iota_p\bar{\beta}) S^{\infty}_t';'entrepreneur net worth';'\pi^* + \pi^*_t';'leverage'};%'5yr inf. exp.'};%'\kappa (1+\iota_p\bar{\beta}) S^{\infty}_t+\iota_p \hat{\pi}_{t-1}';'\kappa S^{\infty}_t+\iota_p \hat{\pi}_{t-1}'};%'Return on Capital'};
varnames_YL_irfs(end+1:end+9) = {'','','','','','','','',''};