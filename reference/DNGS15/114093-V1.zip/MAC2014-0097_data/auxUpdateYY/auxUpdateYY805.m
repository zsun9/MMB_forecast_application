function [YYNew,stateFinals,auxCount] = auxUpdateYY805(YY,vintend,mspec,nlags,nstate,para,paraAlt,varargin)

global rwMC;

[~,spath,~] = pathspec(dataset,'');
fid = fopen([spath,spec_file],'r');
   
   %% Parameters
   [alp,zeta_p,iota_p,del,ups,Bigphi,s2,h,ppsi,nu_l,zeta_w,iota_w,law,laf,bet,Rstarn,psi1,psi2,psi3,pistar,sigmac,rho,epsp,epsw...
    gam,Lmean,Lstar,gstar,rho_g,rho_b,rho_mu,rho_z,rho_laf,rho_law,rho_rm,rho_pist...
    sig_g,sig_b,sig_mu,sig_z,sig_laf,sig_law,sig_rm,sig_pist,eta_gz,eta_laf,eta_law...
    zstar,rstar,rkstar,wstar,wl_c,cstar,kstar,kbarstar,istar,ystar,pistflag] = getpara00_805(para);
   
   [TTT,RRR,CCC,valid_a] = dsgesolv(para,mspec);
   
   
   K = -1; % Set to -1 for infinite expectational horizon (MUST MATCH K in auxMeasure904.m)
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
   % for psi swap
   %     tmp = para;
   %     para = paraAlt;
   %     paraAlt = tmp;
   
   % for other experiments
   %    kappaBar = getKappa( paraAlt, mspec );
   %    [SSS, bbar]   = getSSS( para, mspec, K, 'spec_803_aux', zb );
   
   % for experiment where we calculate states with 803 and Sinf with SW
   kappaBar = getKappa( para, mspec );
   [SSS, bbar]   = getSSS( paraAlt, mspec, K, 'spec_805_aux' );
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
   auxCount = 8;
                 
   tempStates = fread(fid,'single');
   
   eval(['states',num2str(mspec)]);
   
   pi_t1 = n_end+n_exo+n_exp+5;
   
   I=size(YY,1);
   
   XX = reshape(tempStates,I,size(tempStates,1)/I)';
   
   % Use data-constructed or model implied labor share
   %  YY(1:I, end-3) = tempStates(1+(w_t-1)*I:w_t*I,1) + tempStates(1+(L_t-1)*I:L_t*I,1) - tempStates(1+(y_t-1)*I:y_t*I,1);
   %  YY(1:I, end-3) = vintend.series(1+nlags:nlags+I,end-3);
   
   YY(1:I, end-7) = tempStates(1+(rk_t-1)*I:rk_t*I,1); % rk
   YY(1:I, end-6) = tempStates(1+(mc_t-1)*I:mc_t*I,1); % mc
   YY(1:I, end-5) = tempStates(1+(w_t-1)*I:w_t*I,1); % w
   YY(1:I, end-4) = tempStates(1+(y_t-1)*I:y_t*I,1)-tempStates(1+(y_f_t-1)*I:y_f_t*I,1); % ygap
   YY(1:I, end-3) = SSS(mc_t,:)*XX; % S_t
   YY(1:I, end-2) = kappaBar*(1+iota_p*bbar)*YY(1:I,end-3); % k*S_t
   YY(1:I, end-1) = YY(1:I, end-2) + iota_p*tempStates(1+(pi_t1-1)*I:pi_t1*I,1);
   YY(1:I, end)   = 100*(pistar-1) + tempStates(1+(pist_t-1)*I:pist_t*I,1); % pi*+pi*_t
   
   YYNew=YY;
   
   %% CONTRUCT FINALS FROM SMOOTHED STATES USING FULL DATA SAMPLE
   
   fid1 = fopen('states/statesm805926170001201250201Mode','r');
   
   tempStates1 = fread(fid1,'single');
   
   I = size(tempStates1,1)/(nstate);
   
   XX1 = reshape(tempStates1,I,nstate)';
   
   stateFinals = nan(I,size(YY,2));
   
   stateFinals(1:I, end-7) = tempStates1(1+(rk_t-1)*I:rk_t*I,1); % rk
   stateFinals(1:I, end-6) = tempStates1(1+(mc_t-1)*I:mc_t*I,1); % mc
   stateFinals(1:I, end-5) = tempStates1(1+(w_t-1)*I:w_t*I,1); % w
   stateFinals(1:I, end-4) = tempStates1(1+(y_t-1)*I:y_t*I,1)-tempStates1(1+(y_f_t-1)*I:y_f_t*I,1); % ygap
   stateFinals(1:I, end-3) = SSS(mc_t,:)*XX1; % S_t
   stateFinals(1:I, end-2) = kappaBar*(1+iota_p*bbar)*stateFinals(1:I, end-3); % k*S_t
   stateFinals(1:I, end-1) = stateFinals(1:I, end-2) + iota_p*tempStates1(1+(pi_t1-1)*I:pi_t1*I,1);
   stateFinals(1:I, end)   = 100*(pistar-1) + tempStates1(1+(pist_t-1)*I:pist_t*I); % pi*+pi*_t - tempStates(1+(y_t-1)*I:y_t*I,1);