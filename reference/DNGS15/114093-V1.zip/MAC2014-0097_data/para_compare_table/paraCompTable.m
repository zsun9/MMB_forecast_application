spec_904_aux;
spec_realtime;
initializePrograms;
parstr = 'Mode';
nsim = 1;
infile.mhpara = [spath,'mhpara',lmodel,lprior,ds,num2str(100*paramDate),num2str(nlags),num2str(T0),pargibbstr,parstr];
fid.mhpara = fopen(infile.mhpara);
theta904 = fread(fid.mhpara,[npara,nsim],'single')';
paraNames904 = para_names;

keep theta904 paraNames904;

spec_805_aux;
spec_realtime;
initializePrograms;
parstr = 'Mode';
nsim = 1;
infile.mhpara = [spath,'mhpara',lmodel,lprior,ds,num2str(100*paramDate),num2str(nlags),num2str(T0),pargibbstr,parstr];
fid.mhpara = fopen(infile.mhpara);
theta805 = fread(fid.mhpara,[npara,nsim],'single')';
paraNames805 = para_names;

keep theta904 paraNames904 theta805 paraNames805;

spec_804_aux;
spec_realtime;
initializePrograms;
parstr = 'Mode';
nsim = 1;
infile.mhpara = [spath,'mhpara',lmodel,lprior,ds,num2str(100*paramDate),num2str(nlags),num2str(T0),pargibbstr,parstr];
fid.mhpara = fopen(infile.mhpara);
theta804 = fread(fid.mhpara,[npara,nsim],'single')';
paraNames804 = para_names;

keep theta904 paraNames904 theta805 paraNames805 theta804 paraNames804;

spec_803_aux;
spec_realtime;
initializePrograms;
parstr = 'Mode';
nsim = 1;
infile.mhpara = [spath,'mhpara',lmodel,lprior,ds,num2str(100*paramDate),num2str(nlags),num2str(T0),pargibbstr,parstr];
fid.mhpara = fopen(infile.mhpara);
theta803 = fread(fid.mhpara,[npara,nsim],'single')';
paraNames803 = para_names;

keep spath theta904 paraNames904 theta805 paraNames805 theta804 paraNames804 theta803 paraNames803;

fid = fopen([spath,'smetsAndWouters2007ParaMode']);
thetaSW = fread(fid,'single')';

keep theta904 paraNames904 theta805 thetaSW paraNames805 theta804 paraNames804 theta803 paraNames803 paraNamesSW;


fid = fopen('para_compare_table/paraTable_904_805_804_803_SW.tex','w');

fprintf(fid,'\\begin{figure}[h!]\n');
fprintf(fid,'\\begin{center}\n');
fprintf(fid,'\\begin{tabular}{l c c c c r}\n');
fprintf(fid,'\\toprule\n');
fprintf(fid,'Parameter & & & Posterior Mode & &  \\\\ \n');
fprintf(fid,'& SW+FF+infExp & SW+infExp & SW+FF & SW & SW[07]\\\\ \n');
fprintf(fid,'\\cline{2-6}\n');

for i = 1:length(paraNames904)
    ind805 = find(strcmp(paraNames805,paraNames904(i)),1);
    if isempty(ind805); empty805=1; para805='.'; else; empty805=0; para805 = theta805(ind805); end
    
    ind804 = find(strcmp(paraNames804,paraNames904(i)),1);
    if isempty(ind804); empty804=1; para804='.'; else; empty804=0; para804 = theta804(ind804); end
    
    ind803 = find(strcmp(paraNames803,paraNames904(i)),1);
    if isempty(ind803); empty803=1; para803 = '.'; paraSW = '.';...
    else; empty803=0; para803 = theta803(ind803); paraSW = thetaSW(ind803); end
    
    if empty805
        if empty803
            if empty804
                line = ['$',strrep(paraNames904{i},'\','\\'),'$','& %f & %s & %s & %s & %s \\\\ \n'];
            else
                line = ['$',strrep(paraNames904{i},'\','\\'),'$','& %f & %s & %f & %s & %s \\\\ \n'];
            end
        else
            if empty804
                line = ['$',strrep(paraNames904{i},'\','\\'),'$','& %f & %s & %s & %f & %f \\\\ \n'];
            else
                line = ['$',strrep(paraNames904{i},'\','\\'),'$','& %f & %s & %f & %f & %f \\\\ \n'];
            end
        end
    else
        if empty803
            if empty804
                line = ['$',strrep(paraNames904{i},'\','\\'),'$','& %f & %f & %s & %s & %s \\\\ \n'];
            else
                line = ['$',strrep(paraNames904{i},'\','\\'),'$','& %f & %f & %f & %s & %s \\\\ \n'];
            end
        else
            if empty804
                line = ['$',strrep(paraNames904{i},'\','\\'),'$','& %f & %f & %s & %f & %f \\\\ \n'];
            else
                line = ['$',strrep(paraNames904{i},'\','\\'),'$','& %f & %f & %f & %f & %f \\\\ \n'];
            end
        end
    end
    
    fprintf(fid,line,theta904(i),para805,para804,para803,paraSW);
    
    if i == 24
        fprintf(fid,'\\bottomrule\n');
        fprintf(fid,'\\end{tabular}\n');
        fprintf(fid,'\\end{center}\n');
        fprintf(fid,'\\end{figure}\n');
        
        fprintf(fid,'\\begin{figure}[h!]\n');
        fprintf(fid,'\\begin{center}\n');
        fprintf(fid,'\\begin{tabular}{l c c c c r}\n');
        fprintf(fid,'\\toprule\n');
        fprintf(fid,'Parameter & & & Posterior Mode & & \\\\ \n');
        fprintf(fid,'& SW+FF+infExp & SW+infExp & SW+FF & SW & SW[07] \\\\ \n');
        fprintf(fid,'\\cline{2-6}\n');
    end
    
end

fprintf(fid,'\\bottomrule\n');
fprintf(fid,'\\end{tabular}\n');
fprintf(fid,'\\end{center}\n');
fprintf(fid,'\\end{figure}\n');
fclose(fid);
    



