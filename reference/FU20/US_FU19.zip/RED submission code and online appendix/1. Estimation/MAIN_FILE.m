
clc 
clear all

dynare usmodel1984_2007.mod
save('usmodel1984_2007')



%% 
dynare usmodel1948_2007.mod
save('usmodel1948_2007')

dynare usmodel1984_2015.mod
save('usmodel1984_2015')

%% 


dynare usmodel1984_2007inflTarg
save('usmodel1984_2007inflTarg') 



%% 


dynare usmodel1984_2007inflTarg2
save('usmodel1984_2007inflTarg2') 




%% there was a problem with the mean.mat files. Dynare would not run the MOD file unless there are the 
% parameter names, but also Dynare would not store them automatically. So,
% I am taking them from the mode files and storing them in the mean
% files. 

clear all 

load('usmodel1984_2007_mode.mat')
clear hh xparam1 

load('usmodel1984_2007_mean.mat')
save('STORERESULTS/usmodel1984_2007_mean.mat')

clear all 

load('usmodel1948_2007_mode.mat')
clear hh xparam1 

load('usmodel1948_2007_mean.mat')
save('STORERESULTS/usmodel1948_2007_mean.mat')


clear all 

load('usmodel1984_2015_mode.mat')
clear hh xparam1 

load('usmodel1984_2015_mean.mat')
save('STORERESULTS/usmodel1984_2015_mean.mat')


%%

clear all 

load('usmodel1984_2007inflTarg_mode.mat')
clear hh xparam1 

load('usmodel1984_2007inflTarg_mean.mat')
save('STORERESULTS/usmodel1984_2007inflTarg_mean.mat')



clear all 

load('usmodel1984_2007inflTarg2_mode.mat')
clear hh xparam1 

load('usmodel1984_2007inflTarg2_mean.mat')
save('STORERESULTS/usmodel1984_2007inflTarg2_mean.mat')

