% uncomment a location below -- adapt to local installation

% location = 'home_matteo';
% location = 'home_luca';
% location = 'work_matteo';
location = 'chiara' ; 

restoredefaultpath

if strmatch(location,'chiara','exact')  
    dir1='C:\dynare\4.5.7\matlab';
    dir2='C:\ZLB\toolkit_files';
    dir3='C:\ZLB\toolkit_files_private';    
else 
    error('Specify path to Dynare installation')
end

path(dir1,path);
path(dir2,path);
path(dir3,path);


dynare_config

