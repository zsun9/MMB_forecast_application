


clear
close all
clear all 
clc
set(0,'DefaultLineLineWidth',2)

% NEED TO RUN FIRST setpathdynare442 


%---------------------------------------------------------------------
% To compute multipliers at ZLB, solve two models
% simulation 1 is baseline  that takes us at the ZLB
% simulation 2 is baseline simulation that takes us at the ZLB plus G shock
%---------------------------------------------------------------------



nperiods=30;
maxiter=10000;

% Pick color of charts
solution=1;

irfshock = char('eps_c','eps_shadow'); 

scenario1=[  0  -0.05  0    -0.00   0   0
  0.00  0.00   0.00    0.00     0.00    0.00  ]';


scenario2=[ 0     0      0       0        0       0
    0.0 -0.7  -0.0     0.0      0.00    0 ]';

%scenario2=[ 0     0      0       0        0       0
 %  0.00  0.00   0.00    0.00      0.00    -0.0   ]';


modnam = 'dnk';
modnamstar = 'dnk_zlb';



BETA = 0.9925 ;

%constraint = 'r<-(1/BETA-1)';
%constraint_relax ='rnot>-(1/BETA-1)';

constraint = 'r <-(1/BETA-1)';
constraint_relax ='rnot >-(1/BETA-1)';


% Only ZLB
[zdatascenario_lin1 zdatascenario_pie1 zdatass oobase_ Mbase_] = ...
  solve_one_constraint(modnam,modnamstar,...
  constraint, constraint_relax,...
  scenario1,irfshock,nperiods,maxiter);


% ZLB + FWDG
[zdatascenario_lin2 zdatascenario_pie2 zdatass oobase_ Mbase_ ] = ...
  solve_one_constraint(modnam,modnamstar,...
  constraint, constraint_relax,...
  scenario1+scenario2,irfshock,nperiods,maxiter);





% Note that we compute impulse responses in deviation from baseline
% In simulation=1, scenario1 has a no negative preference shock
% In simulation=2, baseline2 has a negative preference shock that takes economy to ZLB
for i=1:Mbase_.endo_nbr
  
  eval([deblank(Mbase_.endo_names(i,:)),'1 = zdatascenario_pie1(:,i);']);
  eval([deblank(Mbase_.endo_names(i,:)),'2 = zdatascenario_pie2(:,i);']);
end

line1=100*[xp1,4*r1,dp1, 4*rnot1 , a_c1,a_shadow1 ];
line2=100*[xp2,4*r2,dp2, 4*rnot2 , a_c2,a_shadow2 ];
  



 


%%




x = zeros(Mbase_.npred, 31) ; 
y = zeros(Mbase_.endo_nbr, 31); 
eps = zeros(Mbase_.exo_nbr, 31) ; 

eps(1, 2:7) = scenario1(:,1) ; 

  % Monetary policy shock (also shadow shock ) 
% NB: if you modify this, please modify it in the paramfile_dnk.m as well! 
  

LB = -(1/BETA-1) ; 

shadow_shock = zeros(30,1) ; 





A=[];
B=[];
C=[];
D=[];



%get state indices
ipred = Mbase_.nstatic+(1:Mbase_.nspred)';
%get state transition matrices
[A,B] = kalman_transition_matrix(oobase_.dr,ipred,1:Mbase_.nspred,Mbase_.exo_nbr);
%get observable position in decision rules
obs_var=oobase_.dr.inv_order_var([5, 6, 7]); % these umbers are the state variables in the declaration order
%get observation equation matrices
[C,D] = kalman_transition_matrix(oobase_.dr,obs_var,1:Mbase_.nspred,Mbase_.exo_nbr);
%compute condition


x = zeros(Mbase_.npred, 31) ; 
y = zeros(Mbase_.endo_nbr, 31); 
eps = zeros(Mbase_.exo_nbr, 31) ; 

eps(1, 2:7) = scenario1(:,1) ; 

id = zeros(1,30) ; 


for i=2:31 
 
x(:,i)=A*x(:,i-1) +B*eps(:,i) ; 
   
   int_rate(i) = oobase_.dr.ghx( oobase_.dr.inv_order_var(3),:)*x(:,i-1) +  oobase_.dr.ghu( oobase_.dr.inv_order_var(3),:)*eps(:,i) ; 
   
   
   if int_rate(i)  <= -(1/BETA-1)
       id(i) = 1 ; 
    eps(3,i) =  (-(1/BETA-1) - int_rate(i) )/oobase_.dr.ghu( oobase_.dr.inv_order_var(4),3) ; 
   end
   
   
   
   y(:,i) = oobase_.dr.ghx*x(:,i-1) +  oobase_.dr.ghu*eps(:,i) ; 

end


y3 = y(oobase_.dr.inv_order_var(2),2:31)'; 
r3 = y(oobase_.dr.inv_order_var(4),2:31)' ; 
dp3 = y(oobase_.dr.inv_order_var(1),2:31)' ; 
rnot3 = y(oobase_.dr.inv_order_var(3),2:31)' ;
a_c3 = y(oobase_.dr.inv_order_var(5),2:31)' ; 
a_z3 = y(oobase_.dr.inv_order_var(6),2:31)' ;  

titlelist = char('Output','Interest rate','Inflation','Taylor implied int rate','shock to preferences','shadow- and monet. shock');

ylabels = char('percent deviation from baseline',...
  '% of GDP, deviation from baseline',...
  'ppoints deviation from baseline, annualized',...
  'percent deviation from baseline',...
  'percent deviation from baseline',...
  'percent deviation from baseline');

figtitle = '';
line3=100*[y3,4*r3,dp3,4*rnot3,a_c3,a_z3];
  
legendlist = cellstr(char('ZLB','ZLB+FWD G'));
figlabel = '';
makechart(titlelist,'',figlabel,ylabels,line1,line2,line3 )
%makechart(titlelist,'',figlabel,ylabels,line1,line2)

saveas(gcf,'IRF_ZLG_FWDG2','pdf')
saveas(gcf,'IRF_ZLG_FWDG2.eps','epsc')
