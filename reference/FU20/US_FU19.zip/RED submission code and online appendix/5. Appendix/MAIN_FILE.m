clc 
clear all



%% 

dynare usmodel1984_2007inflTarg2

save ('usmodel1984_2007inflTarg2')

%% 

dynare usmodel_decomposition4807_1948_2015

save ('usmodel_decomposition4807_1948_2015') 

%% Table B1: Summary statistics 
load usmodel_data2015.mat
label = [1948.25:0.25:2015.0];

endyear = 2015; 


f = 10.^2 ; 

Table_B1 = [ (round(f*mean(dc(144:239) ))/f)    (round(f*std(dc(144:239) ))/f)     (round(f*mean(dc(240:end) ))/f)    (round(f*std(dc(240:end) ))/f )  ; ...
             (round(f*mean(dinve(144:239) ))/f)    (round(f*std(dinve(144:239) ))/f)      (round(f*mean(dinve(240:end) ))/f)    (round(f*std(dinve(240:end) ))/f)    ; ...
             (round(f*mean(dy(144:239) ))/f)  , (round(f*std(dy(144:239) ))/f)    , (round(f*mean(dy(240:end) ))/f)  , (round(f*std(dy(240:end) ))/f)  ; ... 
                (round(f*mean(labobs(144:239) ))/f)  , (round(f*std(labobs(144:239) ))/f)    , (round(f*mean(labobs(240:end) ))/f)  , (round(f*std(labobs(240:end) ))/f)  ; 
   (round(f*mean(pinfobs(144:239) ))/f)  , (round(f*std(pinfobs(144:239) ))/f)    , (round(f*mean(pinfobs(240:end) ))/f)  , (round(f*std(pinfobs(240:end) ))/f)  ; 
  (round(f*mean(dw(144:239) ))/f)  , (round(f*std(dw(144:239) ))/f)    , (round(f*mean(dw(240:end) ))/f)  , (round(f*std(dw(240:end) ))/f)  ; 
  (round(f*mean(robs(144:239) ))/f)  , (round(f*std(robs(144:239) ))/f)    , (round(f*mean(robs(240:end) ))/f)  , (round(f*std(robs(240:end) ))/f) ]  ; 
    
aux = ["consumption"; "investment"; "output"; "labor"; "inflation"; "wage rate"; "interest rate"] ; 
Table_B1 = string(Table_B1) ; 

Table_B1 = [aux, Table_B1] ; 

save('Table_B1.mat','Table_B1' ) ; 



%% Figures B1 to B7

close all

plot(label(144:end),pinfobs(144:end)*4) %ANNUALIZED INFLATION
xtick = get(gca, 'XTick');
xtick(end-2) = 2004;    % PAY ATTENTsION TO THIS POINT NEXT TIME YOU UPDATE THE TIME SERIES AND ADD DATA POINTS! 
set(gca, 'XTick', xtick);
gline = line([2004.0 2004.0], [ -1 5]); %ANNUALIZED INFLATION
axis([1984 endyear -1 5]); %ANNUALIZED INFLATION
set (gline, 'color',[0,0,0]+0.3);
saveas(gcf,'inflation.epsc') 


plot(label(144:end),labobs(144:end))
xtick = get(gca, 'XTick');
xtick(end-2) = 2004;
set(gca, 'XTick', xtick);
gline = line([2004.0 2004.0], [-10 8]); 
axis([1984 endyear -10 8]); 
set (gline, 'color',[0,0,0]+0.3);
saveas(gcf,'labor.epsc') 


plot(label(144:end),dc(144:end))
xtick = get(gca, 'XTick');
xtick(end-2) = 2004;
set(gca, 'XTick', xtick);
gline = line([2004.0 2004.0], [-3.5 3]);
axis([1984 2013 -3.5 3]);
set (gline, 'color',[0,0,0]+0.3);
saveas(gcf,'consumption.epsc') 

plot(label(144:end),dinve(144:end))
xtick = get(gca, 'XTick');
xtick(end-2) = 2004;
set(gca, 'XTick', xtick);
gline = line([2004.0 2004.0], [-10 4.5]);
axis([1984 endyear -10 4.5]);
set (gline, 'color',[0,0,0]+0.3);
saveas(gcf,'investment.epsc') 

plot(label(144:end),dy(144:end))
xtick = get(gca, 'XTick');
xtick(end-2) = 2004;
set(gca, 'XTick', xtick);
gline = line([2004.0 2004.0], [-3 2.4]);
axis([1984 endyear -3 2.4]);
set (gline, 'color',[0,0,0]+0.3);
saveas(gcf,'output.epsc')

plot(label(144:end),dw(144:end))
xtick = get(gca, 'XTick');
xtick(end-2) = 2004;
set(gca, 'XTick', xtick);
gline = line([2004.0 2004.0], [-4 4]);
axis([1984 endyear -4 4]); 
set (gline, 'color',[0,0,0]+0.3);
saveas(gcf,'wagerate.epsc')

plot(label(144:end),robs(144:end))
xtick = get(gca, 'XTick');
xtick(end-2) = 2004;
set(gca, 'XTick', xtick);
gline = line([2004.0 2004.0], [0 4.5]);
axis([1984 endyear 0 4.5]);
set (gline, 'color',[0,0,0]+0.3);
saveas(gcf,'intrate.epsc')

%% Table D2 
clear all
clc

% this file can be created in Estimation folder 
load('usmodel1984_2007')

f = 10.^2; 

posterior_mean_param1984_2007 =  round(f.*oo_.posterior.metropolis.mean)./f; 
posterior_mean_std1984_2007 = round(f.*sqrt(diag(oo_.posterior.metropolis.Variance)))./f;




save('TABLE_D2.mat', 'posterior_mean_param1984_2007', 'posterior_mean_std1984_2007');




%% Table E3 and E4

clear all
clc

% this was generated in folder "main tables and figures" 
load('VD_results_inflation.mat', 'VD', 'VDpre', 'VDpre2','VDpost')

TABLE_E3 = [VD(:,200) , VDpre(:,200) ,VDpre2(:,200) , VDpost(:,200) ]; 

% this was generated in folder "main tables and figures" 
load('VD_results_employment.mat', 'VD', 'VDpre', 'VDpre2','VDpost')

TABLE_E4 = [VD(:,200) , VDpre(:,200) ,VDpre2(:,200) , VDpost(:,200) ]; 

save('TABLE_E3.mat' , 'TABLE_E3' );
save('TABLE_E4.mat' , 'TABLE_E4' );


%% Figure E9
close all
clear all

label = [1948.25:0.25:2015];
endyear = 2015 ; 

% This file has been created in folder Main figures and tables
load usmodel2015_decomposition_1948_2015 



epscilon = zeros(7,options_.nobs);
    epscilon(1, 2:options_.nobs) = oo_.SmoothedShocks.eZ(2:options_.nobs)';
    epscilon(2, 2:options_.nobs) = oo_.SmoothedShocks.ep(2:options_.nobs)';
    epscilon(3, 2:options_.nobs) = oo_.SmoothedShocks.ew(2:options_.nobs)';
    epscilon(4, 2:options_.nobs) = oo_.SmoothedShocks.eb2(2:options_.nobs)';
    epscilon(5, 2:options_.nobs) = oo_.SmoothedShocks.emu(2:options_.nobs)';
    epscilon(6, 2:options_.nobs) = oo_.SmoothedShocks.eg(2:options_.nobs)';
    epscilon(7, 2:options_.nobs) = oo_.SmoothedShocks.ems(2:options_.nobs)';

    
    
figure()

subplot(2,2,1)
hndl = plot(label, epscilon(1,:));
    hold on
    plot([1940,endyear-1],[0,0],'k-', 'HandleVisibility','off');
    enlargeChiara
axis([1948 endyear+1 -2 2])
title('TFP')
subplot(2,2,2)
hndl = plot(label, epscilon(2,:));
    hold on
    plot([1940,endyear-1],[0, 0],'k-', 'HandleVisibility','off');
    enlargeChiara
axis([1948 endyear+1 -1.2,1.2])
title('shocks to price markup')
subplot(2,2,3)
hndl = plot(label, epscilon(3,:));
    hold on
    plot([1940,endyear-1],[0,0],'k-', 'HandleVisibility','off');
    enlargeChiara
axis([1948 endyear+1 -1.2 1.2])
title('shocks to wage markup')
subplot(2,2,4)
hndl = plot(label, epscilon(4,:));
    hold on
    plot([1940,endyear-1],[0,0],'k-', 'HandleVisibility','off');
    enlargeChiara
axis([1948 endyear+1 -0.8 0.8])
title('shocks to risk premium')
saveas(gcf,'shocks1','epsc')
figure()
subplot(2,2,1)
hndl = plot(label, epscilon(5,:));
    hold on
    plot([1940,endyear-1],[0,0],'k-', 'HandleVisibility','off');
    enlargeChiara
axis([1948 endyear+1 -2 2])

title({'investment-specific';'technology'})
subplot(2,2,2)
hndl = plot(label, epscilon(6,:));
    hold on
    plot([1940,endyear-1],[0,0],'k-', 'HandleVisibility','off');
    enlargeChiara
axis([1948 endyear+1 -2 4])
title({'shocks to' ; 'government expenditure'})
subplot(2,2,3)
hndl = plot(label, epscilon(7,:));
    hold on
    plot([1940,endyear-1],[0,0],'k-', 'HandleVisibility','off');
    enlargeChiara
axis([1948 endyear+1 -1.1 1.5])
title('monetary policy shocks')
saveas(gcf,'shocks2','epsc')

    clear LAB_SIZE LET_SIZE DO_THICK_LINES



%% Figure E10 and E11 

clear all
clc
close all

% This file has been created in folder Main figures and tables
load usmodel2015_decomposition_1948_2015 

shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ; 


HD = zeros(7,options_.nobs);


HD(1,:) =  shock_decomposition(38,1,:); %eZ
HD(2,:) =  shock_decomposition(38,2,:); %ep
HD(3,:) =  shock_decomposition(38,3,:); %ew
HD(4,:) =  shock_decomposition(38,4,:); %eb2
HD(5,:) =  shock_decomposition(38,5,:); %emu
HD(6,:) =  shock_decomposition(38,6,:); %eg
HD(7,:) =  shock_decomposition(38,7,:); %ems
InitialValue =  shock_decomposition(38,8,:); 
InitialValue = InitialValue(:); 
SmoothedRobs = shock_decomposition(38,9,:); 
SmoothedRobs = SmoothedRobs(:); 


% Now I want to do the opposite: I remove one shock at a time and check 
% if there are relevant results. 
HD(8,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(9,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:)  + InitialValue' ; 


% combination of shocks
% preferences and investment adjustment cost
HD(15,:) = HD(5,:) + HD(4,:) ; 
  
% price + wage markup shocks
HD(16,:) = HD(2,:) + HD(3,:); 


figure()
        plot(label, SmoothedRobs)
        hold on 
        plot(label, HD(15,:), 'r--')
        axis([1948 endyear+1 -2 4])
saveas(gcf,'HDec_robs_2005-2013','epsc')


figure()
        plot(label(228:end), SmoothedRobs(228:end))
        hold on 
        plot(label(228:end), HD(14,228:end), 'r--')
        axis([2005 endyear+1 -2.2 0.5])
        title('monetary policy shock')
saveas(gcf,'HDec_removingshocks_robs_2005-2013','epsc')



%% Figures E12 to E15 

clear all 
clc

dynare usmodel2015_decomposition_2006_2015
save('usmodel2015_decomposition_2006_2015')

%%
close all
clear all


load 'usmodel2015_decomposition_2006_2015'

varlist = M_.endo_names(1:M_.orig_endo_nbr,:);
[i_var,nvar] = varlist_indices(varlist,M_.endo_names);


% INFLATION
graph_decomp_Chr( oo_.shock_decomposition(37,:,:)*4 ,M_.exo_names,'pinfobs',1,options_.initial_date,M_,options_) %Dynare Historical Decomposition for inflation
saveas(gcf,'HDec_Dynare_pinfobs_2005_2013','pdf')
saveas(gcf,'HDec_Dynare_pinfobs_2005_2013','epsc')

% EMPLOYMENT
graph_decomp_Chr( oo_.shock_decomposition(39,:,:) ,M_.exo_names,'labobs',1,options_.initial_date,M_,options_)
saveas(gcf,'HDec_Dynare_labobs_2005_2013','pdf')
saveas(gcf,'HDec_Dynare_labobs_2005_2013','epsc')

%OUTPUT GAP
graph_decomp_Chr( oo_.shock_decomposition(32,:,:) ,M_.exo_names,'output_gap',1,options_.initial_date,M_,options_) 
saveas(gcf,'HDec_Dynare_output_gap_2005_2013','pdf')
saveas(gcf,'HDec_Dynare_output_gap_2005_2013','epsc')

%ROBS
graph_decomp_Chr( oo_.shock_decomposition(38,:,:) ,M_.exo_names,'robs',1,options_.initial_date,M_,options_) 
saveas(gcf,'HDec_Dynare_robs_2005_2013','pdf')
saveas(gcf,'HDec_Dynare_robs_2005_2013','epsc')



%% Figures E16 to E22 


%% Table F5
clear all
clc


% file created in Estimation folder 
load usmodel1948_2007
f = 10.^2; 

posterior_mean_param1948_2007 =  round(f.*oo_.posterior.metropolis.mean)./f   ; 
posterior_mean_std1948_2007 = round(f.*sqrt(diag(oo_.posterior.metropolis.Variance)))./f;

% file created in Estimation folder 
load usmodel1984_2015
f = 10.^2; 

posterior_mean_param1984_2015 =  round(f.*oo_.posterior.metropolis.mean)./f   ; 
posterior_mean_std1984_2015 = round(f.*sqrt(diag(oo_.posterior.metropolis.Variance)))./f;

save('TABLE_F5', 'posterior_mean_param1948_2007', 'posterior_mean_std1948_2007', 'posterior_mean_param1984_2015', 'posterior_mean_std1984_2015');





%% Tables G6 and G7 

clear all
clc
close all

dynare usmodel4807_1948_2015.mod
save('usmodel4807_1948_2015')

%% 
clear all 

load usmodel4807_1948_2015

A = zeros(40); 
A(:,15:34) = oo_.dr.ghx;
C =  oo_.dr.ghu;

% 12 identifies the position of pinobs in oo_.dr.ghx and oo_.dr.ghu
E12 = zeros(40,1);
E12(12) = 1; 


E1 = zeros(7,1);
E1(1) = 1; 
E2 = zeros(7,1);
E2(2) = 1; 
E3 = zeros(7,1);
E3(3) = 1; 
E4 = zeros(7,1);
E4(4) = 1; 
E5 = zeros(7,1);
E5(5) = 1; 
E6 = zeros(7,1);
E6(6) = 1; 
E7 = zeros(7,1);
E7(7) = 1; 


% epscilon matrix(time period x 7):
epscilon = zeros(options_.nobs,7); 
epscilon(:,1) = oo_.SmoothedShocks.eZ;
epscilon(:,2) = oo_.SmoothedShocks.ep;
epscilon(:,3) = oo_.SmoothedShocks.ew;
epscilon(:,4) = oo_.SmoothedShocks.eb2;
epscilon(:,5) = oo_.SmoothedShocks.emu;
epscilon(:,6) = oo_.SmoothedShocks.eg;
epscilon(:,7) = oo_.SmoothedShocks.ems;
epscilon = epscilon'; 

% 1-step ahead error forecast: 
NU1 = E12'*C*epscilon;



n = 200; 
%n = 4; 

VDpre = zeros(7,n);
VDpre2 = zeros(7,n);
VDpost = zeros(7,n); 
VD = zeros(7,n); 
for k = 1:n

% ------------------ 1948-2007 ------------------
varNU_pre = 0; 
for j = 0:k-1
varNU_pre = varNU_pre  + (((E12'*(A^j)*C*E1)^2)* var(epscilon(1,1:239)))+(((E12'*(A^j)*C*E2)^2)* var(epscilon(2,1:239)))+(((E12' *(A^j)*C*E3)^2)* var(epscilon(3,1:239)))+(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,1:239)))+(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,1:239)))+(((E12' *(A^j)*C*E6)^2)* var(epscilon(6,1:239)))+(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,1:239)));
end

for j = 0:k-1
VDpre(1,k) = VDpre(1,k) +(((E12' *(A^j) *C*E1)^2)* var(epscilon(1,1:239)))/varNU_pre; 
VDpre(2,k) = VDpre(2,k) +(((E12' *(A^j) *C*E2)^2)* var(epscilon(2,1:239)))/varNU_pre; 
VDpre(3,k) = VDpre(3,k) +(((E12' *(A^j) *C*E3)^2)* var(epscilon(3,1:239)))/varNU_pre; 
VDpre(4,k) = VDpre(4,k) +(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,1:239)))/varNU_pre; 
VDpre(5,k) = VDpre(5,k) +(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,1:239)))/varNU_pre; 
VDpre(6,k) = VDpre(6,k) +(((E12' *(A^j)*C*E6)^2)* var(epscilon(6,1:239)))/varNU_pre; 
VDpre(7,k) = VDpre(7,k) +(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,1:239)))/varNU_pre; 
end

VDpre(1,k) + VDpre(2,k) + VDpre(3,k) + VDpre(4,k) + VDpre(5,k) + VDpre(6,k) + VDpre(7,k) 


clear varNU_pre




% ------------------ 1984-2007 ------------------
varNU_pre2 = 0; 
for j = 0:k-1
varNU_pre2 = varNU_pre2  + (((E12'*(A^j)*C*E1)^2)* var(epscilon(1,144:239)))+(((E12'*(A^j)*C*E2)^2)* var(epscilon(2,144:239)))+(((E12' *(A^j)*C*E3)^2)* var(epscilon(3,144:239)))+(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,144:239)))+(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,144:239)))+(((E12' *(A^j)*C*E6)^2)* var(epscilon(6,144:239)))+(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,144:239)));
end

for j = 0:k-1
VDpre2(1,k) = VDpre2(1,k) +(((E12' *(A^j) *C*E1)^2)* var(epscilon(1,144:239)))/varNU_pre2; 
VDpre2(2,k) = VDpre2(2,k) +(((E12' *(A^j) *C*E2)^2)* var(epscilon(2,144:239)))/varNU_pre2; 
VDpre2(3,k) = VDpre2(3,k) +(((E12' *(A^j) *C*E3)^2)* var(epscilon(3,144:239)))/varNU_pre2; 
VDpre2(4,k) = VDpre2(4,k) +(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,144:239)))/varNU_pre2; 
VDpre2(5,k) = VDpre2(5,k) +(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,144:239)))/varNU_pre2; 
VDpre2(6,k) = VDpre2(6,k) +(((E12' *(A^j)*C*E6)^2)* var(epscilon(6,144:239)))/varNU_pre2; 
VDpre2(7,k) = VDpre2(7,k) +(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,144:239)))/varNU_pre2; 
end

VDpre2(1,k) + VDpre2(2,k) + VDpre2(3,k) + VDpre2(4,k) + VDpre2(5,k) + VDpre2(6,k) + VDpre2(7,k) 


clear varNU_pre2




% ------------------ 2008-2013 ------------------
varNU_post = 0; 
for j = 0:k-1
varNU_post = varNU_post + (((E12' *(A^j)*C*E1)^2)* var(epscilon(1,240:end)))+(((E12'*(A^j) *C*E2)^2)* var(epscilon(2,240:end)))+(((E12'*(A^j) *C*E3)^2)* var(epscilon(3,240:end)))+(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,240:end)))+(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,240:end)))+(((E12' *(A^j)*C*E6)^2)* var(epscilon(6,240:end)))+(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,240:end)));
end

for j = 0:k-1
VDpost(1,k) = VDpost(1,k) + (((E12' *(A^j)*C*E1)^2)* var(epscilon(1,240:end)))/varNU_post; 
VDpost(2,k) = VDpost(2,k) +(((E12' *(A^j)*C*E2)^2)* var(epscilon(2,240:end)))/varNU_post; 
VDpost(3,k) = VDpost(3,k) + (((E12'*(A^j) *C*E3)^2)* var(epscilon(3,240:end)))/varNU_post; 
VDpost(4,k) = VDpost(4,k) + (((E12' *(A^j)*C*E4)^2)* var(epscilon(4,240:end)))/varNU_post; 
VDpost(5,k) = VDpost(5,k) + (((E12' *(A^j)*C*E5)^2)* var(epscilon(5,240:end)))/varNU_post; 
VDpost(6,k) = VDpost(6,k) + (((E12' *(A^j)*C*E6)^2)* var(epscilon(6,240:end)))/varNU_post; 
VDpost(7,k) = VDpost(7,k) + (((E12'*(A^j) *C*E7)^2)* var(epscilon(7,240:end)))/varNU_post; 
end

VDpost(1,k) + VDpost(2,k) + VDpost(3,k) + VDpost(4,k) + VDpost(5,k) + VDpost(6,k) + VDpost(7,k) 

clear varNU_post

% ------------------ 1948-2013 ------------------ 
% This is the 1-period aheas conditional variance decomposition for the whole sample 
% as a check this should be the same as the corresponding measure as is
% obtained from Dynare. 
varNU = 0; 
for j = 0:k-1
varNU = varNU + (((E12' *(A^j)*C*E1)^2)* var(epscilon(1,:)))+(((E12' *(A^j)*C*E2)^2)* var(epscilon(2,:)))+(((E12'*(A^j) *C*E3)^2)* var(epscilon(3,:)))+(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,:)))+(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,:)))+(((E12'*(A^j) *C*E6)^2)* var(epscilon(6,:)))+(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,:)));
end

for j = 0:k-1
VD(1,k) = VD(1,k) + (((E12' *(A^j)*C*E1)^2)* var(epscilon(1,:)))/varNU; 
VD(2,k) = VD(2,k) + (((E12' *(A^j)*C*E2)^2)* var(epscilon(2,:)))/varNU; 
VD(3,k) = VD(3,k) + (((E12' *(A^j)*C*E3)^2)* var(epscilon(3,:)))/varNU; 
VD(4,k) = VD(4,k) + (((E12' *(A^j)*C*E4)^2)* var(epscilon(4,:)))/varNU; 
VD(5,k) = VD(5,k) + (((E12' *(A^j)*C*E5)^2)* var(epscilon(5,:)))/varNU; 
VD(6,k) = VD(6,k) + (((E12' *(A^j)*C*E6)^2)* var(epscilon(6,:)))/varNU; 
VD(7,k) = VD(7,k) + (((E12' *(A^j)*C*E7)^2)* var(epscilon(7,:)))/varNU; 
end


VD(1,k) + VD(2,k) + VD(3,k) + VD(4,k) + VD(5,k) + VD(6,k) + VD(7,k) 

clear varNU

end

VD = VD*100; 
VDpre = VDpre*100; 
VDpre2 = VDpre2*100; 
VDpost = VDpost*100; 

save('VD_results_inflation_1948_2007.mat', 'VD', 'VDpre', 'VDpre2', 'VDpost')


%% 
clear all 
load('VD_results_inflation_1948_2007') 

Table_G6 = [VD(:,4), VDpre(:,4), VDpre2(:,4), VDpost(:,4)] ; 

Table_G7 = [VD(:,200), VDpre(:,200), VDpre2(:,200), VDpost(:,200)] ; 

save('Table_G6', 'Table_G6')


save('Table_G7', 'Table_G7')

%% Table G8: Standard deviation of the estimated shocks
clear all 

dynare usmodel_decomposition4807_1948_2015
save('usmodel_decomposition4807_1948_2015')

%% 
 clear all 
 
load usmodel_decomposition4807_1948_2015
shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ; 


epscilon = zeros(7,options_.nobs);
    epscilon(1, 2:options_.nobs) = oo_.SmoothedShocks.eZ(2:options_.nobs)';
    epscilon(2, 2:options_.nobs) = oo_.SmoothedShocks.ep(2:options_.nobs)';
    epscilon(3, 2:options_.nobs) = oo_.SmoothedShocks.ew(2:options_.nobs)';
    epscilon(4, 2:options_.nobs) = oo_.SmoothedShocks.eb2(2:options_.nobs)';
    epscilon(5, 2:options_.nobs) = oo_.SmoothedShocks.emu(2:options_.nobs)';
    epscilon(6, 2:options_.nobs) = oo_.SmoothedShocks.eg(2:options_.nobs)';
    epscilon(7, 2:options_.nobs) = oo_.SmoothedShocks.ems(2:options_.nobs)';
    
Shocks_std = zeros(7,5); 

for i = 1:7
   Shocks_std(i,1) = std( epscilon(i,:)); 
   Shocks_std(i,2) = std( epscilon(i,1:239)); %1948-2007
   Shocks_std(i,3) = std( epscilon(i,1:143)); %1948-1983
   Shocks_std(i,4) = std( epscilon(i,143:239)); %1984-2007
   Shocks_std(i,5) = std( epscilon(i,240:end)); %2008-2015
end


Shocks_std_4815 = Shocks_std(:,1); 
Shocks_std_4807 = Shocks_std(:,2); 
Shocks_std_4884 = Shocks_std(:,3);
Shocks_std_8407 = Shocks_std(:,4);
Shocks_std_0715 = Shocks_std(:,5);

label2 = cell(7,1); 
label2{1} = ['technology shock ' ] ;
label2{2} = ['price markup' ] ;
label2{3} = ['wage markup' ] ;
label2{4} = ['risk premium' ] ;
label2{5} = ['investment adjustment shock' ] ;
label2{6} = ['govt expenditure'  ] ;
label2{7} = ['monetary shocks' ] ;

Table_G8 = [Shocks_std_4815 ,Shocks_std_4807 , Shocks_std_4884 ,Shocks_std_8407, Shocks_std_0715 ] ;


save('TABLE_shocks_std_1948_2007_mean', 'label2', 'Shocks_std_4815', 'Shocks_std_4807', 'Shocks_std_4884', 'Shocks_std_8407', 'Shocks_std_0715');

save('Table_G8', 'Table_G8') 

%% Figures G23, G24

load usmodel_decomposition4807_1948_2015

shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ; 


HD = zeros(20,options_.nobs); 

HD(1,:) =  shock_decomposition(37,1,:); %eZ
HD(2,:) =  shock_decomposition(37,2,:); %ep
HD(3,:) =  shock_decomposition(37,3,:); %ew
HD(4,:) =  shock_decomposition(37,4,:); %eb2
HD(5,:) =  shock_decomposition(37,5,:); %emu (inv. adj. cost) 
HD(6,:) =  shock_decomposition(37,6,:); %eg
HD(7,:) =  shock_decomposition(37,7,:); %ems (monetary shock)
InitialValue =  shock_decomposition(37,8,:); 
InitialValue = InitialValue(:); 
SmoothedPinfobs = shock_decomposition(37,9,:); 
SmoothedPinfobs = SmoothedPinfobs(:); 


HD(8,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(9,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:)  + InitialValue' ; 


% lambda_p + lambda_w seem to explain most of the variation with the
% exception of the latest years
HD(15,:) = HD(2,:) + HD(3,:); 



% lambda_w + monetary policy
HD(16,:) = HD(3,:)+ HD(7,:); 



% lambda_w + shock to preferences 
HD(17,:) = HD(3,:) + HD(4,:); 

    
% lambda_w + shock to preferences + monetary shock 
 HD(18,:) = HD(3,:) + HD(4,:) + HD(7,:);  
    
    
% investm. adj + shock to preferences + monetary shock 
    HD(19,:) = HD(5,:) + HD(4,:) + HD(7,:); 
  
% investm. adj + shock to preferences + monetary shock + price markup 
    HD(20,:) =  HD(5,:) + HD(4,:) + HD(7,:) + HD(2,:); 
    


epscilon = zeros(7,options_.nobs);
    epscilon(1, 2:options_.nobs) = oo_.SmoothedShocks.eZ(2:options_.nobs)';
    epscilon(2, 2:options_.nobs) = oo_.SmoothedShocks.ep(2:options_.nobs)';
    epscilon(3, 2:options_.nobs) = oo_.SmoothedShocks.ew(2:options_.nobs)';
    epscilon(4, 2:options_.nobs) = oo_.SmoothedShocks.eb2(2:options_.nobs)';
    epscilon(5, 2:options_.nobs) = oo_.SmoothedShocks.emu(2:options_.nobs)';
    epscilon(6, 2:options_.nobs) = oo_.SmoothedShocks.eg(2:options_.nobs)';
    epscilon(7, 2:options_.nobs) = oo_.SmoothedShocks.ems(2:options_.nobs)';
    
    
    HD = HD*4; % ANNUALIZED INFLATION; 
    SmoothedPinfobs = SmoothedPinfobs*4 ; % ANNUALIZED INFLATION; 
    InitialValue = InitialValue*4 ; 
    const_pi = const_pi*4 ; 

close all 

figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi, [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(1,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'TFP shocks'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(2,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 3*4])
        plot([2008.75,2008.75],[ -0.5*4 3*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to price markup'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi , [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(3,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to wage markup'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(4,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to risk premium'})
saveas(gcf,'HDec_pi_1984_2015_e4807','pdf')
saveas(gcf,'HDec_pi_1984_2015_e4807.epsc','epsc')

figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(5,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of shocks to';'investment-specific technology'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(6,144:end)+const_pi, 'r--');
        axis([1984 endyear+1 -0.5*4 2*4])
        enlargeChiara
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of shocks to';'government expenditure'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(7,144:end)+const_pi, 'r--')
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'monetary policy shock'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(15,144:end)+const_pi, 'r--')
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'price and wage';'markup shocks'})        
saveas(gcf,'HDec_pi_1984_2015_e4807_b','pdf')
saveas(gcf,'HDec_pi_1984_2015_e4807_b.epsc','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES


%% Figure G25 and G26: Historical shock decomposition of inflation (relative to long-run constant) for the period 2006Q1-2015Q1


close all


figure()
    subplot(2,2,1)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(1,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of';'shocks to TFP'})
    subplot(2,2,2)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(2,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of';'shock to price markup'})
    subplot(2,2,3)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(3,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of';'shock to wage markup'})
    subplot(2,2,4)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(4,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of';'shock to risk premium'})
saveas(gcf,'HDec_pi_2005_2015_e4807','pdf')
saveas(gcf,'HDec_pi_2005_2015_e4807.epsc','epsc')


figure()
    subplot(2,2,1)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(5,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of shocks to';'investment-specific technology'})
    subplot(2,2,2)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(6,:), 'r--');
        axis([2006 endyear+1 -1.2*4 7])
        enlargeChiara
        title({'contrib. of shock to';'government expenditure'})
    subplot(2,2,3)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(7,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of';'monetary policy shock'})
saveas(gcf,'HDec_pi_2005_2015_e4807_b','pdf')
saveas(gcf,'HDec_pi_2005_2015_e4807_b.epsc','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES



%% Figure G27


figure()
    hndl = plot(label, epscilon(2,:));
    enlarge
    hold on
    plot([1940,2020],[0,0],'k-', 'HandleVisibility','off');
    title('Shocks to price markup')
    saveas(gcf,'shocksp_e4807','pdf')
        saveas(gcf,'shocksp_e4807.epsc','epsc')
figure()
    hndl = plot(label, epscilon(3,:));
    enlarge
    hold on
    plot([1940,2020],[0,0],'k-', 'HandleVisibility','off');
    title('Shocks to wage markup')
    saveas(gcf,'shocksw_e4807','pdf')
     saveas(gcf,'shocksw_e4807.epsc','epsc')


%% Figure G28 : A comparison between interest rate and the output gap
close all 
load usmodel_decomposition4807_1948_2015

shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ; 


SmoothedOutputgap = shock_decomposition(13,9,:) - shock_decomposition(23,9,:) ; 
SmoothedOutputgap = SmoothedOutputgap(:); 

hndl = plot(label(228:end),SmoothedOutputgap(228:end));
enlarge
hold on
title('Output Gap','FontSize',26)
axis([2005 endyear+1 -25 5])
plot([2005 endyear+1], [0,0])
set(gca,'FontSize',26)   % this changes the tick size! 
saveas(gcf,'outputgap_20052013_e4807.epsc') 
saveas(gcf,'outputgap_20052013_e4807.pdf') 


HD = zeros(7,options_.nobs);


HD(1,:) =  shock_decomposition(38,1,:); %eZ
HD(2,:) =  shock_decomposition(38,2,:); %ep
HD(3,:) =  shock_decomposition(38,3,:); %ew
HD(4,:) =  shock_decomposition(38,4,:); %eb2
HD(5,:) =  shock_decomposition(38,5,:); %emu
HD(6,:) =  shock_decomposition(38,6,:); %eg
HD(7,:) =  shock_decomposition(38,7,:); %ems
InitialValue =  shock_decomposition(38,8,:); 
InitialValue = InitialValue(:); 
SmoothedRobs = shock_decomposition(38,9,:); 
SmoothedRobs = SmoothedRobs(:); 


% Now I want to do the opposite: I remove one shock at a time and check 
% if there are relevant results. 
HD(8,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(9,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:)  + InitialValue' ; 


% combination of shocks
% preferences and investment adjustment cost
HD(15,:) = HD(5,:) + HD(4,:) ; 
  
% price + wage markup shocks
HD(16,:) = HD(2,:) + HD(3,:); 

figure()
        hndl = plot(label(228:end), 4*(SmoothedRobs(228:end)+const_R));
        enlarge
        hold on 
        hndl = plot(label(228:end), 4*(HD(14,228:end)+const_R), 'r--');
        enlarge
        plot([2005,endyear+1], [0,0], 'k')
         axis([2005 endyear+1 -0.8*4 1.5*4])
        title('Interest Rate','FontSize',26)
        set(gca,'FontSize',26)   % this changes the tick size!         
clear LAB_SIZE LET_SIZE DO_THICK_LINES


saveas(gcf,'Hall_intrate2_e4807','pdf')
saveas(gcf,'Hall_intrate2_e4807','epsc')


%% Figure G29  Decomposition of the nominal interest rate according to the Taylor rule from the model

clear all
clc
close all

load usmodel_decomposition4807_1948_2015
shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ; 

HD = zeros(7,options_.nobs);


HD(1,:) =  shock_decomposition(38,1,:); %eZ
HD(2,:) =  shock_decomposition(38,2,:); %ep
HD(3,:) =  shock_decomposition(38,3,:); %ew
HD(4,:) =  shock_decomposition(38,4,:); %eb2
HD(5,:) =  shock_decomposition(38,5,:); %emu
HD(6,:) =  shock_decomposition(38,6,:); %eg
HD(7,:) =  shock_decomposition(38,7,:); %ems
InitialValue =  shock_decomposition(38,8,:); 
InitialValue = InitialValue(:); 
SmoothedRobs = shock_decomposition(38,9,:); 
SmoothedRobs = SmoothedRobs(:); 


% Now I want to do the opposite: I remove one shock at a time and check 
% if there are relevant results. 
HD(8,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(9,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:)  + InitialValue' ; 


% combination of shocks
% preferences and investment adjustment cost
HD(15,:) = HD(5,:) + HD(4,:) ; 
  
% price + wage markup shocks
HD(16,:) = HD(2,:) + HD(3,:); 



Taylor = zeros(7, options_.nobs); 

% contribution of initial point
for i= 2:options_.nobs
        Taylor(1,i) = rhoR*SmoothedRobs(i-1);
end

% contribution of inflation
for i= 2:options_.nobs
        Taylor(2,i) = (1 - rhoR)* (psi1*oo_.SmoothedVariables.pi(i));
end

% contribution of output gap
for i= 2:options_.nobs
        Taylor(3,i) = (1 - rhoR)* ( psi2*(oo_.SmoothedVariables.y(i) - oo_.SmoothedVariables.y_flex(i)));
end

% contribution of output gap growth 
for i= 2:options_.nobs
        Taylor(4,i) =   psi3*( oo_.SmoothedVariables.y(i) - oo_.SmoothedVariables.y(i-1) - oo_.SmoothedVariables.y_flex(i) + oo_.SmoothedVariables.y_flex(i-1)   )   ;
end

% contribution of monetary shock 
for i= 2:options_.nobs
        Taylor(5,i) =  oo_.SmoothedVariables.ms(i);
end

for i= 2:options_.nobs
Taylor(6,i) = Taylor(2,i) + Taylor(3,i) + Taylor(4,i) + Taylor(5,i) ;
Taylor(7,i) = Taylor(1,i) + Taylor(6,i) ; 

end

Taylor(:, 1) = NaN; 

%
% Taylor 1 = smoothing component = rhoR*r(-1)
%Taylor 2 = inflation component
% Taylor 3 = output gap 
% Taylor 4 = output gap growht
% Taylor 5 = monetary shock
% Taylor 6 = Taylor2 + T 3 + T 4 + T 5 
% Taylor 7 = Taylor 1 + Taylor 6  = SmoothedRobs+const_R


figure()
plot([2004, endyear], [0,0], 'HandleVisibility','off')
hold on
plot(label(228:end), SmoothedRobs(228:end), 'k', 'LineWidth',2 )
area(label(228:end),Taylor(2:4,228:end)'); 
colormap copper
plot(label(228:end), oo_.SmoothedVariables.ms(228:end), 'k:', 'LineWidth',4 )
 set(gca,'FontSize',12) 
legend( 'interest rate', 'inflation comp.', 'output gap comp.', 'output gap growth c.', 'monetary shocks', 'Location', 'SouthWest');
 axis([2005 endyear+1 -2 .6])
 
saveas(gcf,'Taylor_rule_decomposition_e4807','pdf')
saveas(gcf,'Taylor_rule_decomposition_e4807','epsc')



%% Tables G9 and G10 

clear all
clc
close all

load usmodel4807_1948_2015


A = zeros(40); 
A(:,15:34) = oo_.dr.ghx;
C =  oo_.dr.ghu;

E14 = zeros(40,1);
E14(14) = 1; 


E1 = zeros(7,1);
E1(1) = 1; 
E2 = zeros(7,1);
E2(2) = 1; 
E3 = zeros(7,1);
E3(3) = 1; 
E4 = zeros(7,1);
E4(4) = 1; 
E5 = zeros(7,1);
E5(5) = 1; 
E6 = zeros(7,1);
E6(6) = 1; 
E7 = zeros(7,1);
E7(7) = 1; 


% epscilon matrix(time period x 7):
epscilon = zeros(options_.nobs,7); 
epscilon(:,1) = oo_.SmoothedShocks.eZ;
epscilon(:,2) = oo_.SmoothedShocks.ep;
epscilon(:,3) = oo_.SmoothedShocks.ew;
epscilon(:,4) = oo_.SmoothedShocks.eb2;
epscilon(:,5) = oo_.SmoothedShocks.emu;
epscilon(:,6) = oo_.SmoothedShocks.eg;
epscilon(:,7) = oo_.SmoothedShocks.ems;
epscilon = epscilon'; 

% 1-step ahead error forecast: 
NU1 = E14'*C*epscilon;



n = 200; 
%n = 4; 

VDpre = zeros(7,n);
VDpre2 = zeros(7,n);
VDpost = zeros(7,n); 
VD = zeros(7,n); 
for k = 1:n

% ------------------ 1948-2007 ------------------
varNU_pre = 0; 
for j = 0:k-1
varNU_pre = varNU_pre  + (((E14'*(A^j)*C*E1)^2)* var(epscilon(1,1:239)))+(((E14'*(A^j)*C*E2)^2)* var(epscilon(2,1:239)))+(((E14' *(A^j)*C*E3)^2)* var(epscilon(3,1:239)))+(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,1:239)))+(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,1:239)))+(((E14' *(A^j)*C*E6)^2)* var(epscilon(6,1:239)))+(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,1:239)));
end

for j = 0:k-1
VDpre(1,k) = VDpre(1,k) +(((E14' *(A^j) *C*E1)^2)* var(epscilon(1,1:239)))/varNU_pre; 
VDpre(2,k) = VDpre(2,k) +(((E14' *(A^j) *C*E2)^2)* var(epscilon(2,1:239)))/varNU_pre; 
VDpre(3,k) = VDpre(3,k) +(((E14' *(A^j) *C*E3)^2)* var(epscilon(3,1:239)))/varNU_pre; 
VDpre(4,k) = VDpre(4,k) +(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,1:239)))/varNU_pre; 
VDpre(5,k) = VDpre(5,k) +(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,1:239)))/varNU_pre; 
VDpre(6,k) = VDpre(6,k) +(((E14' *(A^j)*C*E6)^2)* var(epscilon(6,1:239)))/varNU_pre; 
VDpre(7,k) = VDpre(7,k) +(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,1:239)))/varNU_pre; 
end

VDpre(1,k) + VDpre(2,k) + VDpre(3,k) + VDpre(4,k) + VDpre(5,k) + VDpre(6,k) + VDpre(7,k) 


clear varNU_pre



% ------------------ 1984-2007 ------------------
varNU_pre2 = 0; 
for j = 0:k-1
varNU_pre2 = varNU_pre2  + (((E14'*(A^j)*C*E1)^2)* var(epscilon(1,144:239)))+(((E14'*(A^j)*C*E2)^2)* var(epscilon(2,144:239)))+(((E14' *(A^j)*C*E3)^2)* var(epscilon(3,144:239)))+(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,144:239)))+(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,144:239)))+(((E14' *(A^j)*C*E6)^2)* var(epscilon(6,144:239)))+(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,144:239)));
end

for j = 0:k-1
VDpre2(1,k) = VDpre2(1,k) +(((E14' *(A^j) *C*E1)^2)* var(epscilon(1,144:239)))/varNU_pre2; 
VDpre2(2,k) = VDpre2(2,k) +(((E14' *(A^j) *C*E2)^2)* var(epscilon(2,144:239)))/varNU_pre2; 
VDpre2(3,k) = VDpre2(3,k) +(((E14' *(A^j) *C*E3)^2)* var(epscilon(3,144:239)))/varNU_pre2; 
VDpre2(4,k) = VDpre2(4,k) +(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,144:239)))/varNU_pre2; 
VDpre2(5,k) = VDpre2(5,k) +(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,144:239)))/varNU_pre2; 
VDpre2(6,k) = VDpre2(6,k) +(((E14' *(A^j)*C*E6)^2)* var(epscilon(6,144:239)))/varNU_pre2; 
VDpre2(7,k) = VDpre2(7,k) +(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,144:239)))/varNU_pre2; 
end

VDpre2(1,k) + VDpre2(2,k) + VDpre2(3,k) + VDpre2(4,k) + VDpre2(5,k) + VDpre2(6,k) + VDpre2(7,k) 


clear varNU_pre2


% ------------------ 2008-2013 ------------------
varNU_post = 0; 
for j = 0:k-1
varNU_post = varNU_post + (((E14' *(A^j)*C*E1)^2)* var(epscilon(1,240:end)))+(((E14'*(A^j) *C*E2)^2)* var(epscilon(2,240:end)))+(((E14'*(A^j) *C*E3)^2)* var(epscilon(3,240:end)))+(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,240:end)))+(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,240:end)))+(((E14' *(A^j)*C*E6)^2)* var(epscilon(6,240:end)))+(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,240:end)));
end

for j = 0:k-1
VDpost(1,k) = VDpost(1,k) + (((E14' *(A^j)*C*E1)^2)* var(epscilon(1,240:end)))/varNU_post; 
VDpost(2,k) = VDpost(2,k) +(((E14' *(A^j)*C*E2)^2)* var(epscilon(2,240:end)))/varNU_post; 
VDpost(3,k) = VDpost(3,k) + (((E14'*(A^j) *C*E3)^2)* var(epscilon(3,240:end)))/varNU_post; 
VDpost(4,k) = VDpost(4,k) + (((E14' *(A^j)*C*E4)^2)* var(epscilon(4,240:end)))/varNU_post; 
VDpost(5,k) = VDpost(5,k) + (((E14' *(A^j)*C*E5)^2)* var(epscilon(5,240:end)))/varNU_post; 
VDpost(6,k) = VDpost(6,k) + (((E14' *(A^j)*C*E6)^2)* var(epscilon(6,240:end)))/varNU_post; 
VDpost(7,k) = VDpost(7,k) + (((E14'*(A^j) *C*E7)^2)* var(epscilon(7,240:end)))/varNU_post; 
end

VDpost(1,k) + VDpost(2,k) + VDpost(3,k) + VDpost(4,k) + VDpost(5,k) + VDpost(6,k) + VDpost(7,k) 

clear varNU_post

% ------------------ 1948-2013 ------------------ 
% This is the 1-period aheas conditional variance decomposition for the whole sample 
% as a check this should be the same as the corresponding measure as is
% obtained from Dynare. 
varNU = 0; 
for j = 0:k-1
varNU = varNU + (((E14' *(A^j)*C*E1)^2)* var(epscilon(1,:)))+(((E14' *(A^j)*C*E2)^2)* var(epscilon(2,:)))+(((E14'*(A^j) *C*E3)^2)* var(epscilon(3,:)))+(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,:)))+(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,:)))+(((E14'*(A^j) *C*E6)^2)* var(epscilon(6,:)))+(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,:)));
end

for j = 0:k-1
VD(1,k) = VD(1,k) + (((E14' *(A^j)*C*E1)^2)* var(epscilon(1,:)))/varNU; 
VD(2,k) = VD(2,k) + (((E14' *(A^j)*C*E2)^2)* var(epscilon(2,:)))/varNU; 
VD(3,k) = VD(3,k) + (((E14' *(A^j)*C*E3)^2)* var(epscilon(3,:)))/varNU; 
VD(4,k) = VD(4,k) + (((E14' *(A^j)*C*E4)^2)* var(epscilon(4,:)))/varNU; 
VD(5,k) = VD(5,k) + (((E14' *(A^j)*C*E5)^2)* var(epscilon(5,:)))/varNU; 
VD(6,k) = VD(6,k) + (((E14' *(A^j)*C*E6)^2)* var(epscilon(6,:)))/varNU; 
VD(7,k) = VD(7,k) + (((E14' *(A^j)*C*E7)^2)* var(epscilon(7,:)))/varNU; 
end


VD(1,k) + VD(2,k) + VD(3,k) + VD(4,k) + VD(5,k) + VD(6,k) + VD(7,k) 

clear varNU

end

VD = VD*100; 
VDpre = VDpre*100; 
VDpre2 = VDpre2*100;
VDpost = VDpost*100; 

save('VD_results_employment1948_2007.mat', 'VD', 'VDpre', 'VDpre2','VDpost')


%% 

clear all

load('VD_results_employment1948_2007.mat')
Table_G9 = [VD(:,4), VDpre(:,4), VDpre2(:,4), VDpost(:,4)] ; 

Table_G10 = [VD(:,200), VDpre(:,200), VDpre2(:,200), VDpost(:,200)] ; 


save('Table_G9', 'Table_G9') 

save('Table_G10', 'Table_G10') 


%% Figure G30 and G31: Historical shock decomposition of employment for the period 1984-2015
close all 
clear all 

load usmodel_decomposition4807_1948_2015

shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ;

% http://www.dynare.org/phpBB3/viewtopic.php?f=1&t=5887
% The mean of the smoothed variables is non-zero if the corresponding data



HD(1,:) =  shock_decomposition(39,1,:); %eZ
HD(2,:) =  shock_decomposition(39,2,:); %ep
HD(3,:) =  shock_decomposition(39,3,:); %ew
HD(4,:) =  shock_decomposition(39,4,:); %eb2
HD(5,:) =  shock_decomposition(39,5,:); %emu
HD(6,:) =  shock_decomposition(39,6,:); %eg
HD(7,:) =  shock_decomposition(39,7,:); %ems
InitialValue =  shock_decomposition(39,8,:); 
InitialValue = InitialValue(:); 
SmoothedLabobs = shock_decomposition(39,9,:); 
SmoothedLabobs = SmoothedLabobs(:); 


HD(8,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(9,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:)  + InitialValue' ; 

% lambda_p + lambda_w seem to explain most of the variation with the
% exception of the latest years
HD(15,:) = HD(2,:) + HD(3,:); 



% lambda_w + monetary policy
HD(16,:) = HD(3,:)+ HD(7,:); 
    
% lambda_w + shock to preferences 
HD(17,:) = HD(3,:) + HD(4,:); 

    
% lambda_w + shock to preferences + monetary shock 
 HD(18,:) = HD(3,:) + HD(4,:) + HD(7,:);  
    
    
% investm. adj + shock to preferences + monetary shock 
    HD(19,:) = HD(5,:) + HD(4,:) + HD(7,:); 
  
% investm. adj + shock to preferences + monetary shock + price markup 
    HD(20,:) =  HD(5,:) + HD(4,:) + HD(7,:) + HD(2,:); 
    
    
    
figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end),HD(1,144:end) , 'r--');
        enlargeChiara
        axis([1984 endyear+1 -12 8])
        title({'contrib. of';'TFP'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(2,144:end), 'r--');
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'contrib. of';'shock to price markup'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(3,144:end), 'r--');
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'contrib. of';'shock to wage markup'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(4,144:end), 'r--');
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'contrib. of';'shock to risk premium'})
saveas(gcf,'HDec_lab_1984-2013_e4807','pdf')
saveas(gcf,'HDec_lab_1984-2013_e4807','epsc')


figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(5,144:end), 'r--')
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'contrib. of shocks to';'investment-specific technology'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(6,144:end), 'r--')
        axis([1984 endyear+1 -12 8 ])
        enlargeChiara
        title({'contrib. of shock to';'government expenditure'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(7,144:end), 'r--')
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'contrib. of';'monetary policy shock'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(15,144:end), 'r--')
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'price and wage';'markup shock'})
saveas(gcf,'HDec_lab_1984-2013_e4807_b','pdf')
saveas(gcf,'HDec_lab_1984-2013_e4807_b','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES

%% Figures G32 and G33:  Historical shock decomposition of employment for the period 2005-2015

figure()
    subplot(2,2,1)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(1,228:end), 'r--');
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        title({'contrib. of';'TFP'})
    subplot(2,2,2)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(2,228:end), 'r--');
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        title({'contrib. of';'shocks to price markup'})
    subplot(2,2,3)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(3,228:end), 'r--');
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        title({'contrib. of';'shocks to wage markup'})
    subplot(2,2,4)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(4,228:end), 'r--');
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        title({'contrib. of';'shocks to risk premium'})
saveas(gcf,'HDec_lab_2005-2013_e4807','pdf')
saveas(gcf,'HDec_lab_2005-2013_e4807','epsc')

figure()
    subplot(2,2,1)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(5,228:end), 'r--');
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        title({'contrib. of shocks to ';'investment-adjustment technology'})
    subplot(2,2,2)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(6,228:end), 'r--');
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        enlargeChiara
        title({'contrib. of shocks to';'government expenditure'})
    subplot(2,2,3)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(7,228:end), 'r--');
        line([2005 endyear+1], [0 0])
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        title({'contrib. of';'monetary policy shocks'})
saveas(gcf,'HDec_lab_2005-2013_e4807_b','pdf')
saveas(gcf,'HDec_lab_2005-2013_e4807_b','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







%% Tables H11 and H12

clear all
clc
close all

dynare usmodel8415_1948_2015.mod
save('usmodel8415_1948_2015')

%% 
clear all 

load usmodel4807_1948_2015

A = zeros(40); 
A(:,15:34) = oo_.dr.ghx;
C =  oo_.dr.ghu;

% 12 identifies the position of pinobs in oo_.dr.ghx and oo_.dr.ghu
E12 = zeros(40,1);
E12(12) = 1; 


E1 = zeros(7,1);
E1(1) = 1; 
E2 = zeros(7,1);
E2(2) = 1; 
E3 = zeros(7,1);
E3(3) = 1; 
E4 = zeros(7,1);
E4(4) = 1; 
E5 = zeros(7,1);
E5(5) = 1; 
E6 = zeros(7,1);
E6(6) = 1; 
E7 = zeros(7,1);
E7(7) = 1; 


% epscilon matrix(time period x 7):
epscilon = zeros(options_.nobs,7); 
epscilon(:,1) = oo_.SmoothedShocks.eZ;
epscilon(:,2) = oo_.SmoothedShocks.ep;
epscilon(:,3) = oo_.SmoothedShocks.ew;
epscilon(:,4) = oo_.SmoothedShocks.eb2;
epscilon(:,5) = oo_.SmoothedShocks.emu;
epscilon(:,6) = oo_.SmoothedShocks.eg;
epscilon(:,7) = oo_.SmoothedShocks.ems;
epscilon = epscilon'; 

% 1-step ahead error forecast: 
NU1 = E12'*C*epscilon;



n = 200; 
%n = 4; 

VDpre = zeros(7,n);
VDpre2 = zeros(7,n);
VDpost = zeros(7,n); 
VD = zeros(7,n); 
for k = 1:n

% ------------------ 1948-2007 ------------------
varNU_pre = 0; 
for j = 0:k-1
varNU_pre = varNU_pre  + (((E12'*(A^j)*C*E1)^2)* var(epscilon(1,1:239)))+(((E12'*(A^j)*C*E2)^2)* var(epscilon(2,1:239)))+(((E12' *(A^j)*C*E3)^2)* var(epscilon(3,1:239)))+(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,1:239)))+(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,1:239)))+(((E12' *(A^j)*C*E6)^2)* var(epscilon(6,1:239)))+(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,1:239)));
end

for j = 0:k-1
VDpre(1,k) = VDpre(1,k) +(((E12' *(A^j) *C*E1)^2)* var(epscilon(1,1:239)))/varNU_pre; 
VDpre(2,k) = VDpre(2,k) +(((E12' *(A^j) *C*E2)^2)* var(epscilon(2,1:239)))/varNU_pre; 
VDpre(3,k) = VDpre(3,k) +(((E12' *(A^j) *C*E3)^2)* var(epscilon(3,1:239)))/varNU_pre; 
VDpre(4,k) = VDpre(4,k) +(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,1:239)))/varNU_pre; 
VDpre(5,k) = VDpre(5,k) +(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,1:239)))/varNU_pre; 
VDpre(6,k) = VDpre(6,k) +(((E12' *(A^j)*C*E6)^2)* var(epscilon(6,1:239)))/varNU_pre; 
VDpre(7,k) = VDpre(7,k) +(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,1:239)))/varNU_pre; 
end

VDpre(1,k) + VDpre(2,k) + VDpre(3,k) + VDpre(4,k) + VDpre(5,k) + VDpre(6,k) + VDpre(7,k) 


clear varNU_pre




% ------------------ 1984-2007 ------------------
varNU_pre2 = 0; 
for j = 0:k-1
varNU_pre2 = varNU_pre2  + (((E12'*(A^j)*C*E1)^2)* var(epscilon(1,144:239)))+(((E12'*(A^j)*C*E2)^2)* var(epscilon(2,144:239)))+(((E12' *(A^j)*C*E3)^2)* var(epscilon(3,144:239)))+(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,144:239)))+(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,144:239)))+(((E12' *(A^j)*C*E6)^2)* var(epscilon(6,144:239)))+(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,144:239)));
end

for j = 0:k-1
VDpre2(1,k) = VDpre2(1,k) +(((E12' *(A^j) *C*E1)^2)* var(epscilon(1,144:239)))/varNU_pre2; 
VDpre2(2,k) = VDpre2(2,k) +(((E12' *(A^j) *C*E2)^2)* var(epscilon(2,144:239)))/varNU_pre2; 
VDpre2(3,k) = VDpre2(3,k) +(((E12' *(A^j) *C*E3)^2)* var(epscilon(3,144:239)))/varNU_pre2; 
VDpre2(4,k) = VDpre2(4,k) +(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,144:239)))/varNU_pre2; 
VDpre2(5,k) = VDpre2(5,k) +(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,144:239)))/varNU_pre2; 
VDpre2(6,k) = VDpre2(6,k) +(((E12' *(A^j)*C*E6)^2)* var(epscilon(6,144:239)))/varNU_pre2; 
VDpre2(7,k) = VDpre2(7,k) +(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,144:239)))/varNU_pre2; 
end

VDpre2(1,k) + VDpre2(2,k) + VDpre2(3,k) + VDpre2(4,k) + VDpre2(5,k) + VDpre2(6,k) + VDpre2(7,k) 


clear varNU_pre2




% ------------------ 2008-2013 ------------------
varNU_post = 0; 
for j = 0:k-1
varNU_post = varNU_post + (((E12' *(A^j)*C*E1)^2)* var(epscilon(1,240:end)))+(((E12'*(A^j) *C*E2)^2)* var(epscilon(2,240:end)))+(((E12'*(A^j) *C*E3)^2)* var(epscilon(3,240:end)))+(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,240:end)))+(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,240:end)))+(((E12' *(A^j)*C*E6)^2)* var(epscilon(6,240:end)))+(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,240:end)));
end

for j = 0:k-1
VDpost(1,k) = VDpost(1,k) + (((E12' *(A^j)*C*E1)^2)* var(epscilon(1,240:end)))/varNU_post; 
VDpost(2,k) = VDpost(2,k) +(((E12' *(A^j)*C*E2)^2)* var(epscilon(2,240:end)))/varNU_post; 
VDpost(3,k) = VDpost(3,k) + (((E12'*(A^j) *C*E3)^2)* var(epscilon(3,240:end)))/varNU_post; 
VDpost(4,k) = VDpost(4,k) + (((E12' *(A^j)*C*E4)^2)* var(epscilon(4,240:end)))/varNU_post; 
VDpost(5,k) = VDpost(5,k) + (((E12' *(A^j)*C*E5)^2)* var(epscilon(5,240:end)))/varNU_post; 
VDpost(6,k) = VDpost(6,k) + (((E12' *(A^j)*C*E6)^2)* var(epscilon(6,240:end)))/varNU_post; 
VDpost(7,k) = VDpost(7,k) + (((E12'*(A^j) *C*E7)^2)* var(epscilon(7,240:end)))/varNU_post; 
end

VDpost(1,k) + VDpost(2,k) + VDpost(3,k) + VDpost(4,k) + VDpost(5,k) + VDpost(6,k) + VDpost(7,k) 

clear varNU_post

% ------------------ 1948-2013 ------------------ 
% This is the 1-period aheas conditional variance decomposition for the whole sample 
% as a check this should be the same as the corresponding measure as is
% obtained from Dynare. 
varNU = 0; 
for j = 0:k-1
varNU = varNU + (((E12' *(A^j)*C*E1)^2)* var(epscilon(1,:)))+(((E12' *(A^j)*C*E2)^2)* var(epscilon(2,:)))+(((E12'*(A^j) *C*E3)^2)* var(epscilon(3,:)))+(((E12' *(A^j)*C*E4)^2)* var(epscilon(4,:)))+(((E12' *(A^j)*C*E5)^2)* var(epscilon(5,:)))+(((E12'*(A^j) *C*E6)^2)* var(epscilon(6,:)))+(((E12' *(A^j)*C*E7)^2)* var(epscilon(7,:)));
end

for j = 0:k-1
VD(1,k) = VD(1,k) + (((E12' *(A^j)*C*E1)^2)* var(epscilon(1,:)))/varNU; 
VD(2,k) = VD(2,k) + (((E12' *(A^j)*C*E2)^2)* var(epscilon(2,:)))/varNU; 
VD(3,k) = VD(3,k) + (((E12' *(A^j)*C*E3)^2)* var(epscilon(3,:)))/varNU; 
VD(4,k) = VD(4,k) + (((E12' *(A^j)*C*E4)^2)* var(epscilon(4,:)))/varNU; 
VD(5,k) = VD(5,k) + (((E12' *(A^j)*C*E5)^2)* var(epscilon(5,:)))/varNU; 
VD(6,k) = VD(6,k) + (((E12' *(A^j)*C*E6)^2)* var(epscilon(6,:)))/varNU; 
VD(7,k) = VD(7,k) + (((E12' *(A^j)*C*E7)^2)* var(epscilon(7,:)))/varNU; 
end


VD(1,k) + VD(2,k) + VD(3,k) + VD(4,k) + VD(5,k) + VD(6,k) + VD(7,k) 

clear varNU

end

VD = VD*100; 
VDpre = VDpre*100; 
VDpre2 = VDpre2*100; 
VDpost = VDpost*100; 

save('VD_results_inflation_1984_2015.mat', 'VD', 'VDpre', 'VDpre2', 'VDpost')

%% 
clear all 
load('VD_results_inflation_1984_2015.mat')
Table_H11 = [VD(:,4), VDpre(:,4), VDpre2(:,4), VDpost(:,4)] ; 

Table_H12 = [VD(:,200), VDpre(:,200), VDpre2(:,200), VDpost(:,200)] ; 

save('Table_H11', 'Table_H11') 
save('Table_H12', 'Table_H12') 

%% Table H13: Standard deviation of the estimated shocks
clear all 

dynare usmodel_decomposition8415_1948_2015
save('usmodel_decomposition8415_1948_2015')

%% 
close all 

load usmodel_decomposition4807_1948_2015
shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ; 


epscilon = zeros(7,options_.nobs);
    epscilon(1, 2:options_.nobs) = oo_.SmoothedShocks.eZ(2:options_.nobs)';
    epscilon(2, 2:options_.nobs) = oo_.SmoothedShocks.ep(2:options_.nobs)';
    epscilon(3, 2:options_.nobs) = oo_.SmoothedShocks.ew(2:options_.nobs)';
    epscilon(4, 2:options_.nobs) = oo_.SmoothedShocks.eb2(2:options_.nobs)';
    epscilon(5, 2:options_.nobs) = oo_.SmoothedShocks.emu(2:options_.nobs)';
    epscilon(6, 2:options_.nobs) = oo_.SmoothedShocks.eg(2:options_.nobs)';
    epscilon(7, 2:options_.nobs) = oo_.SmoothedShocks.ems(2:options_.nobs)';
    
Shocks_std = zeros(7,5); 

for i = 1:7
   Shocks_std(i,1) = std( epscilon(i,:)); 
   Shocks_std(i,2) = std( epscilon(i,1:239)); %1948-2007
   Shocks_std(i,3) = std( epscilon(i,1:143)); %1948-1983
   Shocks_std(i,4) = std( epscilon(i,143:239)); %1984-2007
   Shocks_std(i,5) = std( epscilon(i,240:end)); %2008-2015
end


Shocks_std_4815 = Shocks_std(:,1); 
Shocks_std_4807 = Shocks_std(:,2); 
Shocks_std_4884 = Shocks_std(:,3);
Shocks_std_8407 = Shocks_std(:,4);
Shocks_std_0715 = Shocks_std(:,5);

label2 = cell(7,1); 
label2{1} = ['technology shock ' ] ;
label2{2} = ['price markup' ] ;
label2{3} = ['wage markup' ] ;
label2{4} = ['risk premium' ] ;
label2{5} = ['investment adjustment shock' ] ;
label2{6} = ['govt expenditure'  ] ;
label2{7} = ['monetary shocks' ] ;



save('TABLE_shocks_std_1948_2007_mean', 'label2', 'Shocks_std_4815', 'Shocks_std_4807', 'Shocks_std_4884', 'Shocks_std_8407', 'Shocks_std_0715');

%%
clear all 
load('TABLE_shocks_std_1948_2007_mean') 
Table_H13 = [Shocks_std_4815 ,Shocks_std_4807 , Shocks_std_4884 ,Shocks_std_8407, Shocks_std_0715 ] ;

save('Table_H13', 'Table_H13')

%% Figures H34, H35 :  Historical shocks decomposition of inflation (relative to long-run constant) for the period 1948Q1-2015Q1

load usmodel_decomposition8415_1948_2015

shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ; 


HD = zeros(20,options_.nobs); 

HD(1,:) =  shock_decomposition(37,1,:); %eZ
HD(2,:) =  shock_decomposition(37,2,:); %ep
HD(3,:) =  shock_decomposition(37,3,:); %ew
HD(4,:) =  shock_decomposition(37,4,:); %eb2
HD(5,:) =  shock_decomposition(37,5,:); %emu (inv. adj. cost) 
HD(6,:) =  shock_decomposition(37,6,:); %eg
HD(7,:) =  shock_decomposition(37,7,:); %ems (monetary shock)
InitialValue =  shock_decomposition(37,8,:); 
InitialValue = InitialValue(:); 
SmoothedPinfobs = shock_decomposition(37,9,:); 
SmoothedPinfobs = SmoothedPinfobs(:); 


HD(8,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(9,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:)  + InitialValue' ; 


% lambda_p + lambda_w seem to explain most of the variation with the
% exception of the latest years
HD(15,:) = HD(2,:) + HD(3,:); 



% lambda_w + monetary policy
HD(16,:) = HD(3,:)+ HD(7,:); 



% lambda_w + shock to preferences 
HD(17,:) = HD(3,:) + HD(4,:); 

    
% lambda_w + shock to preferences + monetary shock 
 HD(18,:) = HD(3,:) + HD(4,:) + HD(7,:);  
    
    
% investm. adj + shock to preferences + monetary shock 
    HD(19,:) = HD(5,:) + HD(4,:) + HD(7,:); 
  
% investm. adj + shock to preferences + monetary shock + price markup 
    HD(20,:) =  HD(5,:) + HD(4,:) + HD(7,:) + HD(2,:); 
    


epscilon = zeros(7,options_.nobs);
    epscilon(1, 2:options_.nobs) = oo_.SmoothedShocks.eZ(2:options_.nobs)';
    epscilon(2, 2:options_.nobs) = oo_.SmoothedShocks.ep(2:options_.nobs)';
    epscilon(3, 2:options_.nobs) = oo_.SmoothedShocks.ew(2:options_.nobs)';
    epscilon(4, 2:options_.nobs) = oo_.SmoothedShocks.eb2(2:options_.nobs)';
    epscilon(5, 2:options_.nobs) = oo_.SmoothedShocks.emu(2:options_.nobs)';
    epscilon(6, 2:options_.nobs) = oo_.SmoothedShocks.eg(2:options_.nobs)';
    epscilon(7, 2:options_.nobs) = oo_.SmoothedShocks.ems(2:options_.nobs)';
    
    
    HD = HD*4; % ANNUALIZED INFLATION; 
    SmoothedPinfobs = SmoothedPinfobs*4 ; % ANNUALIZED INFLATION; 
    InitialValue = InitialValue*4 ; 
    const_pi = const_pi*4 ; 

close all 

figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi, [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(1,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'TFP shocks'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(2,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 3*4])
        plot([2008.75,2008.75],[ -0.5*4 3*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to price markup'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi , [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(3,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to wage markup'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(4,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to risk premium'})
saveas(gcf,'HDec_pi_1984_2007_e8415','pdf')
saveas(gcf,'HDec_pi_1984_2007_e8415.epsc','epsc')

figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(5,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of shocks to';'investment-specific technology'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(6,144:end)+const_pi, 'r--');
        axis([1984 endyear+1 -0.5*4 2*4])
        enlargeChiara
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of shocks to';'government expenditure'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(7,144:end)+const_pi, 'r--')
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'monetary policy shock'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(15,144:end)+const_pi, 'r--')
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'price and wage';'markup shocks'})        
saveas(gcf,'HDec_pi_1984_2007_e8415_b','pdf')
saveas(gcf,'HDec_pi_1984_2007_e8415_b.epsc','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES


%% Figure H36 and H37: Historical shock decomposition of inflation (relative to long-run constant) for the period 2006Q1-2015Q1


close all


figure()
    subplot(2,2,1)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(1,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of';'shocks to TFP'})
    subplot(2,2,2)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(2,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of';'shock to price markup'})
    subplot(2,2,3)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(3,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of';'shock to wage markup'})
    subplot(2,2,4)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(4,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of';'shock to risk premium'})
saveas(gcf,'HDec_pi_2005-2013_e8415','pdf')
saveas(gcf,'HDec_pi_2005-2013_e8415.epsc','epsc')


figure()
    subplot(2,2,1)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(5,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of shocks to';'investment-specific technology'})
    subplot(2,2,2)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(6,:), 'r--');
        axis([2006 endyear+1 -1.2*4 7])
        enlargeChiara
        title({'contrib. of shock to';'government expenditure'})
    subplot(2,2,3)
        hndl = plot(label, SmoothedPinfobs, [2006, endyear+1], [0,0], 'k-', [2008, 2008], [-1.2*4 7], 'k-')
        enlargeChiara
        hold on 
        hndl = plot(label, HD(7,:), 'r--');
        enlargeChiara
        axis([2006 endyear+1 -1.2*4 7])
        title({'contrib. of';'monetary policy shock'})
saveas(gcf,'HDec_pi_2005-2013_e8415_b','pdf')
saveas(gcf,'HDec_pi_2005-2013_e8415_b.epsc','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES



%% Figure H38:  Price and wage markup shocks estimated from the model


figure()
    hndl = plot(label, epscilon(2,:));
    enlarge
    hold on
    plot([1940,2020],[0,0],'k-', 'HandleVisibility','off');
    title('Shocks to price markup')
    saveas(gcf,'shocksp_e8415','pdf')
        saveas(gcf,'shocksp_e8415.epsc','epsc')
figure()
    hndl = plot(label, epscilon(3,:));
    enlarge
    hold on
    plot([1940,2020],[0,0],'k-', 'HandleVisibility','off');
    title('Shocks to wage markup')
    saveas(gcf,'shocksw_e8415','pdf')
     saveas(gcf,'shocksw_e8415.epsc','epsc')


%% Figure H39 :  A comparison between interest rate and the output gap
close all 
load usmodel_decomposition8415_1948_2015

shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ; 


SmoothedOutputgap = shock_decomposition(13,9,:) - shock_decomposition(23,9,:) ; 
SmoothedOutputgap = SmoothedOutputgap(:); 

hndl = plot(label(228:end),SmoothedOutputgap(228:end));
enlarge
hold on
title('Output Gap','FontSize',26)
axis([2005 endyear+1 -10 10])
plot([2005 endyear+1], [0,0])
set(gca,'FontSize',26)   % this changes the tick size! 
saveas(gcf,'outputgap_20052013_e8415.epsc') 
saveas(gcf,'outputgap_20052013_e8415.pdf') 


HD = zeros(7,options_.nobs);


HD(1,:) =  shock_decomposition(38,1,:); %eZ
HD(2,:) =  shock_decomposition(38,2,:); %ep
HD(3,:) =  shock_decomposition(38,3,:); %ew
HD(4,:) =  shock_decomposition(38,4,:); %eb2
HD(5,:) =  shock_decomposition(38,5,:); %emu
HD(6,:) =  shock_decomposition(38,6,:); %eg
HD(7,:) =  shock_decomposition(38,7,:); %ems
InitialValue =  shock_decomposition(38,8,:); 
InitialValue = InitialValue(:); 
SmoothedRobs = shock_decomposition(38,9,:); 
SmoothedRobs = SmoothedRobs(:); 


% Now I want to do the opposite: I remove one shock at a time and check 
% if there are relevant results. 
HD(8,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(9,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:)  + InitialValue' ; 


% combination of shocks
% preferences and investment adjustment cost
HD(15,:) = HD(5,:) + HD(4,:) ; 
  
% price + wage markup shocks
HD(16,:) = HD(2,:) + HD(3,:); 

figure()
        hndl = plot(label(228:end), 4*(SmoothedRobs(228:end)+const_R));
        enlarge
        hold on 
        hndl = plot(label(228:end), 4*(HD(14,228:end)+const_R), 'r--');
        enlarge
        plot([2005,endyear+1], [0,0], 'k')
         axis([2005 endyear+1 -0.8*4 1.5*4])
        title('Interest Rate','FontSize',26)
        set(gca,'FontSize',26)   % this changes the tick size!         
clear LAB_SIZE LET_SIZE DO_THICK_LINES


saveas(gcf,'Hall_intrate2_e8415','pdf')
saveas(gcf,'Hall_intrate2_e8415','epsc')


%% Figure H40  Decomposition of the nominal interest rate according to the Taylor rule from the model

clear all
clc
close all

load usmodel_decomposition8415_1948_2015
shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ; 

HD = zeros(7,options_.nobs);


HD(1,:) =  shock_decomposition(38,1,:); %eZ
HD(2,:) =  shock_decomposition(38,2,:); %ep
HD(3,:) =  shock_decomposition(38,3,:); %ew
HD(4,:) =  shock_decomposition(38,4,:); %eb2
HD(5,:) =  shock_decomposition(38,5,:); %emu
HD(6,:) =  shock_decomposition(38,6,:); %eg
HD(7,:) =  shock_decomposition(38,7,:); %ems
InitialValue =  shock_decomposition(38,8,:); 
InitialValue = InitialValue(:); 
SmoothedRobs = shock_decomposition(38,9,:); 
SmoothedRobs = SmoothedRobs(:); 


% Now I want to do the opposite: I remove one shock at a time and check 
% if there are relevant results. 
HD(8,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(9,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:)  + InitialValue' ; 


% combination of shocks
% preferences and investment adjustment cost
HD(15,:) = HD(5,:) + HD(4,:) ; 
  
% price + wage markup shocks
HD(16,:) = HD(2,:) + HD(3,:); 



Taylor = zeros(7, options_.nobs); 

% contribution of initial point
for i= 2:options_.nobs
        Taylor(1,i) = rhoR*SmoothedRobs(i-1);
end

% contribution of inflation
for i= 2:options_.nobs
        Taylor(2,i) = (1 - rhoR)* (psi1*oo_.SmoothedVariables.pi(i));
end

% contribution of output gap
for i= 2:options_.nobs
        Taylor(3,i) = (1 - rhoR)* ( psi2*(oo_.SmoothedVariables.y(i) - oo_.SmoothedVariables.y_flex(i)));
end

% contribution of output gap growth 
for i= 2:options_.nobs
        Taylor(4,i) =   psi3*( oo_.SmoothedVariables.y(i) - oo_.SmoothedVariables.y(i-1) - oo_.SmoothedVariables.y_flex(i) + oo_.SmoothedVariables.y_flex(i-1)   )   ;
end

% contribution of monetary shock 
for i= 2:options_.nobs
        Taylor(5,i) =  oo_.SmoothedVariables.ms(i);
end

for i= 2:options_.nobs
Taylor(6,i) = Taylor(2,i) + Taylor(3,i) + Taylor(4,i) + Taylor(5,i) ;
Taylor(7,i) = Taylor(1,i) + Taylor(6,i) ; 

end

Taylor(:, 1) = NaN; 

%
% Taylor 1 = smoothing component = rhoR*r(-1)
%Taylor 2 = inflation component
% Taylor 3 = output gap 
% Taylor 4 = output gap growht
% Taylor 5 = monetary shock
% Taylor 6 = Taylor2 + T 3 + T 4 + T 5 
% Taylor 7 = Taylor 1 + Taylor 6  = SmoothedRobs+const_R


figure()
plot([2004, endyear], [0,0], 'HandleVisibility','off')
hold on
plot(label(228:end), SmoothedRobs(228:end), 'k', 'LineWidth',2 )
area(label(228:end),Taylor(2:4,228:end)'); 
colormap copper
plot(label(228:end), oo_.SmoothedVariables.ms(228:end), 'k:', 'LineWidth',4 )
 set(gca,'FontSize',12) 
legend( 'interest rate', 'inflation comp.', 'output gap comp.', 'output gap growth c.', 'monetary shocks', 'Location', 'SouthWest');
 axis([2005 endyear+1 -2 .6])
 
saveas(gcf,'Taylor_rule_decomposition_e8415','pdf')
saveas(gcf,'Taylor_rule_decomposition_e8415','epsc')



%% Tables H14 and H15

clear all
clc
close all

load usmodel8415_1948_2015


A = zeros(40); 
A(:,15:34) = oo_.dr.ghx;
C =  oo_.dr.ghu;

E14 = zeros(40,1);
E14(14) = 1; 


E1 = zeros(7,1);
E1(1) = 1; 
E2 = zeros(7,1);
E2(2) = 1; 
E3 = zeros(7,1);
E3(3) = 1; 
E4 = zeros(7,1);
E4(4) = 1; 
E5 = zeros(7,1);
E5(5) = 1; 
E6 = zeros(7,1);
E6(6) = 1; 
E7 = zeros(7,1);
E7(7) = 1; 


% epscilon matrix(time period x 7):
epscilon = zeros(options_.nobs,7); 
epscilon(:,1) = oo_.SmoothedShocks.eZ;
epscilon(:,2) = oo_.SmoothedShocks.ep;
epscilon(:,3) = oo_.SmoothedShocks.ew;
epscilon(:,4) = oo_.SmoothedShocks.eb2;
epscilon(:,5) = oo_.SmoothedShocks.emu;
epscilon(:,6) = oo_.SmoothedShocks.eg;
epscilon(:,7) = oo_.SmoothedShocks.ems;
epscilon = epscilon'; 

% 1-step ahead error forecast: 
NU1 = E14'*C*epscilon;



n = 200; 
%n = 4; 

VDpre = zeros(7,n);
VDpre2 = zeros(7,n);
VDpost = zeros(7,n); 
VD = zeros(7,n); 
for k = 1:n

% ------------------ 1948-2007 ------------------
varNU_pre = 0; 
for j = 0:k-1
varNU_pre = varNU_pre  + (((E14'*(A^j)*C*E1)^2)* var(epscilon(1,1:239)))+(((E14'*(A^j)*C*E2)^2)* var(epscilon(2,1:239)))+(((E14' *(A^j)*C*E3)^2)* var(epscilon(3,1:239)))+(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,1:239)))+(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,1:239)))+(((E14' *(A^j)*C*E6)^2)* var(epscilon(6,1:239)))+(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,1:239)));
end

for j = 0:k-1
VDpre(1,k) = VDpre(1,k) +(((E14' *(A^j) *C*E1)^2)* var(epscilon(1,1:239)))/varNU_pre; 
VDpre(2,k) = VDpre(2,k) +(((E14' *(A^j) *C*E2)^2)* var(epscilon(2,1:239)))/varNU_pre; 
VDpre(3,k) = VDpre(3,k) +(((E14' *(A^j) *C*E3)^2)* var(epscilon(3,1:239)))/varNU_pre; 
VDpre(4,k) = VDpre(4,k) +(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,1:239)))/varNU_pre; 
VDpre(5,k) = VDpre(5,k) +(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,1:239)))/varNU_pre; 
VDpre(6,k) = VDpre(6,k) +(((E14' *(A^j)*C*E6)^2)* var(epscilon(6,1:239)))/varNU_pre; 
VDpre(7,k) = VDpre(7,k) +(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,1:239)))/varNU_pre; 
end

VDpre(1,k) + VDpre(2,k) + VDpre(3,k) + VDpre(4,k) + VDpre(5,k) + VDpre(6,k) + VDpre(7,k) 


clear varNU_pre



% ------------------ 1984-2007 ------------------
varNU_pre2 = 0; 
for j = 0:k-1
varNU_pre2 = varNU_pre2  + (((E14'*(A^j)*C*E1)^2)* var(epscilon(1,144:239)))+(((E14'*(A^j)*C*E2)^2)* var(epscilon(2,144:239)))+(((E14' *(A^j)*C*E3)^2)* var(epscilon(3,144:239)))+(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,144:239)))+(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,144:239)))+(((E14' *(A^j)*C*E6)^2)* var(epscilon(6,144:239)))+(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,144:239)));
end

for j = 0:k-1
VDpre2(1,k) = VDpre2(1,k) +(((E14' *(A^j) *C*E1)^2)* var(epscilon(1,144:239)))/varNU_pre2; 
VDpre2(2,k) = VDpre2(2,k) +(((E14' *(A^j) *C*E2)^2)* var(epscilon(2,144:239)))/varNU_pre2; 
VDpre2(3,k) = VDpre2(3,k) +(((E14' *(A^j) *C*E3)^2)* var(epscilon(3,144:239)))/varNU_pre2; 
VDpre2(4,k) = VDpre2(4,k) +(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,144:239)))/varNU_pre2; 
VDpre2(5,k) = VDpre2(5,k) +(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,144:239)))/varNU_pre2; 
VDpre2(6,k) = VDpre2(6,k) +(((E14' *(A^j)*C*E6)^2)* var(epscilon(6,144:239)))/varNU_pre2; 
VDpre2(7,k) = VDpre2(7,k) +(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,144:239)))/varNU_pre2; 
end

VDpre2(1,k) + VDpre2(2,k) + VDpre2(3,k) + VDpre2(4,k) + VDpre2(5,k) + VDpre2(6,k) + VDpre2(7,k) 


clear varNU_pre2


% ------------------ 2008-2013 ------------------
varNU_post = 0; 
for j = 0:k-1
varNU_post = varNU_post + (((E14' *(A^j)*C*E1)^2)* var(epscilon(1,240:end)))+(((E14'*(A^j) *C*E2)^2)* var(epscilon(2,240:end)))+(((E14'*(A^j) *C*E3)^2)* var(epscilon(3,240:end)))+(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,240:end)))+(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,240:end)))+(((E14' *(A^j)*C*E6)^2)* var(epscilon(6,240:end)))+(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,240:end)));
end

for j = 0:k-1
VDpost(1,k) = VDpost(1,k) + (((E14' *(A^j)*C*E1)^2)* var(epscilon(1,240:end)))/varNU_post; 
VDpost(2,k) = VDpost(2,k) +(((E14' *(A^j)*C*E2)^2)* var(epscilon(2,240:end)))/varNU_post; 
VDpost(3,k) = VDpost(3,k) + (((E14'*(A^j) *C*E3)^2)* var(epscilon(3,240:end)))/varNU_post; 
VDpost(4,k) = VDpost(4,k) + (((E14' *(A^j)*C*E4)^2)* var(epscilon(4,240:end)))/varNU_post; 
VDpost(5,k) = VDpost(5,k) + (((E14' *(A^j)*C*E5)^2)* var(epscilon(5,240:end)))/varNU_post; 
VDpost(6,k) = VDpost(6,k) + (((E14' *(A^j)*C*E6)^2)* var(epscilon(6,240:end)))/varNU_post; 
VDpost(7,k) = VDpost(7,k) + (((E14'*(A^j) *C*E7)^2)* var(epscilon(7,240:end)))/varNU_post; 
end

VDpost(1,k) + VDpost(2,k) + VDpost(3,k) + VDpost(4,k) + VDpost(5,k) + VDpost(6,k) + VDpost(7,k) 

clear varNU_post

% ------------------ 1948-2013 ------------------ 
% This is the 1-period aheas conditional variance decomposition for the whole sample 
% as a check this should be the same as the corresponding measure as is
% obtained from Dynare. 
varNU = 0; 
for j = 0:k-1
varNU = varNU + (((E14' *(A^j)*C*E1)^2)* var(epscilon(1,:)))+(((E14' *(A^j)*C*E2)^2)* var(epscilon(2,:)))+(((E14'*(A^j) *C*E3)^2)* var(epscilon(3,:)))+(((E14' *(A^j)*C*E4)^2)* var(epscilon(4,:)))+(((E14' *(A^j)*C*E5)^2)* var(epscilon(5,:)))+(((E14'*(A^j) *C*E6)^2)* var(epscilon(6,:)))+(((E14' *(A^j)*C*E7)^2)* var(epscilon(7,:)));
end

for j = 0:k-1
VD(1,k) = VD(1,k) + (((E14' *(A^j)*C*E1)^2)* var(epscilon(1,:)))/varNU; 
VD(2,k) = VD(2,k) + (((E14' *(A^j)*C*E2)^2)* var(epscilon(2,:)))/varNU; 
VD(3,k) = VD(3,k) + (((E14' *(A^j)*C*E3)^2)* var(epscilon(3,:)))/varNU; 
VD(4,k) = VD(4,k) + (((E14' *(A^j)*C*E4)^2)* var(epscilon(4,:)))/varNU; 
VD(5,k) = VD(5,k) + (((E14' *(A^j)*C*E5)^2)* var(epscilon(5,:)))/varNU; 
VD(6,k) = VD(6,k) + (((E14' *(A^j)*C*E6)^2)* var(epscilon(6,:)))/varNU; 
VD(7,k) = VD(7,k) + (((E14' *(A^j)*C*E7)^2)* var(epscilon(7,:)))/varNU; 
end


VD(1,k) + VD(2,k) + VD(3,k) + VD(4,k) + VD(5,k) + VD(6,k) + VD(7,k) 

clear varNU

end

VD = VD*100; 
VDpre = VDpre*100; 
VDpre2 = VDpre2*100;
VDpost = VDpost*100; 

save('VD_results_employment1984_2015.mat', 'VD', 'VDpre', 'VDpre2','VDpost')

%% 
clear all 
load('VD_results_employment1984_2015.mat')
Table_H14 = [VD(:,4), VDpre(:,4), VDpre2(:,4), VDpost(:,4)] ; 

Table_H15 = [VD(:,200), VDpre(:,200), VDpre2(:,200), VDpost(:,200)] ; 

save('Table_H14', 'Table_H14')
save('Table_H15', 'Table_H15')

%% Figure H41 and H42: Historical shock decomposition of employment for the period 1984-2015
close all 
clear all 

load usmodel_decomposition8415_1948_2015 

shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ;

% http://www.dynare.org/phpBB3/viewtopic.php?f=1&t=5887
% The mean of the smoothed variables is non-zero if the corresponding data



HD(1,:) =  shock_decomposition(39,1,:); %eZ
HD(2,:) =  shock_decomposition(39,2,:); %ep
HD(3,:) =  shock_decomposition(39,3,:); %ew
HD(4,:) =  shock_decomposition(39,4,:); %eb2
HD(5,:) =  shock_decomposition(39,5,:); %emu
HD(6,:) =  shock_decomposition(39,6,:); %eg
HD(7,:) =  shock_decomposition(39,7,:); %ems
InitialValue =  shock_decomposition(39,8,:); 
InitialValue = InitialValue(:); 
SmoothedLabobs = shock_decomposition(39,9,:); 
SmoothedLabobs = SmoothedLabobs(:); 


HD(8,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(9,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:)  + InitialValue' ; 

% lambda_p + lambda_w seem to explain most of the variation with the
% exception of the latest years
HD(15,:) = HD(2,:) + HD(3,:); 



% lambda_w + monetary policy
HD(16,:) = HD(3,:)+ HD(7,:); 
    
% lambda_w + shock to preferences 
HD(17,:) = HD(3,:) + HD(4,:); 

    
% lambda_w + shock to preferences + monetary shock 
 HD(18,:) = HD(3,:) + HD(4,:) + HD(7,:);  
    
    
% investm. adj + shock to preferences + monetary shock 
    HD(19,:) = HD(5,:) + HD(4,:) + HD(7,:); 
  
% investm. adj + shock to preferences + monetary shock + price markup 
    HD(20,:) =  HD(5,:) + HD(4,:) + HD(7,:) + HD(2,:); 
    
    
    
figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end),HD(1,144:end) , 'r--');
        enlargeChiara
        axis([1984 endyear+1 -12 8])
        title({'contrib. of';'TFP'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(2,144:end), 'r--');
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'contrib. of';'shock to price markup'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(3,144:end), 'r--');
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'contrib. of';'shock to wage markup'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(4,144:end), 'r--');
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'contrib. of';'shock to risk premium'})
saveas(gcf,'HDec_lab_1984-2013_e8415','pdf')
saveas(gcf,'HDec_lab_1984-2013_e8415','epsc')


figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(5,144:end), 'r--')
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'contrib. of shocks to';'investment-specific technology'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(6,144:end), 'r--')
        axis([1984 endyear+1 -12 8 ])
        enlargeChiara
        title({'contrib. of shock to';'government expenditure'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(7,144:end), 'r--')
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'contrib. of';'monetary policy shock'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedLabobs(144:end), [2008,2008],[-12,8 ],'k-', [1984,endyear+1],[0,0],'k-');
        hold on 
        hndl = plot(label(144:end), HD(15,144:end), 'r--')
        enlargeChiara
        axis([1984 endyear+1 -12 8 ])
        title({'price and wage';'markup shock'})
saveas(gcf,'HDec_lab_1984-2013_e8415_b','pdf')
saveas(gcf,'HDec_lab_1984-2013_e8415_b','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES

%% Figures H43 and H44:  Historical shock decomposition of employment for the period 2005-2015

figure()
    subplot(2,2,1)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(1,228:end), 'r--');
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        title({'contrib. of';'TFP'})
    subplot(2,2,2)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(2,228:end), 'r--');
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        title({'contrib. of';'shocks to price markup'})
    subplot(2,2,3)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(3,228:end), 'r--');
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        title({'contrib. of';'shocks to wage markup'})
    subplot(2,2,4)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(4,228:end), 'r--');
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        title({'contrib. of';'shocks to risk premium'})
saveas(gcf,'HDec_lab_2005-2013_e8415','pdf')
saveas(gcf,'HDec_lab_2005-2013_e8415','epsc')

figure()
    subplot(2,2,1)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(5,228:end), 'r--');
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        title({'contrib. of shocks to ';'investment-adjustment technology'})
    subplot(2,2,2)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(6,228:end), 'r--');
        axis([2005 endyear+1 -12 8 ])
        line([2005 endyear+1], [0 0])
        enlargeChiara
        title({'contrib. of shocks to';'government expenditure'})
    subplot(2,2,3)
        hndl = plot(label(228:end), SmoothedLabobs(228:end), [2008,2008],[-12,8 ],'k-', [2005,endyear+1],[0,0],'k-');
        hold on 
        enlargeChiara
        hndl = plot(label(228:end), HD(7,228:end), 'r--');
        line([2005 endyear+1], [0 0])
        enlargeChiara
        axis([2005 endyear+1 -12 8 ])
        title({'contrib. of';'monetary policy shocks'})
saveas(gcf,'HDec_lab_2005-2013_e8415_b','pdf')
saveas(gcf,'HDec_lab_2005-2013_e8415_b','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES


%% Table I16
clear all 
close all 

load usmodel1984_2007inflTarg



f = 10.^2; 

posterior_mean_paramInfTarg =  round(f.*oo_.posterior.metropolis.mean)./f; 
posterior_std_paramInfTarg = round(f.*sqrt(diag(oo_.posterior.metropolis.Variance)))./f;

Table_I16column2 =  posterior_mean_paramInfTarg ; 

save('Table_I16column2', 'Table_I16column2')

clear all 
load('usmodel1984_2007inflTarg2_mean.mat')

f = 10.^2; 

posterior_mean_paramInfTarg2 =  round(f.*xparam1)./f; 
posterior_std_paramInfTarg2 = round(f.*(diag(SIGMA)))./f;

Table_I16column1 =  posterior_mean_paramInfTarg2 ; 

save('Table_I16column1', 'Table_I16column1')


%% Figure I.45 and I 46: Model with time-varying inflation target. Historical shocks decomposition of
% inflation (relative to long-run constant) for the period 1984Q1-2015Q1. Posterior distributions according to mode (1)

clear all 

dynare usmodel1984_2007inflTarg_dec1948_2015

%%

shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015];
endyear = 2015 ;


HD = zeros(20,options_.nobs); 

HD(1,:) =  shock_decomposition(37,1,:); %eZ
HD(2,:) =  shock_decomposition(37,2,:); %ep
HD(3,:) =  shock_decomposition(37,3,:); %ew
HD(4,:) =  shock_decomposition(37,4,:); %eb2
HD(5,:) =  shock_decomposition(37,5,:); %emu (inv. adj. cost) 
HD(6,:) =  shock_decomposition(37,6,:); %eg
HD(7,:) =  shock_decomposition(37,7,:); %ems (monetary shock)
HD(8,:) =  shock_decomposition(37,8,:); %epi_star (inflation target)
InitialValue =  shock_decomposition(37,9,:); 
InitialValue = InitialValue(:); 
SmoothedPinfobs = shock_decomposition(37,10,:); 
SmoothedPinfobs = SmoothedPinfobs(:); 


HD(9,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:)+ HD(8,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + HD(8,:)+ InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + HD(8,:)+ InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + HD(8,:)+ InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + HD(8,:)+ InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + HD(8,:)+ InitialValue' ; 
HD(15,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(8,:) + InitialValue' ; 
HD(16,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 

% combination of shocks
%NB: when you compute combinations of shocks remember to change the sum of
%oo_.dr.ghu and the update of Y (sums of C*epscilon)

% lambda_p + lambda_w seem to explain most of the variation with the
% exception of the latest years
%HD(15,:) = HD(2,:) + HD(3,:); 
HD(17,:) = HD(2,:) + HD(3,:); 


% lambda_w + monetary policy
%HD(16,:) = HD(3,:)+ HD(7,:); 
HD(18,:) = HD(3,:)+ HD(7,:); 


% lambda_w + shock to preferences 
%HD(17,:) = HD(3,:) + HD(4,:); 
HD(19,:) = HD(3,:) + HD(4,:); 
    
% lambda_w + shock to preferences + monetary shock 
%HD(18,:) = HD(3,:) + HD(4,:) + HD(7,:);  
HD(20,:) = HD(3,:) + HD(4,:) + HD(7,:);      
    
% investm. adj + shock to preferences + monetary shock 
%HD(19,:) = HD(5,:) + HD(4,:) + HD(7,:); 
HD(21,:) = HD(5,:) + HD(4,:) + HD(7,:); 

% investm. adj + shock to preferences + monetary shock + price markup 
%HD(20,:) =  HD(5,:) + HD(4,:) + HD(7,:) + HD(2,:); 
HD(22,:) =  HD(5,:) + HD(4,:) + HD(7,:) + HD(2,:);     

%markup shocks plus inflation target
HD(23,:) = HD(2,:) + HD(3,:) + HD(8,:); 

epscilon = zeros(7,options_.nobs);
    epscilon(1, 2:options_.nobs) = oo_.SmoothedShocks.eZ(2:options_.nobs)';
    epscilon(2, 2:options_.nobs) = oo_.SmoothedShocks.ep(2:options_.nobs)';
    epscilon(3, 2:options_.nobs) = oo_.SmoothedShocks.ew(2:options_.nobs)';
    epscilon(4, 2:options_.nobs) = oo_.SmoothedShocks.eb2(2:options_.nobs)';
    epscilon(5, 2:options_.nobs) = oo_.SmoothedShocks.emu(2:options_.nobs)';
    epscilon(6, 2:options_.nobs) = oo_.SmoothedShocks.eg(2:options_.nobs)';
    epscilon(7, 2:options_.nobs) = oo_.SmoothedShocks.ems(2:options_.nobs)';
    epscilon(8, 2:options_.nobs) = oo_.SmoothedShocks.epi_star(2:options_.nobs)';

    
    HD = HD*4; % ANNUALIZED INFLATION; 
    SmoothedPinfobs = SmoothedPinfobs*4 ; % ANNUALIZED INFLATION; 
    InitialValue = InitialValue*4 ; 
    const_pi = const_pi*4 ; 
    
    


figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi, [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(1,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'TFP shocks'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(2,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to price markup'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi , [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(3,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to wage markup'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(4,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to risk premium'})
saveas(gcf,'HDec_pi_1984-2013_infTarg_g','pdf')
saveas(gcf,'HDec_pi_1984-2013_infTarg_g','epsc')

%% 
figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(5,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of shocks to';'investment-specific technology'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(6,144:end)+const_pi, 'r--');
        axis([1984 endyear+1 -0.5*4 2*4])
        enlargeChiara
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of shocks to';'government expenditure'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(7,144:end)+const_pi, 'r--')
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'monetary policy shock'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(8,144:end)+const_pi, 'r--')
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shock to inflation target'})   
saveas(gcf,'HDec_pi_1984-2013b_infTarg_g','pdf')
saveas(gcf,'HDec_pi_1984-2013b_infTarg_g','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES


%% Figure I.47 I.48 and I.49: Del Negro, Giannoni and Schorfheide (2015) . Historical shocks decomposition
% of inflation (relative to long-run constant) for the period 1984Q1-2015Q1

dynare usmodel2015_spread10_ff


shock_decomposition = oo_.shock_decomposition; 

label = [1953.5:0.25:2015];
endyear = 2015 ; 


HD = zeros(20,options_.nobs); 

HD(1,:) =  shock_decomposition(36,1,:); %eZ   // now inflation is at position 36! 
HD(2,:) =  shock_decomposition(36,2,:); %ep
HD(3,:) =  shock_decomposition(36,3,:); %ew
HD(4,:) =  shock_decomposition(36,4,:); %eb2
HD(5,:) =  shock_decomposition(36,5,:); %emu (inv. adj. cost) 
HD(6,:) =  shock_decomposition(36,6,:); %eg
HD(7,:) =  shock_decomposition(36,7,:); %ems (monetary shock)
HD(8,:) =  shock_decomposition(36,8,:); %eff (financial shock)
% shock_decomposition(36,9,:); %emue (this shock is really zero, so I am
% simply not using it) 
HD(9,:) =  shock_decomposition(36,9,:); %epist (shocks to the inflation target) 

InitialValue =  shock_decomposition(36,12,:); 
InitialValue = InitialValue(:); 
SmoothedPinfobs = shock_decomposition(36,13,:); 
SmoothedPinfobs = SmoothedPinfobs(:); 

%shock_decomposition(36,11,:)

% combination of shocks
%NB: when you compute combinations of shocks remember to change the sum of
%oo_.dr.ghu and the update of Y (sums of C*epscilon)

% lambda_p + lambda_w seem to explain most of the variation with the
% exception of the latest years
HD(10,:) = HD(2,:) + HD(3,:); 



% lambda_p + lambda_w + ff 
HD(11,:) = HD(2,:) + HD(3,:)+ HD(8,:); 



    

epscilon = zeros(7,options_.nobs);
    epscilon(1, 2:options_.nobs) = oo_.SmoothedShocks.eZ(2:options_.nobs)';
    epscilon(2, 2:options_.nobs) = oo_.SmoothedShocks.ep(2:options_.nobs)';
    epscilon(3, 2:options_.nobs) = oo_.SmoothedShocks.ew(2:options_.nobs)';
    epscilon(4, 2:options_.nobs) = oo_.SmoothedShocks.eb2(2:options_.nobs)';
    epscilon(5, 2:options_.nobs) = oo_.SmoothedShocks.emu(2:options_.nobs)';
    epscilon(6, 2:options_.nobs) = oo_.SmoothedShocks.eg(2:options_.nobs)';
    epscilon(7, 2:options_.nobs) = oo_.SmoothedShocks.ems(2:options_.nobs)';
    epscilon(8, 2:options_.nobs) = oo_.SmoothedShocks.eff(2:options_.nobs)';
    epscilon(9, 2:options_.nobs) = oo_.SmoothedShocks.epist(2:options_.nobs)';
    
    HD = HD*4; % ANNUALIZED INFLATION; 
    SmoothedPinfobs = SmoothedPinfobs*4 ; % ANNUALIZED INFLATION; 
    InitialValue = InitialValue*4 ; 
    const_pi = const_pi*4 ; 

    

figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi, [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(1,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'TFP shocks'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(2,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to price markup'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi , [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(3,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to wage markup'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(4,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'shocks to risk premium'})
saveas(gcf,'HDec_pi_1984-2013DGS','pdf')
saveas(gcf,'HDec_pi_1984-2013DGS','epsc')

figure()
    subplot(2,2,1)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(5,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of shocks to';'investment-specific technology'})
    subplot(2,2,2)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(6,144:end)+const_pi, 'r--');
        axis([1984 endyear+1 -0.5*4 2*4])
        enlargeChiara
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of shocks to';'government expenditure'})
    subplot(2,2,3)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(7,144:end)+const_pi, 'r--')
        enlargeChiara
        axis([1984 endyear+1 -0.5*4 2*4])
        plot([2008.75,2008.75],[ -0.5*4 2*4 ],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contrib. of';'monetary policy shock'})
    subplot(2,2,4)
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(8,144:end)+const_pi, 'r--')
        enlargeChiara
        axis([1984 endyear+1 -2*4 4*4])
        title({'contrib. of';'financial shock'})
saveas(gcf,'HDec_pi_1984-2013bDGS','pdf')
saveas(gcf,'HDec_pi_1984-2013bDGS','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES


figure()
        plot(label(144:end), SmoothedPinfobs(144:end)+const_pi,  [1984,endyear+1],[const_pi,const_pi],'k-');
        hold on 
        hndl = plot(label(144:end), HD(9,144:end)+const_pi, 'r--');
        enlargeChiara
        axis([1984 endyear+1 -2*4 4*4])
        title({'contrib. of shocks to';'inflation target'})
saveas(gcf,'HDec_pi_1984-2013cDGS','pdf')
saveas(gcf,'HDec_pi_1984-2013cDGS','epsc')


clear LAB_SIZE LET_SIZE DO_THICK_LINES   

