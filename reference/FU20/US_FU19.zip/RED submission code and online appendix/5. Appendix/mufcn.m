
function f=mufcn(z,sigma,const_SP)
f = (1-1/const_SP)/(dGdomegafcn(z,sigma)/dGammadomegafcn(z)*(1-Gammafcn(z,sigma))+Gfcn(z,sigma));
end