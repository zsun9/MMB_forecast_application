

function f=zetaspbfcn(z,sigma,const_SP)
zetaratio = zetabomegafcn(z,sigma,const_SP)/zetazomegafcn(z,sigma,const_SP);
nk = nkfcn(z,sigma,const_SP);
f = -zetaratio/(1-zetaratio)*nk/(1-nk);
end
