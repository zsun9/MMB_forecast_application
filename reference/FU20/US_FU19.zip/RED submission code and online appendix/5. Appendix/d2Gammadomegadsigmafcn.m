function f=d2Gammadomegadsigmafcn(z,sigma)
f = (z/sigma-1)*normpdf(z);
end