
function f=dGdomegafcn(z,sigma)
f=normpdf(z)/sigma;
end
