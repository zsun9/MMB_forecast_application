
function f=nkfcn(z,sigma,const_SP)
f = 1-(Gammafcn(z,sigma)-mufcn(z,sigma,const_SP)*Gfcn(z,sigma))*const_SP;
end
