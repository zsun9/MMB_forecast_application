
function f=omegafcn(z,sigma)
f = exp(sigma*z-1/2*sigma^2);
end