function f=dGammadomegafcn(z)
f = 1-normcdf(z);
end
