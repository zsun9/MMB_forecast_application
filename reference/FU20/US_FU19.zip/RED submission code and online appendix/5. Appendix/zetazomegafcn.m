
function f=zetazomegafcn(z,sigma,const_SP)
mustar = mufcn(z,sigma,const_SP);
f = omegafcn(z,sigma)*(dGammadomegafcn(z)-mustar*dGdomegafcn(z,sigma))/...
    (Gammafcn(z,sigma)-mustar*Gfcn(z,sigma));
end
