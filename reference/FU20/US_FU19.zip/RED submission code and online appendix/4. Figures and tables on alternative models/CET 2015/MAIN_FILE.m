clear all
clc

dynare cet.mod