
clc 
clear all
close all 
dynare usmodel1984_2007inflTarg_dec1948_2015


save('usmodel1984_2007inflTarg_dec1948_2015')

%%
clc 
clear all
close all 

dynare usmodel2015_spread10_ff

save('usmodel2015_spread10_ff_1948_2015')


%% Figure 16: Accounting for inflation in a model with a time-varying inflation target, using
% the posterior mode for the autoregressive coefficient for the inflation target, estimated to
% be 0.5141.

clc 
clear all

load usmodel1984_2007inflTarg_dec1948_2015
shock_decomposition = oo_.shock_decomposition; 

label = [1948.25:0.25:2015.0];
endyear = 2015 ; 


HD = zeros(20,options_.nobs); 

HD(1,:) =  shock_decomposition(37,1,:); %eZ
HD(2,:) =  shock_decomposition(37,2,:); %ep
HD(3,:) =  shock_decomposition(37,3,:); %ew
HD(4,:) =  shock_decomposition(37,4,:); %eb2
HD(5,:) =  shock_decomposition(37,5,:); %emu (inv. adj. cost) 
HD(6,:) =  shock_decomposition(37,6,:); %eg
HD(7,:) =  shock_decomposition(37,7,:); %ems (monetary shock)
HD(8,:) =  shock_decomposition(37,8,:); %epi_star (inflation target)
InitialValue =  shock_decomposition(37,9,:); 
InitialValue = InitialValue(:); 
SmoothedPinfobs = shock_decomposition(37,10,:); 
SmoothedPinfobs = SmoothedPinfobs(:); 


HD(9,:) =  HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:)+ HD(8,:) + InitialValue' ; 
HD(10,:) = HD(1,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + HD(8,:)+ InitialValue' ; 
HD(11,:) = HD(1,:) + HD(2,:)+ HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + HD(8,:)+ InitialValue' ; 
HD(12,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(5,:) + HD(6,:) + HD(7,:) + HD(8,:)+ InitialValue' ; 
HD(13,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:)+ HD(6,:) + HD(7,:) + HD(8,:)+ InitialValue' ; 
HD(14,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(7,:) + HD(8,:)+ InitialValue' ; 
HD(15,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(8,:) + InitialValue' ; 
HD(16,:) = HD(1,:) + HD(2,:) + HD(3,:) + HD(4,:) + HD(5,:) + HD(6,:) + HD(7,:) + InitialValue' ; 

% combination of shocks

% lambda_p + lambda_w seem to explain most of the variation with the
% exception of the latest years
%HD(15,:) = HD(2,:) + HD(3,:); 
HD(17,:) = HD(2,:) + HD(3,:); 


% lambda_w + monetary policy
%HD(16,:) = HD(3,:)+ HD(7,:); 
HD(18,:) = HD(3,:)+ HD(7,:); 


% lambda_w + shock to preferences 
%HD(17,:) = HD(3,:) + HD(4,:); 
HD(19,:) = HD(3,:) + HD(4,:); 
    
% lambda_w + shock to preferences + monetary shock 
%HD(18,:) = HD(3,:) + HD(4,:) + HD(7,:);  
HD(20,:) = HD(3,:) + HD(4,:) + HD(7,:);      
    
% investm. adj + shock to preferences + monetary shock 
%HD(19,:) = HD(5,:) + HD(4,:) + HD(7,:); 
HD(21,:) = HD(5,:) + HD(4,:) + HD(7,:); 

% investm. adj + shock to preferences + monetary shock + price markup 
%HD(20,:) =  HD(5,:) + HD(4,:) + HD(7,:) + HD(2,:); 
HD(22,:) =  HD(5,:) + HD(4,:) + HD(7,:) + HD(2,:);     

%markup shocks plus inflation target
HD(23,:) = HD(2,:) + HD(3,:) + HD(8,:); 

epsilon = zeros(7,options_.nobs);
    epsilon(1, 2:options_.nobs) = oo_.SmoothedShocks.eZ(2:options_.nobs)';
    epsilon(2, 2:options_.nobs) = oo_.SmoothedShocks.ep(2:options_.nobs)';
    epsilon(3, 2:options_.nobs) = oo_.SmoothedShocks.ew(2:options_.nobs)';
    epsilon(4, 2:options_.nobs) = oo_.SmoothedShocks.eb2(2:options_.nobs)';
    epsilon(5, 2:options_.nobs) = oo_.SmoothedShocks.emu(2:options_.nobs)';
    epsilon(6, 2:options_.nobs) = oo_.SmoothedShocks.eg(2:options_.nobs)';
    epsilon(7, 2:options_.nobs) = oo_.SmoothedShocks.ems(2:options_.nobs)';
    epsilon(8, 2:options_.nobs) = oo_.SmoothedShocks.epi_star(2:options_.nobs)';

    
    HD = HD*4; % ANNUALIZED INFLATION; 
    SmoothedPinfobs = SmoothedPinfobs*4 ; % ANNUALIZED INFLATION; 
    InitialValue = InitialValue*4 ; 
    const_pi = const_pi*4 ; 


figure()
        hndl = plot(label, SmoothedPinfobs+const_pi)
        enlargeChiara
        hold on 
        hndl = plot(label, HD(17,:)+const_pi, 'r--')
        enlargeChiara
        axis([1948 endyear+1 -2*4 4*4])
        plot([1948,endyear+1],[const_pi,const_pi],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contribution of';'shocks to wage and price markup'})
saveas(gcf,'HDec_pi_1948-2013_markups_infTarg_d','pdf')
saveas(gcf,'HDec_pi_1948-2013_markups_infTarg_d','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES



figure()
    hndl = plot(label, SmoothedPinfobs+const_pi,  [1948,endyear+1],[const_pi,const_pi],'k-');
    enlargeChiara
    hold on 
    hndl = plot(label, HD(8,:)+const_pi, 'r--')
    enlargeChiara
    axis([1948 endyear+1 -2*4 4*4])
    title({'contribution of';'shocks to inflation target'})        
saveas(gcf,'HDec_pi_1948-2013_infTarg_d','pdf')
saveas(gcf,'HDec_pi_1948-2013_infTarg_d','epsc')


%% Figure 17: Del Negro et al. (2015)


load usmodel2015_spread10_ff_1948_2015 
shock_decomposition = oo_.shock_decomposition; 

label = [1953.5:0.25:2015];
endyear = 2015 ; 


HD = zeros(20,options_.nobs); 

HD(1,:) =  shock_decomposition(36,1,:); %eZ   // now inflation is at position 36! 
HD(2,:) =  shock_decomposition(36,2,:); %ep
HD(3,:) =  shock_decomposition(36,3,:); %ew
HD(4,:) =  shock_decomposition(36,4,:); %eb2
HD(5,:) =  shock_decomposition(36,5,:); %emu (inv. adj. cost) 
HD(6,:) =  shock_decomposition(36,6,:); %eg
HD(7,:) =  shock_decomposition(36,7,:); %ems (monetary shock)
HD(8,:) =  shock_decomposition(36,8,:); %eff (financial shock)
% shock_decomposition(36,9,:); %emue (this shock is really zero, so I am
% simply not using it) 
HD(9,:) =  shock_decomposition(36,9,:); %epist (shocks to the inflation target) 

InitialValue =  shock_decomposition(36,12,:); 
InitialValue = InitialValue(:); 
SmoothedPinfobs = shock_decomposition(36,13,:); 
SmoothedPinfobs = SmoothedPinfobs(:); 

%shock_decomposition(36,11,:)

% combination of shocks

% lambda_p + lambda_w seem to explain most of the variation with the
% exception of the latest years
HD(10,:) = HD(2,:) + HD(3,:); 



% lambda_p + lambda_w + ff 
HD(11,:) = HD(2,:) + HD(3,:)+ HD(8,:); 



    

epsilon = zeros(7,options_.nobs);
    epsilon(1, 2:options_.nobs) = oo_.SmoothedShocks.eZ(2:options_.nobs)';
    epsilon(2, 2:options_.nobs) = oo_.SmoothedShocks.ep(2:options_.nobs)';
    epsilon(3, 2:options_.nobs) = oo_.SmoothedShocks.ew(2:options_.nobs)';
    epsilon(4, 2:options_.nobs) = oo_.SmoothedShocks.eb2(2:options_.nobs)';
    epsilon(5, 2:options_.nobs) = oo_.SmoothedShocks.emu(2:options_.nobs)';
    epsilon(6, 2:options_.nobs) = oo_.SmoothedShocks.eg(2:options_.nobs)';
    epsilon(7, 2:options_.nobs) = oo_.SmoothedShocks.ems(2:options_.nobs)';
    epsilon(8, 2:options_.nobs) = oo_.SmoothedShocks.eff(2:options_.nobs)';
    epsilon(9, 2:options_.nobs) = oo_.SmoothedShocks.epist(2:options_.nobs)';
    
    HD = HD*4; % ANNUALIZED INFLATION; 
    SmoothedPinfobs = SmoothedPinfobs*4 ; % ANNUALIZED INFLATION; 
    InitialValue = InitialValue*4 ; 
    const_pi = const_pi*4 ; 



figure()
        hndl = plot(label, SmoothedPinfobs+const_pi)
        enlargeChiara
        hold on 
        hndl = plot(label, HD(10,:)+const_pi, 'r--')
        enlargeChiara
        axis([1948 endyear+1 -2*4 4*4])
        plot([1948,endyear+1],[const_pi,const_pi],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contribution of';'shocks to wage and price markup'})
saveas(gcf,'HDec_pi_1948-2013_markupsDGS','pdf')
saveas(gcf,'HDec_pi_1948-2013_markupsDGS','epsc')

clear LAB_SIZE LET_SIZE DO_THICK_LINES


figure()
        hndl = plot(label, SmoothedPinfobs+const_pi) ; 
        hold on 
        enlargeChiara
        hndl = plot(label, HD(10,:)+HD(8,:)+const_pi , 'r--') ; 
        enlargeChiara
        axis([1948 endyear+1 -2*4 4*4])
        plot([1948,endyear+1],[const_pi,const_pi],'k-', 'HandleVisibility','off', 'LineWidth', 2);
        title({'contribution of';  'markup shocks + financial shocks'})
saveas(gcf,'HDec_pi_1948-2013_markups_ffDGS','pdf')
saveas(gcf,'HDec_pi_1948-2013_markups_ffDGS','epsc')




