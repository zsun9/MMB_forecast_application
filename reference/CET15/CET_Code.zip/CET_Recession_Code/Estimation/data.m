%Dynare needs this file to invoke estimation 
%since we estimate the models using impulse response matching, we just
%pass-on some random data here to avoid Dynare getting stuck.

yR=rand(10,1);

