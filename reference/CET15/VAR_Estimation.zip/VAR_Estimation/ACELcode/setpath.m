addpath c:\projects\solve\code
addpath c:\projects\solve\newandersen